import { GoogleGenAI, Type, Modality, FunctionDeclaration } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

/**
 * Utility to retry an async function with exponential backoff.
 * Specifically handles 429 (Rate Limit) errors.
 */
async function withRetry<T>(fn: () => Promise<T>, maxRetries = 7, initialDelay = 1000): Promise<T> {
  let lastError: unknown;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error: unknown) {
      lastError = error;
      const err = error as { message?: string; status?: number; name?: string };
      const errorMessage = err?.message || (typeof error === "string" ? error : "");
      
      // Handle both string and status-based rate limits
      const isRateLimit = errorMessage.includes("429") || 
                        err?.status === 429 || 
                        JSON.stringify(error).includes("429") ||
                        err?.name === "QuotaExceededError";

      const isSafety = errorMessage.toLowerCase().includes("safety") ||
                       errorMessage.toLowerCase().includes("blocked");
      
      if (isRateLimit && i < maxRetries - 1) {
        // Exponential backoff with jitter
        const jitter = Math.random() * 800;
        const delay = (initialDelay * Math.pow(2, i)) + jitter;
        
        console.warn(`[Aether_Core] Neural link throttled (429). Re-attempting sync in ${Math.round(delay)}ms... (Attempt ${i + 1}/${maxRetries})`);
        
        await new Promise(resolve => setTimeout(resolve, delay));
        continue;
      }
      
      if (isRateLimit) {
        const rateLimitError = new Error("Aether Neural Link Overloaded. Our systems are currently processing a high volume of designs. Please wait a moment for the neural quota to reset.");
        (rateLimitError as Error & { status?: number }).status = 429;
        throw rateLimitError;
      }

      if (isSafety) {
        const safetyError = new Error("Neural Safety Protocol Triggered. The requested synthesis contains parameters that violate Aether core directives. Please refine your design prompt.");
        (safetyError as Error & { status?: number }).status = 403;
        throw safetyError;
      }
      
      const generalError = new Error(`Neural Sync Error: ${errorMessage || "Connection to Aether core interrupted."}`);
      throw generalError;
    }
  }
  throw lastError;
}

export interface Idea {
  id?: string;
  idea: string;
  plan: string;
  code: string;
  field: string;
  difficulty?: string;
  estimatedCost?: string; // Now in BDT
  keyComponents?: string[];
  components?: { name: string; price: number; quantity: number; category: string }[];
  grabCadUrl?: string;
  thingiverseUrl?: string;
  originalPrompt?: string;
  userInputtedName?: string;
  research?: ResearchData;
  circuit?: CircuitData;
  modelData?: GeneratedModelData;
  synthesis?: string;
  image?: string;
}

export interface ResearchData {
  overview: string;
  applications: string[];
  challenges: string[];
  technologies: string[];
  references: string[];
  detailedAnalysis?: string;
  materialScience?: string;
  futureEvolution?: string;
  marketAnalysis?: string;
  regulatorySafety?: string;
  ethicalImplications?: string;
}

export interface CircuitData {
  description: string;
  connections: { from: string; to: string; via: string }[];
  textualSchematic: string;
}

export interface ModelResult {
  uid: string;
  name: string;
  embedUrl: string;
  thumbnailUrl: string | null;
  source?: string;
  downloadUrl?: string; // For Thingiverse or other sources
  isGenerated?: boolean;
  generatedData?: GeneratedModelData;
}

export interface GeneratedModelData {
  primitives: {
    type: "box" | "sphere" | "cylinder" | "torus";
    args: number[];
    position: [number, number, number];
    rotation?: [number, number, number];
    color: string;
    label: string;
    materialProperties?: {
      material: string;
      density?: string;
      tensileStrength?: string;
      conductivity?: string;
      purpose?: string;
    };
  }[];
}

function cleanJSON(text: string): string {
  // Remove markdown code blocks if present
  let cleaned = text.trim();
  if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "");
  }
  return cleaned;
}

export async function generateIdeas(prompt: string, advanced?: Record<string, string | number>): Promise<Idea[]> {
  try {
    const advancedContext = advanced ? `
      ADVANCED ENGINEERING CONSTRAINTS:
      - ARCHITECTURE_CLASS: ${advanced.architecture} (Strict adherence to this design philosophy required)
      - STABILITY_INDEX: ${advanced.stability}/100 (Higher means more rigid, lower means more agile/experimental)
      - MATERIAL_LATTICE: ${advanced.materialClass} (BOM must reflect components made of this material class)
      - NEURAL_INTEGRATION_DEPTH: ${advanced.neuralDepth}/100 (Higher means more AI/ML complexity, lower means base electronics)
    ` : "";

    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are the Aether Intelligence, a Senior Project Architect at Idea Forge.
      The user wants to explore ideas related to: "${prompt}".
      ${advancedContext}
      
      STRICT RELEVANCE MANTRA: Your mission is to provide 3 creative, highly accurate variations of the user's specific request. 
      - If the user provides a specific project (e.g. "Electronic Chessboard"), do NOT generate generic "Smart Home" or "Drone" ideas. Instead, generate 3 different types or architectural approaches to an "Electronic Chessboard".
      - Ensure the ideas are strictly anchored to the user's keywords.
      - Return EXACTLY THREE (3) project ideas.
      
      Requirements:
      1. For each idea, provide a unique title (idea), a concise technical plan (plan), example code (code), difficulty level, estimated cost in BDT, and a comprehensive Bill of Materials (BOM).
      The BOM must be realistic, including all necessary modules, connectors, power sources, and mounting hardware. Ensure each component has a correct category and quantity.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            ideas: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  idea: { type: Type.STRING },
                  plan: { type: Type.STRING },
                  code: { type: Type.STRING },
                  difficulty: { type: Type.STRING },
                  estimatedCost: { type: Type.STRING },
                  keyComponents: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  },
                  components: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        name: { type: Type.STRING },
                        price: { type: Type.NUMBER },
                        quantity: { type: Type.NUMBER },
                        category: { type: Type.STRING }
                      },
                      required: ["name", "price", "quantity", "category"]
                    }
                  }
                },
                required: ["idea", "plan", "code", "difficulty", "estimatedCost", "keyComponents", "components"]
              }
            }
          },
          required: ["ideas"]
        }
      }
    }));

    const data = JSON.parse(cleanJSON(response.text || "{}"));
    return (data.ideas || []).map((i: Idea) => {
      const searchQuery = encodeURIComponent(prompt);
      return { 
        ...i, 
        field: prompt,
        originalPrompt: prompt,
        userInputtedName: prompt,
        grabCadUrl: `https://grabcad.com/library?query=${searchQuery}`,
        thingiverseUrl: `https://www.thingiverse.com/search?q=${searchQuery}`
      };
    });
  } catch (error) {
    console.error("Gemini Error (generateIdeas):", error);
    throw error;
  }
}

export async function buildIdea(title: string, originalPrompt?: string, userInputtedName?: string): Promise<Idea | null> {
  try {
    const contextStr = originalPrompt && originalPrompt !== title 
      ? `Original User Requirement context: "${originalPrompt}"\nSpecific Project Focus: "${title}"`
      : `Project Focus: "${title}"`;

    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are a Senior Systems Engineer. Create a comprehensive, industrial-grade technical blueprint.
      
      ${contextStr}
      
      STRICT FIDELITY REQUIREMENT: You are FORBIDDEN from deviating from the user's core intent. 
      - If the user specified Raspberry Pi, do not use Arduino. 
      - If they asked for 5 motors, the BOM and Code must reflect exactly 5 motors. 
      - Every component in the BOM must be essential and logically linked to the project description.
      
      ZERO HALLUCINATION POLICY: Do not add "extra" features that weren't requested if they complicate or contradict the user's original design goal.
      
      Requirements:
      1. **Technical Step-by-Step Implementation Plan**:
         - Provide 40+ highly granular, professional steps.
         - **STRICT FORMATTING**: You MUST start every single step with the exact prefix "STEP_ID: " followed by the number and a colon, then the title. 
         - Example: "STEP_ID: 1: System Initialization..."
         - Each step MUST be on a new line with significant vertical space in your logical structure.
         - Organize into these mandatory phases:
           - PHASE I: SYSTEM ARCHITECTURE
           - PHASE II: MECHANICAL FABRICATION
           - PHASE III: ELECTRICAL INTEGRATION
           - PHASE IV: FIRMWARE ARCHITECTURE
           - PHASE V: SYSTEM INTEGRATION
           - PHASE VI: VALIDATION & VERIFICATION
           - PHASE VII: MAINTENANCE & SCALABILITY
      
      2. **Advanced Multi-System Source Code**:
         - Provide FULL, production-ready source code.
         - **ARDUINO COMPATIBILITY**: If this project uses sensors or actuators, the code MUST be written in Arduino C++ (ino format style) and be 100% ready to execute.
         - **SPACING & FORMATTING**: Use a clean, expanded coding style with consistent indentation (2 or 4 spaces) and double-newlines between functions for high readability and "space".
         - Use clear, professional headers: "/* === [SYSTEM COMPONENT NAME] === */".
         - Include exhaustive library imports, pin definitions, and thorough block comments for each logic section.
      
      3. **Estimated Cost**: Realistic total in BDT.
      4. **Industrial BOM**: Complete and exhaustive list with BDT prices, quantities, and specific categories. Include every screw, jumper wire, and microchip required for the assembly.
      
      5. **Primary Research Data**:
         - Overview: High-level technical summary.
         - Applications: 3-5 industrial or real-world use cases.
         - Challenges: 3-5 technical hurdles and mitigation strategies.
         - Technologies: Core hardware/software tech stack components.
         - DetailedAnalysis: An in-depth engineering breakdown of the project.
         - MaterialScience: Considerations for materials used (e.g., alloys, polymers, thermal properties).
         - FutureEvolution: How this project could scale or evolve in the next 5-10 years.
         - MarketAnalysis: Specific target demographics, potential industrial sectors, and competitive landscape.
         - RegulatorySafety: International standards (ISO, IEEE, CE), safety protocols, and certifications needed.
         - EthicalImplications: Analysis of societal impact, environmental footprint, and human-machine interaction ethics.
         - References: List of 3-5 real-world technical references or documentation links.
      
      6. **Synthesis**:
         - A 2-3 sentence high-level engineering synthesis of the project. Speak as 'Aether AI Core', describing the core technological breakthrough or synergy of the design in a professional, slightly futuristic tone.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            plan: { type: Type.STRING },
            code: { type: Type.STRING },
            estimatedCost: { type: Type.STRING },
            synthesis: { type: Type.STRING },
            components: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  price: { type: Type.NUMBER },
                  quantity: { type: Type.NUMBER },
                  category: { type: Type.STRING }
                },
                required: ["name", "price", "quantity", "category"]
              }
            },
            research: {
              type: Type.OBJECT,
              properties: {
                overview: { type: Type.STRING },
                applications: { type: Type.ARRAY, items: { type: Type.STRING } },
                challenges: { type: Type.ARRAY, items: { type: Type.STRING } },
                technologies: { type: Type.ARRAY, items: { type: Type.STRING } },
                detailedAnalysis: { type: Type.STRING },
                materialScience: { type: Type.STRING },
                futureEvolution: { type: Type.STRING },
                marketAnalysis: { type: Type.STRING },
                regulatorySafety: { type: Type.STRING },
                ethicalImplications: { type: Type.STRING },
                references: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["overview", "applications", "challenges", "technologies", "detailedAnalysis", "materialScience", "futureEvolution", "marketAnalysis", "regulatorySafety", "ethicalImplications", "references"]
            }
          },
          required: ["plan", "code", "estimatedCost", "components", "research", "synthesis"]
        }
      }
    }));

    const data = JSON.parse(cleanJSON(response.text || "{}"));
    const searchQuery = encodeURIComponent(userInputtedName || originalPrompt || title);
    return {
      idea: title,
      plan: data.plan || "No plan generated.",
      code: data.code || "// No code generated",
      estimatedCost: data.estimatedCost,
      components: data.components,
      research: data.research,
      synthesis: data.synthesis,
      field: "Custom",
      originalPrompt: originalPrompt || title,
      userInputtedName: userInputtedName || originalPrompt || title,
      grabCadUrl: `https://grabcad.com/library?query=${searchQuery}`,
      thingiverseUrl: `https://www.thingiverse.com/search?q=${searchQuery}`
    };
  } catch (error) {
    console.error("Gemini Error (buildIdea):", error);
    const searchQuery = encodeURIComponent(userInputtedName || originalPrompt || title);
    if ((error as { status?: number }).status === 429) {
      return {
        idea: title,
        plan: "Blueprint generation paused due to high demand. Please try again in a few moments for a detailed industrial-grade plan.",
        code: "// Source code synthesis delayed. Re-initialize neural link shortly.",
        estimatedCost: "TBD",
        components: [],
        field: "Custom",
        originalPrompt: originalPrompt || title,
        userInputtedName: userInputtedName || originalPrompt || title,
        grabCadUrl: `https://grabcad.com/library?query=${searchQuery}`,
        thingiverseUrl: `https://www.thingiverse.com/search?q=${searchQuery}`
      };
    }
    throw error;
  }
}

export async function chatWithAether(messages: { role: string, content: string }[], context?: { idea?: string; plan?: string; field?: string }): Promise<{ text: string; functionCall?: { name: string; args: Record<string, unknown> } }> {
  try {
    const contextDescription = context ? `
    PROJECT CONTEXT:
    - Title: ${context.idea || "N/A"}
    - Category: ${context.field || "N/A"}
    - Implementation Plan Summary: ${context.plan ? context.plan.substring(0, 500) + "..." : "N/A"}
    ` : "No specific project context provided.";

    const systemInstruction = `You are AETHER, a high-tech engineering and DIY project assistant. 
    You help users brainstorm, plan, and build complex projects. 
    Be concise, technical, and inspiring. 
    Always prioritize accuracy and physical feasibility in your technical advice.
    
    STRICT FIDELITY PROTOCOL:
    - Never generate "random" or "generic" advice. 
    - Every response must be surgically connected to the user's specific input and the current project context.
    - If a user specifies a piece of hardware, your advice MUST revolve around that hardware.
    - Do not hallucinate features or requirements that deviate from the user's stated intent.
    
    FORGING ABILITY:
    You have the ability to "forge" a new project idea into a full technical blueprint. 
    If a user asks you to "forge X", "build a plan for X", or if they describe a new project idea they want to realize, you should call the 'forgeProject' tool with a clear, concise prompt describing the project.
    
    VISUAL SYNTHESIS (IMAGE GENERATION):
    You can also generate high-fidelity technical illustrations, conceptual art, or architectural visualizations of projects.
    If the user asks to "generate an image of X", "show me a picture of X", "visualize X", or "illustrate X", call the 'generateImage' tool with a detailed visual prompt.
    
    ${contextDescription}`;

    const forgeProjectTool: FunctionDeclaration = {
      name: "forgeProject",
      description: "Triggers the creation of a full technical blueprint (forge) for a specific project idea.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          prompt: {
            type: Type.STRING,
            description: "A clear, detailed prompt describing the project to be forged."
          }
        },
        required: ["prompt"]
      }
    };

    const generateImageTool: FunctionDeclaration = {
      name: "generateImage",
      description: "Generates a conceptual illustration or technical visual of a project or system component.",
      parameters: {
        type: Type.OBJECT,
        properties: {
          prompt: {
            type: Type.STRING,
            description: "A detailed visual prompt for the image generation model (e.g. 'A futuristic bipedal robot with carbon fiber limbs, 8k resolution, technical blueprint style')."
          }
        },
        required: ["prompt"]
      }
    };

    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: messages.map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }]
      })),
      config: {
        systemInstruction,
        tools: [{ functionDeclarations: [forgeProjectTool, generateImageTool] }]
      }
    }));

    if (response.functionCalls && response.functionCalls.length > 0) {
      const call = response.functionCalls[0];
      return { 
        text: response.text || "Initializing Forge Sequence...", 
        functionCall: { name: call.name, args: call.args } 
      };
    }

    return { text: response.text || "I'm sorry, I couldn't process that." };
  } catch (error) {
    console.error("Gemini Error (chatWithAether):", error);
    return { text: "Connection to Aether core lost. Please try again." };
  }
}

export async function generateResearch(idea: string, plan: string): Promise<ResearchData> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are the Lead Scientific Officer at Aether Engineering Labs. Perform exhaustive technical research for: "${idea}".
      Plan: ${plan}
      
      Requirements:
      1. Technical Overview: Multi-paragraph engineering synthesis.
      2. Industrial Applications: 5 specific global scale use cases.
      3. Critical Challenges: 5 complex engineering roadblocks and technical solutions.
      4. Tech Stack & Standards: Comprehensive list of IEEE/ISO standards, protocols, and materials.
      5. Detailed Analysis: Deep dive into the physical or computational laws governing the project.
      6. Material Science: Specific alloys, polymers, or electronic substrates required.
      7. Future Evolution: Deployment roadmap for 2030 and beyond.
      8. Market Analysis: Demographics, industrial sectors, and adoption curves.
      9. Regulatory & Safety: Compliance protocols and international safety requirements.
     10. Ethical Implications: Societal and environmental impact assessment.
     11. References: 5 high-quality, real-world technical documentation names or whitepaper titles.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overview: { type: Type.STRING },
            applications: { type: Type.ARRAY, items: { type: Type.STRING } },
            challenges: { type: Type.ARRAY, items: { type: Type.STRING } },
            technologies: { type: Type.ARRAY, items: { type: Type.STRING } },
            detailedAnalysis: { type: Type.STRING },
            materialScience: { type: Type.STRING },
            futureEvolution: { type: Type.STRING },
            marketAnalysis: { type: Type.STRING },
            regulatorySafety: { type: Type.STRING },
            ethicalImplications: { type: Type.STRING },
            references: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["overview", "applications", "challenges", "technologies", "detailedAnalysis", "materialScience", "futureEvolution", "marketAnalysis", "regulatorySafety", "ethicalImplications", "references"]
        }
      }
    }));

    return JSON.parse(cleanJSON(response.text || "{}"));
  } catch (error) {
    console.error("Gemini Error (generateResearch):", error);
    return {
      overview: "Research data unavailable due to high demand or technical error. This project involves complex engineering principles and multi-disciplinary integration.",
      applications: ["Industrial Automation", "Consumer Electronics", "Research & Development", "Educational Tools", "Smart Infrastructure"],
      challenges: ["Power Efficiency", "Thermal Management", "Structural Integrity", "Software Reliability", "Cost Optimization"],
      technologies: ["Embedded Systems", "Wireless Communication", "Advanced Materials", "AI/ML Integration", "Cloud Connectivity"],
      references: ["IEEE Engineering Standards", "MIT OpenCourseWare", "NASA Technical Reports", "Official Component Datasheets", "Engineering Handbooks"]
    };
  }
}

export async function generateCircuit(idea: string, plan: string): Promise<CircuitData> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a highly accurate, zero-deviation circuit topology for: "${idea}".
      Plan context: ${plan}
      
      CRITICAL: The circuit MUST use the exact hardware mentioned in the project plan. If the plan mentions an ESP32, do not map connections for an Arduino.
      
      Provide:
      1. Technical description with voltage/current specs.
      2. Precise pin-to-pin mapping (e.g., "VCC -> 5V", "GND -> GND", "Sensor Data -> GPIO 14").
      3. Structured text schematic.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            description: { type: Type.STRING },
            connections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  from: { type: Type.STRING },
                  to: { type: Type.STRING },
                  via: { type: Type.STRING }
                },
                required: ["from", "to", "via"]
              }
            },
            textualSchematic: { type: Type.STRING }
          },
          required: ["description", "connections", "textualSchematic"]
        }
      }
    }));

    return JSON.parse(cleanJSON(response.text || "{}"));
  } catch (error) {
    console.error("Gemini Error (generateCircuit):", error);
    return {
      description: "Circuit schematic unavailable due to high demand or technical error. Typically involves a central MCU (Arduino/ESP32) connected to sensors via I2C/SPI and actuators via PWM/GPIO.",
      connections: [
        { from: "Main MCU", to: "Power Supply", via: "VCC/GND" },
        { from: "Sensors", to: "Main MCU", via: "I2C (SDA/SCL)" },
        { from: "Actuators", to: "Main MCU", via: "Digital/PWM Pins" }
      ],
      textualSchematic: "/* Schematic synthesis failed. Please retry. */"
    };
  }
}

// Removed Sketchfab/Thingiverse integration as per user request
export async function generateComponentInsight(projectName: string, componentName: string): Promise<{ tip: string; link?: string }> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are Aether AI Core. Provide a brief (1-2 sentence) industrial-grade optimization tip for the component "${componentName}" within the project "${projectName}". 
      Also provide a relevant search query or conceptual link.
      
      Format as JSON: { "tip": "...", "link": "..." }`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            tip: { type: Type.STRING },
            link: { type: Type.STRING }
          },
          required: ["tip", "link"]
        }
      }
    }));

    return JSON.parse(cleanJSON(response.text || "{}"));
  } catch (error) {
    console.error("Gemini Error (generateComponentInsight):", error);
    return { tip: "Analyzing material properties and structural synergy..." };
  }
}

export async function generate3DModelDescription(idea: string, plan: string): Promise<GeneratedModelData> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `You are an elite Lead Mechanical Design Engineer specializing in GrabCAD-quality industrial assemblies and parametric CAD synthesis. 
      Create a high-fidelity 3D parametric architecture for the project: "${idea}".
      Plan context: ${plan}
      
      Design the model as a complex mechanical assembly of 20-35 precise primitives. Every part must have a clear engineering purpose.
      
      ENGINEERING ASSEMBLY LOGIC:
      1. PRIMARY STRUCTURE: Design a rigid skeletal frame (Carbon Fiber / Aluminum) with cross-bracing and mount points.
      2. LOGIC & CONTROL: Include a multi-layered electronics stack (stacked PCBs with standoffs), IC packages, and protective shielding.
      3. POWER DELIVERY: Model high-density energy storage units (LiPo/Li-Ion packs), voltage regulators (Heatsinks), and terminal blocks.
      4. PROPULSION/ACTUATION: Accurately place motor housings, gearboxes, shafts, and mounting flanges.
      5. PRECISION SENSORS: Integrate specialized sensor pods (Optics, LiDAR, IMU) with clearly defined sensing orientations.
      
      CRITICAL ASSEMBLY RULES:
      - Coordinate System: [0,0,0] is the primary centroid of mass.
      - Mechanical Integration: Parts MUST be physically congruent. Use standoffs (cylinders) to connect PCBs (boxes). Use struts to connect frame plates.
      - Realistic Scale: Total assembly MUST fit within a 20x20x20 unit volume ([-10, -10, -10] to [10, 10, 10]). 
      - Geometry Precision: Specify dimensions and positions with millimeter precision (e.g. 0.08 for plates, 0.12 for wiring conduits).
      
      PART SPECIFICATIONS:
      - type: "box" | "sphere" | "cylinder" | "torus"
      - args: Numerical array matching the type (box: [w,h,d], sphere: [r], cylinder: [r_top, r_bot, h])
      - position: [x,y,z]
      - rotation: [x,y,z] in radians
      - color: Industrial hex colors (#1A1A1A, #111111, #065F46, #444444, #F59E0B, #CBD5E1)
      - label: EXACTLY ONE SEMANTIC ENGINEERING WORD (E.g. CHASSIS, MOTOR, STATOR, HEATSINK, PLATE). NO underscores, symbols or numbers.
      - materialProperties: { material: string, purpose: string }
      
      Think in terms of functional architecture and Bill of Materials (BOM) accuracy.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            primitives: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, enum: ["box", "sphere", "cylinder", "torus"] },
                  args: { type: Type.ARRAY, items: { type: Type.NUMBER } },
                  position: { type: Type.ARRAY, items: { type: Type.NUMBER }, minItems: 3, maxItems: 3 },
                  rotation: { type: Type.ARRAY, items: { type: Type.NUMBER }, minItems: 3, maxItems: 3 },
                  color: { type: Type.STRING },
                  label: { type: Type.STRING },
                  materialProperties: {
                    type: Type.OBJECT,
                    properties: {
                      material: { type: Type.STRING },
                      density: { type: Type.STRING },
                      tensileStrength: { type: Type.STRING },
                      conductivity: { type: Type.STRING },
                      purpose: { type: Type.STRING }
                    },
                    required: ["material", "purpose"]
                  }
                },
                required: ["type", "args", "position", "rotation", "color", "label", "materialProperties"]
              }
            }
          },
          required: ["primitives"]
        }
      }
    }));

    return JSON.parse(cleanJSON(response.text || '{"primitives": []}'));
  } catch (error) {
    console.error("Gemini Error (generate3DModelDescription):", error);
    return { primitives: [] };
  }
}

export async function generateImage(prompt: string): Promise<string | null> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    }));

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType || "image/png"};base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Gemini Error (generateImage):", error);
    return null;
  }
}

export async function generateSpeech(text: string, voice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr' = 'Kore'): Promise<string | null> {
  try {
    const response = await withRetry(() => ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice },
          },
        },
      },
    }));

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    return base64Audio || null;
  } catch (error) {
    console.error("Gemini Error (generateSpeech):", error);
    return null;
  }
}
