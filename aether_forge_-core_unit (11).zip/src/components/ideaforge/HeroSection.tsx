import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Search, Terminal, Cpu, Zap, Activity, Sliders, ChevronDown, ChevronUp, Layers, Wind, ShieldCheck, Database } from "lucide-react";

interface AdvancedOptions {
  architecture: "Industrial" | "Aerospace" | "Neural" | "Nano";
  stability: number; // 0 to 100
  materialClass: "Composite" | "Metallic" | "Crystal" | "Polymer";
  neuralDepth: number; // 0 to 100
  thermalProfile: "Cryogenic" | "Stable" | "Extreme";
  complexity: "Prototype" | "Standard" | "Elite";
}

interface HeroSectionProps {
  onForge: (prompt: string, isDirect?: boolean, customTitle?: string, advanced?: AdvancedOptions) => void;
  onOpenAdvanced: () => void;
  isLoading: boolean;
}

export const HeroSection = ({ onForge, onOpenAdvanced, isLoading }: HeroSectionProps) => {
  const [prompt, setPrompt] = useState("");
  const [isAdvanced, setIsAdvanced] = useState(false);
  const [advanced, setAdvanced] = useState<AdvancedOptions>({
    architecture: "Industrial",
    stability: 75,
    materialClass: "Composite",
    neuralDepth: 50,
    thermalProfile: "Stable",
    complexity: "Standard"
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onForge(prompt, false, undefined, isAdvanced ? advanced : undefined);
    }
  };

  const exampleTags = [
    "Autonomous Drone",
    "Smart Hydroponics",
    "Neural Interface",
    "Solar Tracker",
    "IoT Smart Lock",
    "Robotic Arm"
  ];

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 md:px-8 pt-20 overflow-hidden bg-background">
      {/* Dark Technical Atmosphere */}
      <div className="absolute inset-0 atmosphere opacity-100 pointer-events-none" />
      <div className="absolute inset-0 tech-grid opacity-30 pointer-events-none" />
      
      {/* Schematic Accents */}
      <div className="absolute top-0 left-0 w-full h-[30vh] border-b border-white/[0.03] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-full h-[40vh] border-t border-white/[0.03] pointer-events-none" />
      <div className="absolute left-[20%] top-0 w-px h-full bg-white/[0.03] pointer-events-none" />
      <div className="absolute right-[20%] top-0 w-px h-full bg-white/[0.03] pointer-events-none" />

      {/* Numerical Marking Accents */}
      <div className="absolute top-1/2 -translate-y-1/2 left-4 vertical-rl text-[9px] font-mono text-white/5 tracking-[1em] pointer-events-none">
        AETHER_FORGE_SYNTH_HUB
      </div>
      <div className="absolute top-1/2 -translate-y-1/2 right-4 vertical-rl text-[9px] font-mono text-white/5 tracking-[1em] pointer-events-none rotate-180">
        GEOMETRIC_ASSEMBLY_SYSTEM_v4.2
      </div>

      <div className="relative z-10 max-w-6xl w-full flex flex-col items-center">
        {/* Lab Unit Indicator */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center mb-8"
        >
          <div className="flex items-center gap-6 mb-4">
            <div className="h-[2px] w-12 bg-primary" />
            <span className="font-mono text-sm text-primary tracking-[0.6em] font-black phosphor-glow">ADVANCED_NEURAL_FORGE</span>
            <div className="h-[2px] w-12 bg-primary" />
          </div>
          <span className="text-[10px] font-mono tracking-[0.2em] text-white/30 uppercase font-black">STATION_TYPE: PARAMETRIC_FORGE_v4.2</span>
        </motion.div>

        {/* Industrial Engineering Title */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-16 relative"
        >
          <h1 className="text-[10vw] font-black tracking-tighter leading-none text-white uppercase flex flex-col items-center">
            <span className="phosphor-glow">Aether</span>
            <span className="opacity-10" style={{ WebkitTextStroke: '1px rgba(255,255,255,0.4)' }}>Forge_</span>
          </h1>
          
          <div className="absolute -top-12 -right-8 hidden lg:block">
            <div className="p-4 bg-primary text-black flex flex-col gap-1 rounded-none -rotate-2">
              <span className="text-[11px] font-mono font-black tracking-widest">CRITICAL_SYSTEM</span>
              <span className="text-[8px] font-mono uppercase tracking-[0.2em] leading-none text-left opacity-80">PROT: 0xDEADBEEF</span>
            </div>
          </div>
        </motion.div>

        {/* Drafting Interface */}
        <div className="w-full max-w-4xl space-y-4">
          <motion.form 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8 }}
            onSubmit={handleSubmit}
            className="w-full relative"
          >
            <div className="absolute -inset-1 border border-primary/20 rounded-none -z-10" />
            
            <div className="relative flex flex-col md:flex-row items-center bg-black border-2 border-primary rounded-none p-1 shadow-[20px_20px_0px_rgba(255,255,255,0.03)]">
              <div className="hidden md:flex pl-8 text-primary/40">
                <Terminal className="w-5 h-5" />
              </div>
              
              <input 
                type="text" 
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="INIT_NEURAL_PROMPT_SEQUENCE..."
                className="w-full bg-transparent border-none focus:outline-none py-8 md:py-12 px-8 text-white font-mono text-xs md:text-sm placeholder:text-white/10 uppercase tracking-[0.3em] font-medium"
                disabled={isLoading}
              />
              
              <div className="flex items-center gap-2 pr-1 w-full md:w-auto p-2 md:p-0">
                <button 
                  type="submit"
                  disabled={isLoading || !prompt.trim()}
                  className="flex-1 md:flex-none flex items-center justify-center gap-4 bg-primary text-black px-16 py-8 rounded-none font-sans font-black uppercase tracking-[0.2em] text-[14px] hover:invert transition-all disabled:opacity-50"
                >
                  {isLoading ? "FORGING..." : "EXEC_CODE"}
                  <Search className="w-4 h-4" />
                </button>
              </div>
            </div>
          </motion.form>

          {/* Dedicated Advanced Toggle Button */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="flex items-center justify-start gap-4 px-1"
          >
            <button
              onClick={() => setIsAdvanced(!isAdvanced)}
              className={`group flex items-center gap-4 px-6 py-4 border transition-all ${
                isAdvanced 
                ? "bg-primary text-black border-primary font-black" 
                : "bg-black/40 border-white/10 text-white/40 hover:border-primary/50 hover:text-primary"
              }`}
            >
              <Sliders className={`w-4 h-4 ${isAdvanced ? "animate-pulse" : ""}`} />
              <span className="font-mono text-[10px] uppercase tracking-[0.3em]">
                {isAdvanced ? "ADVANCED_PARAMETERS_ACTIVE" : "QUICK_ADVANCED_CONTROLS"}
              </span>
              {isAdvanced ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>

            <button
              onClick={onOpenAdvanced}
              className="group flex items-center gap-4 px-8 py-4 bg-primary/10 border-2 border-primary/40 hover:bg-primary hover:text-black hover:border-primary text-primary transition-all relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-primary/20 scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
              <Zap className="w-4 h-4 relative z-10 group-hover:scale-110 transition-transform" />
              <span className="font-mono text-[11px] uppercase tracking-[0.4em] font-black relative z-10 phosphor-glow">
                ADVANCED_FORGER
              </span>
            </button>
          </motion.div>

          {/* Advanced Forge Panel */}
          <AnimatePresence>
            {isAdvanced && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden bg-black border-x-2 border-b-2 border-primary/40 p-1"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-1 p-1 bg-primary/5">
                  {/* Architecture Class */}
                  <div className="bg-black/50 p-6 border border-white/5 space-y-4">
                    <div className="flex items-center gap-3 text-primary/60">
                      <Layers className="w-4 h-4" />
                      <span className="text-[10px] font-mono font-black uppercase tracking-[0.3em]">ARCHITECTURE_CLASS</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      {["Industrial", "Aerospace", "Neural", "Nano"].map((arch) => (
                        <button
                          key={arch}
                          onClick={() => setAdvanced(prev => ({ ...prev, architecture: arch as "Industrial" | "Aerospace" | "Neural" | "Nano" }))}
                          className={`py-3 px-1 text-[9px] font-mono font-bold uppercase transition-all border ${advanced.architecture === arch ? "bg-primary text-black border-primary" : "bg-white/5 text-white/40 border-transparent hover:border-white/10"}`}
                        >
                          {arch}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Material Stability */}
                  <div className="bg-black/50 p-6 border border-white/5 space-y-4">
                    <div className="flex items-center gap-3 text-primary/60">
                      <Wind className="w-4 h-4" />
                      <span className="text-[10px] font-mono font-black uppercase tracking-[0.3em]">STABILITY_RATING</span>
                    </div>
                    <input 
                      type="range" value={advanced.stability} 
                      onChange={(e) => setAdvanced(prev => ({ ...prev, stability: parseInt(e.target.value) }))}
                      className="w-full accent-primary bg-white/10 h-1 appearance-none cursor-pointer" 
                    />
                    <div className="flex justify-between font-mono text-[10px] text-white/20">
                      <span>LOW_RELIANCE</span>
                      <span className="text-primary">{advanced.stability}%</span>
                      <span>MAX_RIGID</span>
                    </div>
                  </div>

                  {/* Material Class */}
                  <div className="bg-black/50 p-6 border border-white/5 space-y-4">
                    <div className="flex items-center gap-3 text-primary/60">
                      <ShieldCheck className="w-4 h-4" />
                      <span className="text-[10px] font-mono font-black uppercase tracking-[0.3em]">MATERIAL_LATTICE</span>
                    </div>
                    <select 
                      value={advanced.materialClass}
                      onChange={(e) => setAdvanced(prev => ({ ...prev, materialClass: e.target.value as "Composite" | "Metallic" | "Crystal" | "Polymer" }))}
                      className="w-full bg-white/5 border border-white/10 py-3 px-4 text-[10px] font-mono text-white/80 uppercase outline-none focus:border-primary transition-all"
                    >
                      {["Composite", "Metallic", "Crystal", "Polymer"].map(m => (
                        <option key={m} value={m} className="bg-black text-white">{m}</option>
                      ))}
                    </select>
                  </div>

                  {/* Neural Depth */}
                  <div className="bg-black/50 p-6 border border-white/5 space-y-4">
                    <div className="flex items-center gap-3 text-primary/60">
                      <Database className="w-4 h-4" />
                      <span className="text-[10px] font-mono font-black uppercase tracking-[0.3em]">NEURAL_DEPTH</span>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                        <div className="h-full bg-primary phosphor-glow transition-all duration-300" style={{ width: `${advanced.neuralDepth}%` }} />
                      </div>
                      <span className="text-[12px] font-mono text-primary font-bold min-w-[3ch]">{advanced.neuralDepth}</span>
                    </div>
                    <div className="flex gap-1">
                      {[10, 25, 50, 75, 100].map((v) => (
                        <button 
                          key={v}
                          onClick={() => setAdvanced(prev => ({ ...prev, neuralDepth: v }))}
                          className={`flex-1 py-1 text-[8px] font-mono border ${advanced.neuralDepth === v ? "bg-primary/20 border-primary text-primary" : "bg-white/5 border-transparent text-white/20"}`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Example Tags */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 flex flex-wrap justify-center gap-4"
        >
          {exampleTags.map((tag) => (
            <button
              key={`example-${tag}`}
              onClick={() => setPrompt(tag)}
              className="text-[10px] font-mono tracking-widest text-primary/40 uppercase px-4 py-2 border border-primary/10 rounded-none hover:bg-primary/10 hover:text-primary transition-all"
            >
              &gt; {tag.replace(/\s+/g, '_')}
            </button>
          ))}
        </motion.div>
      </div>

      {/* Bottom Accents */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      <div className="absolute bottom-8 left-8 flex items-center gap-4 text-[8px] font-mono text-white/20 uppercase tracking-[0.3em]">
        <div className="w-12 h-px bg-white/10" />
        <span>Aether_Forge_v4.2.1</span>
      </div>
    </section>
  );
};
