import { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { 
  ArrowLeft, 
  Box, 
  ListChecks, 
  Code2, 
  Layers, 
  Cpu, 
  ExternalLink, 
  ArrowRight,
  Settings,
  Zap,
  Globe,
  BookOpen,
  Volume2,
  Sparkles,
  MessageSquare,
  Activity,
  X,
  type LucideIcon,
  Cloud
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";

import { Idea, generate3DModelDescription, generateComponentInsight, type GeneratedModelData } from "@/services/geminiService";
import { saveProject } from "@/services/projectService";
import { playAetherVoice } from "@/lib/audio";
import { toast } from "sonner";
import { useAuth } from "@/hooks/use-auth";
import { db, serverTimestamp, handleFirestoreError, OperationType } from "@/lib/firebase";
import { Logo } from "./Logo";
import { Scene3D } from "./Scene3D";
import { CircuitDiagram } from "./CircuitDiagram";
import { ComponentBOM } from "./ComponentBOM";
import { ProjectResearch } from "./ProjectResearch";
import { CORE_UNIT_BLUEPRINT } from "./ExplodableModel";

interface ProjectDetailProps {
  idea: Idea;
  onClose: () => void;
  onUpdateIdea: (updatedIdea: Idea) => void;
  isLoading?: boolean;
  onAskAether?: (prompt: string) => void;
  allProjects?: Idea[];
  onSelectProject?: (idea: Idea) => void;
  onAdvancedForge?: () => void;
}

export function ProjectDetail({ 
  idea, 
  onClose, 
  onUpdateIdea, 
  isLoading, 
  onAskAether, 
  allProjects = [], 
  onSelectProject,
  onAdvancedForge
}: ProjectDetailProps) {
  const [explodeFactor, setExplodeFactor] = useState(0);
  const [autoRotate, setAutoRotate] = useState(true);
  const [showGrid, setShowGrid] = useState(true);
  const [wireframe, setWireframe] = useState(false);
  const [ghost, setGhost] = useState(false);
  const [simulationActive, setSimulationActive] = useState(false);
  const [spreadMode, setSpreadMode] = useState<'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID'>('GRID');
  const [generatedModel, setGeneratedModel] = useState<GeneratedModelData | null>(null);
  const [isGeneratingModel, setIsGeneratingModel] = useState(false);
  const [activeTab, setActiveTab] = useState<"cad" | "plan" | "code" | "bom" | "research" | "circuit">("cad");
  const [showCoreUnit, setShowCoreUnit] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isBooting, setIsBooting] = useState(true);
  const [bootStatus, setBootStatus] = useState("INITIALIZING_CORE");
  const [activeComponent, setActiveComponent] = useState<string | null>(null);
  const [componentInsight, setComponentInsight] = useState<{ tip: string; link?: string } | null>(null);
  const [isAnalyzingComponent, setIsAnalyzingComponent] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const scrollRef = useRef<HTMLElement>(null);

  // Reset scroll on tab change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [activeTab]);

  const filteredProjects = useMemo(() => {
    if (!projectSearch) return allProjects;
    return allProjects.filter(p => 
      p.idea.toLowerCase().includes(projectSearch.toLowerCase()) || 
      p.field.toLowerCase().includes(projectSearch.toLowerCase())
    );
  }, [allProjects, projectSearch]);

  const handleSaveToCloud = useCallback(async () => {
    if (!user) {
      toast.error("Protocol Error: Authentication required to save to cloud.");
      return;
    }

    setIsSaving(true);
    const success = await saveProject(idea, user.uid);
    if (success) {
      toast.success("Synthesis Saved: Cloud data synchronized.");
      onUpdateIdea({ ...idea, isSaved: true });
    }
    setIsSaving(false);
  }, [user, idea, onUpdateIdea]);

  // Analyze component on selection
  useEffect(() => {
    if (!activeComponent) {
      setComponentInsight(null);
      return;
    }

    const analyze = async () => {
      setIsAnalyzingComponent(true);
      try {
        const insight = await generateComponentInsight(idea.idea, activeComponent);
        setComponentInsight(insight);
      } catch (err: unknown) {
        console.error("Failed to analyze component", err);
        const errorObj = err as { message?: string; status?: number };
        const isQuota = errorObj?.message?.includes("Overloaded") || errorObj?.status === 429;
        if (isQuota) {
          setComponentInsight({ tip: "Neural link throttled. Analysis will resume in a moment." });
        }
      } finally {
        setIsAnalyzingComponent(false);
      }
    };

    analyze();
  }, [activeComponent, idea.idea]);

  // Voice Over Control
  const speakText = async (text: string) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    await playAetherVoice(text);
    // Rough estimate of speech duration or just enable after 5s
    setTimeout(() => setIsSpeaking(false), 5000);
  };
  const [hasStartedModelFetch, setHasStartedModelFetch] = useState(false);

  // Load state from localStorage on mount
  useEffect(() => {
    if (!idea) return;
    const savedState = localStorage.getItem(`aether_project_${idea.idea}`);
    if (savedState) {
      try {
        const state = JSON.parse(savedState);
        if (state.explodeFactor !== undefined) setExplodeFactor(state.explodeFactor);
        if (state.autoRotate !== undefined) setAutoRotate(state.autoRotate);
        if (state.showGrid !== undefined) setShowGrid(state.showGrid);
        if (state.wireframe !== undefined) setWireframe(state.wireframe);
        if (state.ghost !== undefined) setGhost(state.ghost);
        if (state.simulationActive !== undefined) setSimulationActive(state.simulationActive);
        if (state.spreadMode !== undefined) setSpreadMode(state.spreadMode);
        if (state.activeTab !== undefined) setActiveTab(state.activeTab);
      } catch (e) {
        console.error("Failed to load project state", e);
      }
    }
  }, [idea]);

  // Save state to localStorage on change
  useEffect(() => {
    if (!idea) return;
    const state = {
      explodeFactor,
      autoRotate,
      showGrid,
      wireframe,
      ghost,
      simulationActive,
      spreadMode,
      activeTab
    };
    localStorage.setItem(`aether_project_${idea.idea}`, JSON.stringify(state));
  }, [idea, explodeFactor, autoRotate, showGrid, wireframe, ghost, simulationActive, spreadMode, activeTab]);

  // Auto-Save Effect: Persist if the user stays for 8 seconds or if it's already a deep blueprint
  useEffect(() => {
    if (!user || idea.isSaved || !idea.plan || idea.plan.length < 500) return;

    const timer = setTimeout(() => {
      handleSaveToCloud();
    }, 8000); // 8 seconds of viewing a deep blueprint = intent to save

    return () => clearTimeout(timer);
  }, [idea.idea, idea.plan, idea.isSaved, user, handleSaveToCloud]);

  // Improved Booting Logic: Only complete when all data is ready
  useEffect(() => {
    if (!isLoading && !isGeneratingModel && generatedModel) {
      setBootStatus("SYNTHESIS_COMPLETE");
      const timer = setTimeout(() => setIsBooting(false), 400); // Reduced artificial delay
      return () => clearTimeout(timer);
    }

    if (isLoading) {
      // Rotate through more granular status updates
      const statuses = ["FORGING_BLUEPRINT", "SYNTHESIZING_VECTORS", "MAPPING_NEURAL_NODES"];
      const interval = setInterval(() => {
        setBootStatus(prev => {
          const idx = statuses.indexOf(prev);
          return statuses[(idx + 1) % statuses.length];
        });
      }, 2000);
      return () => clearInterval(interval);
    } else if (isGeneratingModel) {
      setBootStatus("SPATIAL_CALIBRATION");
    }
  }, [isLoading, isGeneratingModel, generatedModel]);

  useEffect(() => {
    if (!idea) return;
    
    // If we're currently loading the blueprint, don't try to fetch models yet
    // unless we already have one cached
    if (isLoading && !idea.modelData) return;
    
    // If we already have model data, or are already fetching, skip
    if (idea.modelData || hasStartedModelFetch) {
      if (idea.modelData && !generatedModel) {
        setGeneratedModel(idea.modelData);
      }
      return;
    }

    const fetchModels = async () => {
      setHasStartedModelFetch(true);
      setGeneratedModel(null);
      setIsGeneratingModel(true);
      
      try {
        const gen = await generate3DModelDescription(idea.idea, idea.plan);
        setGeneratedModel(gen);
        // Save the model data into a new copy of the idea for persistence
        onUpdateIdea({ ...idea, modelData: gen });
      } catch (error) {
        console.error("Failed to generate 3D model:", error);
        setHasStartedModelFetch(false); // Enable retry on error
      } finally {
        setIsGeneratingModel(false);
      }
    };

    fetchModels();
  }, [idea, onUpdateIdea, hasStartedModelFetch, isLoading, generatedModel]);

  const [isFullscreen, setIsFullscreen] = useState(false);

  if (!idea) return null;

  const handleDownloadCAD = () => {
    if (!generatedModel) return;
    const blob = new Blob([JSON.stringify(generatedModel, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${idea.idea.replace(/\s+/g, "_")}_CAD_Data.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const allSteps = idea.plan.split(/\n\s*(?:STEP_ID:\s*\d+:\s*|Step\s+\d+:\s*|\d+[.)]\s*|Phase\s+\d+:\s*)/i)
    .map(s => s.trim())
    .filter(s => s.length > 0)
    .map(s => s.replace(/^(?:PHASE\s+[IVXLCDM]+:?\s*)/i, '').trim()); // Clean up residual phase labels
  
  if (allSteps.length > 0) {
    allSteps[0] = allSteps[0].replace(/^(?:STEP_ID:\s*\d+:\s*|Step\s+\d+:\s*|\d+[.)]\s*|Phase\s+\d+:\s*)/i, '');
  }

  // Fullscreen only on initial boot.
  // isLoading during blueprint synth is non-blocking to allow viewing existing data.
  if (isBooting) {
    return (
      <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-6 md:p-8 text-center overscroll-contain">
        <div className="tech-grid absolute inset-0 opacity-10" />
        <div className="relative mb-8 transform scale-50 opacity-80">
          <Logo />
        </div>
        
        <div className="max-w-xs w-full space-y-6 relative z-10">
          <div className="space-y-2">
            <h2 className="text-lg font-sans font-black text-white uppercase tracking-[0.4em] animate-pulse">
              {bootStatus}
            </h2>
            <p className="text-[8px] font-mono text-primary uppercase tracking-[0.3em] font-black opacity-60">
              SYS_PROC: {isLoading ? "BLUEPRINT_SYNTH" : isGeneratingModel ? "TOPOLOGY_CALIB" : "NEURAL_HANDSHAKE"}
            </p>
          </div>

          <div className="bg-black border border-primary/10 p-4 rounded-none font-mono text-[8px] text-left space-y-2 h-32 overflow-hidden relative opacity-70">
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent pointer-events-none" />
            <div className="space-y-1 opacity-80">
              <div className="text-primary font-black">[KERNEL] V_UNIT: 722_ARC_STABLE</div>
              <div className="text-primary/60 truncate"> &gt; SECTOR_SCAN: {idea.idea.toUpperCase()}</div>
              <div className="text-primary/40 truncate"> &gt; FIELD_SYNC: {idea.field.toUpperCase()}</div>
              <div className="text-white/20"> &gt; BLUPRINT_PROC: {isLoading ? "RUNNING..." : "OK"}</div>
              <div className="text-white/20"> &gt; CAD_SPATIAL: {isGeneratingModel ? "LOCKING..." : (generatedModel ? "LOCKED" : "WAIT")}</div>
              {!isLoading && !isGeneratingModel && <div className="text-primary font-black mt-2"> &gt; SYSTEM_READY_FOR_ENGAGEMENT</div>}
            </div>
          </div>

          <div className="w-full h-0.5 bg-white/5 rounded-none overflow-hidden">
            <motion.div 
              initial={{ width: "0%" }}
              animate={{ width: (!isLoading && !isGeneratingModel && generatedModel) ? "100%" : isLoading ? "45%" : "85%" }}
              transition={{ duration: 1.5, ease: "linear" }}
              className="h-full bg-primary phosphor-glow"
            />
          </div>
          <p className="text-[7px] font-mono text-white/10 uppercase tracking-[0.6em] animate-pulse font-black">
            AUTORUN_SEQUENCE_09
          </p>
        </div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[150] bg-[#0c0c0e] flex flex-col overflow-hidden selection:bg-primary/30"
    >
      {/* Dark Technical Top Bar */}
      <header className="z-50 bg-black border-b-2 border-primary px-6 h-20 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-6">
          <Tooltip>
            <TooltipTrigger asChild>
              <button 
                onClick={onAdvancedForge}
                className="p-3 bg-white/5 border border-white/10 text-white/40 hover:text-primary hover:border-primary/50 transition-all group relative overflow-hidden"
                disabled={isLoading}
              >
                <Zap className="w-5 h-5 group-hover:scale-110 transition-transform" />
                <motion.div 
                  className="absolute inset-0 bg-primary/20 scale-x-0 group-hover:scale-x-100 transition-transform origin-left"
                />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>ADVANCED_FORGER</p>
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <button
                onClick={onClose}
                className="p-3 bg-white/5 border border-white/10 hover:bg-red-500 hover:text-black transition-all"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>TERMINATE_SESSION</p>
            </TooltipContent>
          </Tooltip>
          
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <div className={`w-1.5 h-1.5 ${isLoading ? "bg-amber-500" : "bg-primary"} animate-pulse`} />
              <span className="text-[9px] font-mono font-black text-primary uppercase tracking-[0.4em] phosphor-glow">ADVANCED_SYNTHESIS_FORGE</span>
            </div>
            <h2 className="text-2xl font-black text-white uppercase tracking-tighter truncate max-w-[200px] md:max-w-2xl">
              {idea.idea}
            </h2>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <Tooltip>
            <TooltipTrigger asChild>
              <button 
                onClick={() => speakText(`Analyzing current schematic: ${idea.idea}. Neural handshake stable.`)}
                disabled={isSpeaking}
                className={`p-3 border border-white/10 transition-all ${isSpeaking ? "bg-primary text-black" : "text-white/40 hover:text-white hover:bg-white/5"}`}
              >
                <Volume2 className="w-4 h-4" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>AUDIO_RELAY</p>
            </TooltipContent>
          </Tooltip>

          <button
            onClick={handleSaveToCloud}
            disabled={isSaving || (idea.isSaved && !!user)}
            className={`flex items-center gap-3 px-8 py-3 text-[11px] font-black uppercase tracking-[0.2em] border-2 transition-all ${
              idea.isSaved && user
                ? "bg-primary/10 border-primary text-primary cursor-default" 
                : "bg-primary text-black border-primary hover:bg-black hover:text-primary"
            }`}
          >
            {isSaving ? (
              <div className="w-4 h-4 border-2 border-current border-t-transparent animate-spin" />
            ) : idea.isSaved && user ? (
              <Cloud className="w-4 h-4" />
            ) : (
              <Sparkles className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">
              {idea.isSaved && user ? "SYNCED" : "COMMIT_DATA"}
            </span>
          </button>
          
          <button
            onClick={() => onAskAether?.("Explain the core logic and synthesis of this project.")}
            className="flex items-center gap-3 px-6 py-3 bg-primary text-black border-2 border-primary hover:bg-black hover:text-primary transition-all group"
          >
            <div className="w-2 h-2 bg-black group-hover:bg-primary transition-colors" />
            <span className="text-[11px] font-mono font-black tracking-widest uppercase">
              CONSULT_AETHER
            </span>
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        <Tabs 
          value={activeTab} 
          onValueChange={(v) => setActiveTab(v as typeof activeTab)} 
          className="flex-1 flex flex-col md:flex-row h-full w-full"
        >
          {/* Brutalist Navigation Sidebar using TabsList */}
          <TabsList className="w-20 md:w-80 shrink-0 bg-card border-r border-white/5 flex flex-col h-full rounded-none justify-start p-0 relative overflow-hidden">
            <div className="absolute inset-0 tech-grid opacity-10 pointer-events-none" />
            
            <ScrollArea className="flex-1 w-full relative z-10 p-2 md:p-4">
              <div className="space-y-8">
                {/* Search Section */}
                <div className="hidden md:flex flex-col w-full space-y-4">
                  <div className="space-y-1 px-2">
                    <div className="flex justify-between items-center px-1">
                      <span className="text-[9px] font-mono text-primary uppercase tracking-[0.3em] font-black">REGISTRY_FINDER</span>
                      <Activity className="w-3 h-3 text-primary/40" />
                    </div>
                    <input 
                      type="text" 
                      value={projectSearch}
                      onChange={(e) => setProjectSearch(e.target.value)}
                      placeholder="SEARCH_NODES..."
                      className="w-full bg-black border border-white/10 px-4 py-2 text-[10px] font-mono text-white placeholder:text-white/10 focus:border-primary outline-none transition-all"
                    />
                  </div>

                  {projectSearch && (
                    <div className="border border-white/5 bg-black/40 p-2 space-y-1">
                      {filteredProjects.map((p, i) => (
                        <button
                          key={`search-res-${p.id || 'p'}-${i}-${p.idea.substring(0, 5)}`}
                          onClick={() => onSelectProject?.(p)}
                          className={`w-full text-left p-2 border-l-2 transition-all ${p.idea === idea.idea ? "bg-primary/20 border-primary text-primary" : "bg-white/2 border-white/5 text-white/40 hover:bg-white/10 hover:text-white"}`}
                        >
                          <p className="text-[9px] font-black uppercase truncate">{p.idea}</p>
                          <p className="text-[7px] font-mono opacity-40 uppercase">{p.field}</p>
                        </button>
                      ))}
                      {filteredProjects.length === 0 && (
                        <p className="text-[8px] font-mono text-white/10 uppercase p-4 text-center">NO_MATCHES_FOUND</p>
                      )}
                    </div>
                  )}
                </div>

                <div className="hidden md:block w-full">
                  <Card className="rounded-none border-white/10 bg-black/40 shadow-[12px_12px_0px_rgba(0,0,0,0.4)]">
                    <CardContent className="p-5 space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-[9px] font-mono text-white/20 uppercase tracking-widest font-black">PROC_LOAD</span>
                        <span className="text-[10px] font-mono text-primary font-black phosphor-glow">98.4%</span>
                      </div>
                      <div className="h-0.5 bg-white/5 overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: "98.4%" }} className="h-full bg-primary" />
                      </div>
                      <div className="flex justify-between items-center text-[8px] font-mono text-white/10 uppercase tracking-tighter">
                        <span>Logic_Core</span>
                        <span className="text-primary/60">Stable</span>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                <div className="flex flex-col gap-4">
                  {[
                    { id: "cad", label: "Model", desc: "SPATIAL_TOPOLOGY", icon: Box },
                    { id: "plan", label: "Execution", desc: "SYNTHESIS_STAGES", icon: ListChecks },
                    { id: "code", label: "Logic", desc: "CORE_SEQUENCE", icon: Code2 },
                    { id: "circuit", label: "Circuits", desc: "FLOW_TOPOLOGY", icon: Zap },
                    { id: "bom", label: "Components", desc: "ATOMIC_REGISTRY", icon: Layers },
                    { id: "research", label: "Research", desc: "REFERENCE_DRAFTS", icon: BookOpen }
                  ].map((tab, idx) => (
                    <TabsTrigger 
                      key={`tab-trigger-${tab.id}-${idx}-${idea.id || 'curr'}`}
                      value={tab.id}
                      className="w-full group relative flex items-center gap-4 p-5 transition-all duration-200 border-2 bg-black border-white/5 text-white/40 data-[state=active]:bg-primary data-[state=active]:border-primary data-[state=active]:text-black hover:border-primary/40 hover:text-white rounded-none"
                    >
                      <div className="shrink-0 w-6 h-6 flex items-center justify-center">
                        <tab.icon className="w-5 h-5" />
                      </div>
                      
                      <div className="hidden md:flex flex-col items-start uppercase text-left">
                        <span className="text-[12px] font-black tracking-widest leading-none">
                          {tab.label}
                        </span>
                        <span className="text-[8px] font-mono tracking-tighter opacity-60 mt-1">
                          {tab.desc}
                        </span>
                      </div>
                    </TabsTrigger>
                  ))}
                </div>
              </div>
            </ScrollArea>

            <div className="mt-auto hidden md:block w-full p-4 relative z-10 border-t border-white/5">
              <Card className="rounded-none border-white/5 bg-black/40">
                <CardContent className="p-4 space-y-2">
                  <div className="flex items-center gap-2">
                    <Settings className="w-3 h-3 text-primary animate-spin-slow" />
                    <span className="text-[8px] font-mono font-bold text-primary uppercase tracking-[0.3em]">System_Log</span>
                  </div>
                  <p className="text-[9px] text-white/10 font-mono leading-tight uppercase">
                    Aether_Core_v4.2 - Neural session locked to current drafting workstation.
                  </p>
                </CardContent>
              </Card>
            </div>
          </TabsList>

        {/* Main Drafting Canvas */}
        <main ref={scrollRef} className="flex-1 overflow-y-auto scroll-smooth custom-scrollbar relative bg-background">
          {/* Canvas Background Elements */}
          <div className="absolute inset-0 tech-grid opacity-20 pointer-events-none" />
          <div className="absolute top-0 right-0 p-8 text-[7px] font-mono text-white/10 vertical-rl tracking-[1em] pointer-events-none">
            DESIGN_SYNTHESIS_HUB_0722_REV_A
          </div>
          
            <div className="max-w-6xl mx-auto px-6 py-16 md:px-12 relative z-10">
              <AnimatePresence mode="wait">
                {activeTab === "cad" && (
                  <motion.div
                    key="cad"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="space-y-16"
                  >
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 md:gap-16">
                      <div className={`lg:col-span-3 bg-black border-2 border-white/10 relative group overflow-hidden ${isFullscreen ? "fixed inset-0 z-[100] h-screen w-screen" : "h-[450px] md:h-[700px]"}`}>
                        <Scene3D 
                          activeField={null} 
                          selectedIdea={idea} 
                          explodeFactor={explodeFactor} 
                          generatedModelData={showCoreUnit ? CORE_UNIT_BLUEPRINT : generatedModel}
                          autoRotate={autoRotate}
                          showGrid={showGrid}
                          wireframe={wireframe}
                          ghost={ghost}
                          simulationActive={simulationActive}
                          spreadMode={spreadMode}
                          activeComponent={activeComponent}
                          onComponentSelect={(comp) => setActiveComponent(comp === activeComponent ? null : comp)}
                        />
                          
                          {/* Internal Technical Overlays */}
                          <div className="absolute top-8 left-8 flex flex-col gap-6 z-20">
                            {isGeneratingModel ? (
                              <div className="px-6 py-3 bg-black border-2 border-primary flex items-center gap-4 w-fit animate-pulse">
                                <div className="w-2.5 h-2.5 bg-primary animate-ping" />
                                <span className="text-[11px] font-mono font-black text-primary uppercase tracking-[0.4em]">
                                  SYNTHESIZING_3D_MODEL...
                                </span>
                              </div>
                            ) : (
                              <div className="px-6 py-3 bg-black border-2 border-primary/40 flex items-center gap-4 w-fit">
                                <div className="w-2.5 h-2.5 bg-primary/40" />
                                <span className="text-[11px] font-mono font-black text-primary/40 uppercase tracking-[0.4em]">
                                  {generatedModel ? "TOPOLOGY_STABLE" : "EXTERNAL_RENDER_ACTIVE"}
                                </span>
                              </div>
                            )}

                            <div className="flex flex-row md:flex-col border-2 border-white/10 bg-black">
                              {[
                                { id: "RE-GEN", label: "RE-GEN", state: isGeneratingModel, action: () => { setHasStartedModelFetch(false); setGeneratedModel(null); } },
                                { id: "ROTATE", label: "ROTATE", state: autoRotate, action: setAutoRotate },
                                { id: "WIRE", label: "WIRE", state: wireframe, action: setWireframe },
                                { id: "CORE", label: "CORE", state: showCoreUnit, action: setShowCoreUnit },
                                { id: "GRID", label: "GRID", state: showGrid, action: setShowGrid },
                                { id: "GHOST", label: "GHOST", state: ghost, action: setGhost },
                                { id: "SIMULATE", label: "SIMULATE", state: simulationActive, action: setSimulationActive },
                              ].map((ctrl, index) => (
                                <button
                                  key={`${ctrl.id}-${index}`}
                                  onClick={() => {
                                    if (ctrl.id === "RE-GEN") {
                                      setHasStartedModelFetch(false);
                                      setGeneratedModel(null);
                                    } else if (typeof ctrl.action === "function") {
                                      if (ctrl.id === "SIMULATE" || ctrl.id === "ROTATE" || ctrl.id === "WIRE" || ctrl.id === "GRID" || ctrl.id === "GHOST" || ctrl.id === "CORE") {
                                        (ctrl.action as (val: boolean) => void)(!ctrl.state);
                                      }
                                    }
                                  }}
                                  className={`px-8 py-4 text-[10px] font-mono font-black uppercase tracking-widest transition-all border-b border-white/5 last:border-0 ${
                                    ctrl.state ? (ctrl.label === "SIMULATE" ? "bg-amber-500 text-black shadow-[0_0_20px_rgba(245,158,11,0.5)]" : "bg-primary text-black") : "text-white/20 hover:text-white hover:bg-white/10"
                                  }`}
                                >
                                  {ctrl.label}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Refined Sliders using shadcn/ui Slider & Switch */}
                          <Card className="absolute bottom-4 right-4 md:bottom-6 md:right-6 bg-black/95 border-2 border-white/10 w-44 md:w-52 z-10 rounded-none overflow-hidden backdrop-blur-xl transition-all hover:border-primary/50 shadow-2xl">
                            <CardContent className="p-2 md:p-3 space-y-2">
                              <div className="space-y-1.5">
                                <div className="flex justify-between items-center">
                                  <Label className="text-[8px] font-mono font-black text-white/30 uppercase tracking-widest">EXPL_FCT</Label>
                                  <span className="text-primary font-mono text-[9px]">{(explodeFactor * 100).toFixed(0)}%</span>
                                </div>
                                <Slider 
                                  value={[explodeFactor]} 
                                  min={0} 
                                  max={1} 
                                  step={0.01} 
                                  onValueChange={(val) => setExplodeFactor(val[0])}
                                  className="py-0.5"
                                />
                              </div>

                              <Separator className="bg-white/5" />

                              <div className="space-y-1.5">
                                <Label className="text-[8px] font-mono font-black text-white/30 uppercase tracking-widest block">MODE</Label>
                                <Tabs value={spreadMode} onValueChange={(v) => setSpreadMode(v as typeof spreadMode)} className="w-full">
                                  <TabsList className="grid grid-cols-4 bg-white/5 h-6 p-0.5 rounded-none border border-white/10">
                                    <TabsTrigger value="RADIAL" className="text-[6px] font-mono data-[state=active]:bg-primary data-[state=active]:text-black rounded-none px-0">RAD</TabsTrigger>
                                    <TabsTrigger value="LINEAR" className="text-[6px] font-mono data-[state=active]:bg-primary data-[state=active]:text-black rounded-none px-0">LIN</TabsTrigger>
                                    <TabsTrigger value="COLUMN" className="text-[6px] font-mono data-[state=active]:bg-primary data-[state=active]:text-black rounded-none px-0">COL</TabsTrigger>
                                    <TabsTrigger value="GRID" className="text-[6px] font-mono data-[state=active]:bg-primary data-[state=active]:text-black rounded-none px-0">GRD</TabsTrigger>
                                  </TabsList>
                                </Tabs>
                              </div>

                              <div className="flex items-center justify-between">
                                <Label className="text-[8px] font-mono font-black text-white/30 uppercase tracking-widest">DRIVE</Label>
                                <Switch checked={autoRotate} onCheckedChange={setAutoRotate} size="sm" className="scale-50 origin-right -mr-2" />
                              </div>

                              <button 
                                onClick={() => { setExplodeFactor(0); setAutoRotate(true); }}
                                className="w-full py-1.5 bg-white/5 border border-white/10 text-[7px] font-mono font-black text-white/30 hover:bg-white hover:text-black transition-all uppercase tracking-widest"
                              >
                                RESET_POS
                              </button>
                            </CardContent>
                          </Card>

                          {/* Consultation Trigger - Refined for clarity */}
                          <div className="absolute bottom-8 left-8 z-20">
                            <button
                              onClick={() => onAskAether?.("I need architectural consultation for this model.")}
                              className="flex items-center gap-3 px-6 py-4 bg-primary text-black border-2 border-primary hover:bg-black hover:text-primary transition-all duration-300 font-black uppercase text-[11px] tracking-widest shadow-[12px_12px_0px_rgba(0,0,0,0.5)]"
                            >
                              <MessageSquare className="w-5 h-5" />
                              <span>CONSULT_AETHER</span>
                            </button>
                          </div>

                          {/* Global Controls */}
                          <div className="absolute top-8 right-8 flex gap-2">
                            <button
                              onClick={() => setIsFullscreen(!isFullscreen)}
                              className="w-14 h-14 flex items-center justify-center bg-black border-2 border-white/10 text-white/40 hover:text-white hover:border-primary transition-all font-mono text-[11px] font-black"
                            >
                              {isFullscreen ? "ESC" : "FULL"}
                            </button>
                            <button
                              onClick={handleDownloadCAD}
                              disabled={!generatedModel}
                              className="px-8 py-3 bg-primary text-black text-[12px] font-black uppercase tracking-widest hover:invert transition-all disabled:opacity-30"
                            >
                              EXPORT_DATA
                            </button>
                          </div>
                        </div>

                      {/* Analysis Insight Pane using shadcn Card */}
                <div className="lg:col-span-1 space-y-8">
                  <Card className="rounded-none border-white/5 bg-black shadow-[8px_8px_0_rgba(0,0,0,0.5)] relative overflow-hidden">
                    <div className="absolute -right-4 -top-4 w-24 h-24 bg-primary/5 rounded-full blur-3xl" />
                    <CardContent className="p-8 space-y-8">
                      <div className="flex items-center gap-3">
                        <div className="w-1.5 h-1.5 bg-primary phosphor-glow" />
                        <span className="text-[10px] font-mono font-bold text-primary uppercase tracking-widest">Topology_Report</span>
                      </div>
                      
                      <div className="space-y-4">
                        <div className="flex justify-between items-center text-[9px] font-mono text-white/20 uppercase font-bold">
                          <span>Stabilization</span>
                          <span className="text-primary">98%</span>
                        </div>
                        <Separator className="bg-white/5" />
                        <div className="flex justify-between items-center text-[9px] font-mono text-white/20 uppercase font-bold">
                          <span>Relativity</span>
                          <span className="text-primary">High</span>
                        </div>
                        <Separator className="bg-white/5" />
                        <div className="flex justify-between items-center text-[9px] font-mono text-white/20 uppercase font-bold">
                          <span>Sync_Key</span>
                          <span className="text-primary">0x722</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="rounded-none bg-primary border-none shadow-[8px_8px_0_rgba(0,0,0,0.6)]">
                     <CardContent className="p-8 space-y-6">
                       <div className="flex items-center gap-2 text-black">
                         <Cpu className="w-4 h-4" />
                         <span className="text-[10px] font-mono font-bold uppercase tracking-widest">Logic_Kernel</span>
                       </div>
                       <p className="text-[10px] font-mono leading-relaxed font-bold uppercase italic opacity-70 text-black">
                         Systematic architecture shows optimal performance for {idea.field} integration. Structural integrity and parametric offsets are synchronized.
                       </p>
                     </CardContent>
                  </Card>
                </div>
              </div>

              {/* Central Synthesis Card using shadcn Card */}
              <Card className="mt-16 bg-black border border-white/5 rounded-none p-12 shadow-[24px_24px_0px_rgba(0,0,0,0.6)] relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-12 opacity-5">
                  <Sparkles className="w-48 h-48 text-primary" />
                </div>
                
                <div className="absolute -bottom-6 right-16 flex flex-col opacity-10 -rotate-6 pointer-events-none select-none">
                  <span className="text-6xl font-black text-white uppercase tracking-tighter">FINAL_SPEC_ACTIVE</span>
                  <span className="text-2xl font-mono text-white text-right font-black">PROTOCOL_4.02</span>
                </div>

                <CardContent className="p-0 max-w-4xl space-y-10 relative z-10">
                  <div className="flex items-center gap-4">
                    <div className="w-3 h-3 bg-primary group-hover:rotate-45 transition-transform phosphor-glow" />
                    <span className="text-[12px] font-mono text-primary font-black uppercase tracking-[0.5em] phosphor-glow">Neural_Synthesis_Stream</span>
                  </div>

                  <div className="prose prose-invert prose-lg max-w-none text-white/40 font-mono uppercase tracking-tight leading-relaxed font-black">
                    <ReactMarkdown remarkPlugins={[remarkGfm]}>
                      {idea.synthesis || `Executing synthesis protocol for ${idea.idea}. Theoretical stabilization confirmed.`}
                    </ReactMarkdown>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-10 border-t-2 border-white/10">
                    {[
                      { icon: Zap, label: "Efficiency", val: "94.2%" },
                      { icon: Cpu, label: "Neural_Link", val: "Stable" },
                      { icon: Globe, label: "Scale", val: "Global" },
                      { icon: Layers, label: "Registry", val: "Active" }
                    ].map((stat, index) => {
                      const StatIcon = stat.icon;
                      return (
                        <div key={`stat-dtl-${stat.label}-${index}-${idea.id || 'id'}`} className="flex flex-col gap-2">
                          <div className="flex items-center gap-2 text-primary/40">
                            <StatIcon className="w-4 h-4" />
                            <span className="text-[9px] font-mono uppercase tracking-widest font-black">{stat.label}</span>
                          </div>
                          <span className="text-lg font-black text-white uppercase tracking-[0.2em]">{stat.val}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

                  {/* Component Insight Panel */}
                  <AnimatePresence mode="wait">
                    {activeComponent && (
                      <motion.div
                        key="comp-insight"
                        initial={{ opacity: 0, scale: 0.98 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        className="p-10 md:p-14 bg-black border-2 border-primary relative overflow-hidden group mb-12 shadow-2xl"
                      >
                        <button 
                          onClick={() => setActiveComponent(null)}
                          className="absolute top-6 right-6 p-2 bg-white/5 border border-white/10 hover:bg-red-500 hover:text-black transition-all z-[60]"
                        >
                          <X className="w-5 h-5" />
                        </button>
                        
                        <div className="absolute top-0 right-16 p-10 opacity-30">
                          <Zap className={`w-14 h-14 ${isAnalyzingComponent ? "text-primary animate-pulse" : "text-primary/20"}`} />
                        </div>
                        
                        <div className="space-y-8 relative z-10">
                          <div className="flex items-center gap-4">
                            <div className={`w-3 h-3 bg-primary ${isAnalyzingComponent ? "animate-ping" : ""}`} />
                            <span className="text-[11px] font-mono text-primary font-black uppercase tracking-[0.4em]">PROC_COMP_INSIGHT_LINK</span>
                          </div>
                          
                          <h3 className="text-2xl md:text-5xl font-black text-white uppercase tracking-tighter">
                            {activeComponent}
                          </h3>

                          {/* Dynamic Material Properties from AI Model Data */}
                          {generatedModel?.primitives.find(p => p.label === activeComponent)?.materialProperties && (
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-y border-white/10">
                              {[
                                { label: "Material", val: generatedModel.primitives.find(p => p.label === activeComponent)?.materialProperties?.material },
                                { label: "Density", val: generatedModel.primitives.find(p => p.label === activeComponent)?.materialProperties?.density },
                                { label: "Tensile", val: generatedModel.primitives.find(p => p.label === activeComponent)?.materialProperties?.tensileStrength },
                                { label: "Conductivity", val: generatedModel.primitives.find(p => p.label === activeComponent)?.materialProperties?.conductivity }
                              ].map((prop, index) => prop.val && (
                                <div key={`${prop.label}-${index}`} className="flex flex-col gap-1">
                                  <span className="text-[8px] font-mono text-white/30 uppercase tracking-widest">{prop.label}</span>
                                  <span className="text-[11px] font-mono text-primary font-black uppercase">{prop.val}</span>
                                </div>
                              ))}
                            </div>
                          )}
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                              <div className="flex items-center gap-2 text-primary/40 text-[9px] font-mono font-black uppercase tracking-widest">
                                <Activity className="w-3 h-3" />
                                Component_Metadata
                              </div>
                              {isAnalyzingComponent ? (
                                <div className="space-y-3">
                                  <div className="h-4 bg-white/5 animate-pulse w-full" />
                                  <div className="h-4 bg-white/5 animate-pulse w-5/6" />
                                  <div className="h-4 bg-white/5 animate-pulse w-2/3" />
                                </div>
                              ) : componentInsight ? (
                                <div className="prose prose-invert prose-lg max-w-none text-white/80 font-mono uppercase tracking-tight leading-relaxed">
                                  <ReactMarkdown remarkPlugins={[remarkGfm]}>
                                    {componentInsight.tip}
                                  </ReactMarkdown>
                                </div>
                              ) : (
                                <p className="text-white/20 font-mono text-xs italic uppercase">SYNTHESIS_DELAYED_RETRY_LINK...</p>
                              )}
                            </div>

                            <div className="space-y-6 flex flex-col justify-end">
                              <div className="grid grid-cols-1 gap-4">
                                <button
                                  onClick={() => {
                                    onAskAether?.(`Perform a deep architectural analysis on the ${activeComponent} system within the context of ${idea.idea}.`);
                                  }}
                                  className="w-full px-10 py-5 bg-primary text-black text-[12px] font-black uppercase tracking-[0.4em] hover:bg-white transition-all shadow-2xl flex items-center justify-between group"
                                >
                                  EXEC_DEEP_ANALYSIS
                                  <ArrowRight className="w-5 h-5 group-hover:translate-x-2 transition-transform" />
                                </button>
                                
                                {componentInsight?.link && (
                                  <a 
                                    href={`https://www.google.com/search?q=${encodeURIComponent(componentInsight.link)}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="w-full inline-flex items-center justify-between px-10 py-5 bg-black border border-white/10 text-[11px] font-black text-white/40 hover:text-white hover:border-primary transition-all uppercase tracking-[0.4em] group"
                                  >
                                    SYNC_EXTERNAL_DATASHEET
                                    <ExternalLink className="w-5 h-5 group-hover:scale-110 transition-transform" />
                                  </a>
                                )}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <div className="space-y-12">
                    <div className="space-y-6">
                      <SectionHeader 
                        title="Architecture" 
                        icon={Cpu} 
                        onAskAether={onAskAether}
                      />
                      <div className="p-10 bg-black border border-white/10 space-y-4">
                        <p className="text-sm text-muted-foreground leading-relaxed uppercase tracking-wide font-medium">
                          The architectural foundation of this construct is designed for maximum efficiency and aesthetic brilliance.
                        </p>
                      </div>
                    </div>
                    
                    <div className="space-y-6">
                      <SectionHeader title="References" icon={Globe} />
                      <div className="grid grid-cols-1 gap-px bg-white/10 border border-white/10">
                        <ReferenceCard 
                          title="GrabCAD" 
                          desc="Industrial CAD models" 
                          url={idea.grabCadUrl || `https://grabcad.com/library?query=${encodeURIComponent(idea.originalPrompt || idea.idea)}`} 
                        />
                        <ReferenceCard 
                          title="Thingiverse" 
                          desc="3D Printing blueprints" 
                          url={idea.thingiverseUrl || `https://www.thingiverse.com/search?q=${encodeURIComponent(idea.originalPrompt || idea.idea)}`} 
                        />
                      </div>
                    </div>

                    <button 
                      onClick={() => setActiveTab("plan")}
                      className="w-full py-6 border-2 border-white/20 hover:border-white hover:bg-white hover:text-black transition-all text-xs font-bold uppercase tracking-[0.3em] flex items-center justify-center gap-4 group"
                    >
                      Proceed to Execution Plan
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                    </button>
                  </div>
                </motion.div>
              )}

                {activeTab === "plan" && (
                  <motion.div
                    key="plan"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="max-w-4xl mx-auto space-y-12"
                  >
                      <SectionHeader title="Execution_Timeline" icon={ListChecks} onAskAether={onAskAether} />
                      <Card className="bg-black/60 border-white/10 rounded-none p-6 md:p-12 shadow-2xl relative overflow-hidden">
                        <div className="absolute inset-0 tech-grid opacity-5 pointer-events-none" />
                        <CardContent className="p-0 space-y-12 relative z-10">
                          {allSteps.map((step, i) => (
                            <div key={`step-${idea.id || 'id'}-${i}-${step.substring(0, 5)}`} className="flex gap-10 items-start group">
                              <div className="shrink-0 flex flex-col items-center gap-4">
                                <div className="w-12 h-12 border-2 border-primary/20 flex items-center justify-center text-[14px] font-mono font-black text-primary/40 group-hover:border-primary group-hover:text-primary transition-all duration-500 shadow-none group-hover:shadow-[0_0_15px_rgba(var(--primary),0.3)] font-black">
                                  {(i + 1).toString().padStart(2, '0')}
                                </div>
                                {i < allSteps.length - 1 && <div className="w-[1px] h-20 bg-white/10" />}
                              </div>
                              <div className="space-y-4 pt-1 flex-1">
                                <div className="flex items-center gap-3">
                                  <span className="text-[9px] font-mono text-primary uppercase tracking-[0.4em] font-bold">Protocol_Gate_{i + 1}</span>
                                  <div className="h-px flex-1 bg-gradient-to-r from-primary/30 to-transparent" />
                                </div>
                                <h4 className="text-xl font-black text-white/90 uppercase tracking-widest group-hover:text-primary transition-colors duration-500 font-black">{step.split(":")[0]}</h4>
                                <p className="text-white/40 leading-relaxed font-mono text-xs uppercase tracking-tight">{step.split(":")[1] || step}</p>
                                
                                <div className="pt-4 flex items-center gap-4">
                                  <button
                                    onClick={() => {
                                      onAskAether?.(`I have a question about Step ${i + 1}: ${step.split(":")[0]}. ${step.split(":")[1] || ""}`);
                                    }}
                                    className="flex items-center gap-3 px-6 py-3 bg-primary text-black border-2 border-primary text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-primary transition-all shadow-[8px_8px_0px_rgba(0,0,0,0.4)] font-black"
                                  >
                                    <MessageSquare className="w-4 h-4" />
                                    CONSULT_AETHER
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                {activeTab === "code" && (
                  <motion.div
                    key="code"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="max-w-5xl mx-auto space-y-12"
                  >
                      <SectionHeader title="Neural_Logic_Kernel" icon={Code2} onAskAether={onAskAether} />
                      <Card className="bg-black/60 border-white/10 rounded-none shadow-2xl overflow-hidden">
                        <div className="flex items-center justify-between p-6 border-b border-white/10 bg-white/5">
                          <div className="flex gap-2">
                            <div className="w-3 h-3 rounded-full bg-red-500/30" />
                            <div className="w-3 h-3 rounded-full bg-amber-500/30" />
                            <div className="w-3 h-3 rounded-full bg-green-500/30" />
                          </div>
                          <button
                            onClick={() => {
                              navigator.clipboard.writeText(idea.code);
                              toast.success("Code copied to neural link.");
                            }}
                            className="px-6 py-2 bg-primary/10 border border-primary/20 text-[10px] font-black text-primary uppercase tracking-widest hover:bg-primary hover:text-black transition-all font-black"
                          >
                            Copy_Source
                          </button>
                        </div>
                        <ScrollArea className="h-[600px] w-full p-8 bg-black/40">
                          <pre className="text-[12px] font-mono text-primary/80 uppercase tracking-tight leading-loose whitespace-pre-wrap">
                            {idea.code || "// [KERNEL]: Neural sequence missing. Forge required."}
                          </pre>
                        </ScrollArea>
                      </Card>
                    </motion.div>
                  )}

                {activeTab === "bom" && (
                  <motion.div
                    key="bom"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="max-w-5xl mx-auto space-y-12"
                  >
                      <SectionHeader title="Atomic_Registry" icon={Layers} onAskAether={onAskAether} />
                      <Card className="bg-black/60 border-white/10 rounded-none overflow-hidden shadow-2xl">
                        <CardContent className="p-0">
                          <ComponentBOM idea={idea} activeComponent={activeComponent} onComponentSelect={setActiveComponent} />
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                {activeTab === "research" && (
                  <motion.div
                    key="research"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="max-w-5xl mx-auto space-y-12"
                  >
                      <SectionHeader title="Theoretical_Base" icon={BookOpen} onAskAether={onAskAether} />
                      <Card className="bg-black/60 border-white/10 rounded-none p-6 md:p-12 shadow-2xl">
                        <CardContent className="p-0">
                          <ProjectResearch idea={idea} onUpdate={(r) => handleUpdate({ research: r })} />
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}

                {activeTab === "circuit" && (
                  <motion.div
                    key="circuit"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                    className="max-w-5xl mx-auto space-y-12"
                  >
                      <SectionHeader title="Electronic_Topology" icon={Zap} onAskAether={onAskAether} />
                      <Card className="bg-black/60 border-white/10 rounded-none p-6 md:p-12 shadow-2xl overflow-x-auto">
                        <CardContent className="p-0 min-w-[600px]">
                          <CircuitDiagram idea={idea} onUpdate={(c) => handleUpdate({ circuit: c })} />
                        </CardContent>
                      </Card>
                    </motion.div>
                  )}
              </AnimatePresence>
            </div>
        </main>
        </Tabs>
      </div>
    </motion.div>
  );
}

function SectionHeader({ 
  title, 
  icon: Icon, 
  onSpeak, 
  isSpeaking,
  onAskAether
}: { 
  title: string; 
  icon: LucideIcon; 
  onSpeak?: () => void; 
  isSpeaking?: boolean;
  onAskAether?: (prompt: string) => void;
}) {
  return (
    <div className="flex items-center gap-4 md:gap-6 mb-8 md:mb-12">
      <div className="w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl bg-primary/10 flex items-center justify-center text-primary flex-shrink-0">
        <Icon className="w-5 h-5 md:w-6 md:h-6" />
      </div>
      <div className="flex flex-col">
        <h3 className="text-lg md:text-2xl font-bold text-white tracking-tight uppercase leading-none">{title}</h3>
        <span className="text-[7px] font-mono text-slate-500 uppercase tracking-widest mt-1">Sector_Analysis: Stable</span>
      </div>
      <div className="h-px flex-1 bg-white/5" />
      <div className="flex items-center gap-2">
        {onAskAether && (
          <button
            onClick={() => {
              const promptMap: Record<string, string> = {
                "Architecture": "Explain the architectural advantages of this project's design.",
                "Bill_of_Materials": "Can you analyze the component choices in the BOM? Are there any alternatives?",
                "Project_Research": "Provide more context or recent breakthroughs related to the research topics found here.",
                "Circuit_Topology": "Explain the electronic safety and signal integrity of this circuit topology.",
                "Project_Execution_Plan": "What are the common pitfalls I should avoid during the execution of this plan?",
                "Neural_Logic_Source": "Analyze the main loop and safety checks in this code."
              };
              // @ts-expect-error - promptMap access
              const prompt = promptMap[title] || `Tell me more about the ${title.replace(/_/g, " ")} section.`;
              onAskAether(prompt);
            }}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-white/10 text-[9px] font-bold text-slate-400 hover:text-white transition-all uppercase tracking-widest bg-white/5"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Ask_Aether</span>
          </button>
        )}
        {onSpeak && (
          <button 
            onClick={(e) => { e.stopPropagation(); onSpeak(); }}
            disabled={isSpeaking}
            className={`p-2 md:p-3 rounded-lg md:rounded-xl border border-white/5 bg-white/5 hover:bg-white/10 transition-all ${isSpeaking ? "text-primary animate-pulse" : "text-slate-500 hover:text-white"}`}
          >
            <Volume2 className="w-4 h-4 md:w-5 md:h-5" />
          </button>
        )}
      </div>
    </div>
  );
}

function ReferenceCard({ title, desc, url }: { title: string; desc: string; url: string }) {
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className="p-6 md:p-8 glass-panel hover:bg-white/5 transition-all group flex items-center justify-between gap-4"
    >
      <div className="space-y-1">
        <h4 className="text-base md:text-lg font-bold text-white group-hover:text-primary transition-colors">{title}</h4>
        <p className="text-[10px] md:text-xs text-muted-foreground font-medium">{desc}</p>
      </div>
      <ArrowRight className="w-4 h-4 md:w-5 md:h-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-2 transition-all flex-shrink-0" />
    </a>
  );
}
