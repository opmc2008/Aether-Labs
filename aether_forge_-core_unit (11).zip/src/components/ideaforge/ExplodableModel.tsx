import React, { useRef, useState, useMemo, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Html, Line, Edges, Float, MeshDistortMaterial, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import { motion, AnimatePresence } from "motion/react";
import { GeneratedModelData } from "@/services/geminiService";

/**
 * AETHER CAD CORE v5.0 // TOTAL REVAMP
 * -----------------------------------
 * Industrial-grade parametric assembly system with high-fidelity 
 * materials and quadrants-based disassembly logic.
 */

interface ExplodableModelProps {
  projectType: string;
  explodeFactor: number;
  wireframe?: boolean;
  ghost?: boolean;
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}

interface ComponentMetadata {
  desc: string;
  material: string;
  voltage?: string;
  current?: string;
  specs: string[];
  note: string;
}

const COMPONENT_REGISTRY: Record<string, ComponentMetadata> = {
  "CHASSIS": { 
    desc: "Core Structural Assembly", 
    material: "6061-T6 Aluminum", 
    voltage: "GND",
    current: "0A",
    specs: ["Coating: Matte Black Anodized", "Density: 2.7 g/cm³"], 
    note: "Main structural backbone." 
  },
  "MCU": { 
    desc: "Neural Logic Array", 
    material: "Doped Silicon", 
    voltage: "3.3V / 5.0V", 
    current: "450mA",
    specs: ["Throughput: 800 MIPS", "Protocol: I2C/SPI"], 
    note: "System processing core." 
  },
  "PCB": { 
    desc: "Signal Routing Substrate", 
    material: "Rogers 4350B", 
    voltage: "1.8V - 12V",
    current: "Up to 5A",
    specs: ["Layers: 6-Layer Stackup", "TG: 170°C"], 
    note: "High-density interconnect." 
  },
  "BATTERY": { 
    desc: "Energy Storage Unit", 
    material: "Li-Ion Gen-3 Cells", 
    voltage: "14.8V Nominal", 
    current: "2200mAh / 45C",
    specs: ["Capacity: 32.5 Wh", "Max Discharge: 100A"], 
    note: "Primary power reservoir." 
  },
  "MOTOR": { 
    desc: "Brushless Drive Actuator", 
    material: "Neodymium / Copper", 
    voltage: "Max 25V", 
    current: "22A Peak",
    specs: ["RPM: 2400 KV", "Thrust: 1.2kg"], 
    note: "High-torque mechanical drive." 
  },
  "SENSOR": { 
    desc: "Environmental Transducer", 
    material: "MEMS Silicon", 
    voltage: "3.3V",
    current: "20mA",
    specs: ["Precision: 0.01°", "Sampling: 2kHz"], 
    note: "Environmental data acquisition." 
  },
  "FRAME": { 
    desc: "Rigid Structural Frame", 
    material: "Toray T700 Carbon Fiber", 
    specs: ["Vibration Damping: 0.85", "Modulus: 230 GPa"], 
    note: "Lightweight aerodynamic support." 
  },
  "SHIELD": { 
    desc: "EMI/RFI Protective Barrier", 
    material: "Nickel-Silver Alloy", 
    specs: ["Attenuation: -60dB", "Thickness: 0.2mm"], 
    note: "RF interference suppression." 
  },
  "HEATSINK": { 
    desc: "Thermal Dissipation Matrix", 
    material: "C11000 Copper", 
    specs: ["Area: 14500 mm²", "Thermal Cond: 390 W/mK"], 
    note: "Advanced thermal management." 
  },
};

/**
 * 0. ASSEMBLY PARTICLES
 */
function AssemblyParticles({ factor }: { factor: number }) {
  // Use useMemo with a stable seed-like logic or just accept the randomness for particles
  const points = useMemo(() => {
    const p = [];
    const seed = 0.5; // Dummy stable seed reference 
    for (let i = 0; i < 50; i++) {
      // Use a deterministic-ish pattern for the linter if it complains about purity
      const rx = Math.sin(i * 12.9898 + seed) * 43758.5453123 % 1;
      const ry = Math.sin(i * 78.233 + seed) * 43758.5453123 % 1;
      const rz = Math.sin(i * 54.321 + seed) * 43758.5453123 % 1;
      p.push(new THREE.Vector3(rx * 20 - 10, ry * 20 - 10, rz * 20 - 10));
    }
    return p;
  }, []);

  // Reduced visual noise by removing particles
  return (
    <group>
    </group>
  );
}

/**
 * 1. INDUSTRIAL MATERIAL REPOSITORY
 */
function TechnicalMaterial({ 
  color = "#ffffff", 
  transparent = false, 
  opacity = 1, 
  wireframe = false, 
  emissive = "#000000", 
  metalness = 0.5, 
  roughness = 0.5, 
  isHighlighted = false,
  simulationActive = false,
  explodeFactor = 0
}) {
  const materialRef = useRef<THREE.MeshPhysicalMaterial>(null!);

  useFrame((state) => {
    if (!materialRef.current) return;
    
    // Power pulse effect + Explosion Overload
    const pulse = Math.sin(state.clock.elapsedTime * 4) * 0.5 + 0.5;
    const explosionBoost = explodeFactor * 2.5;
    
    if (simulationActive) {
      materialRef.current.emissiveIntensity = isHighlighted ? 6 : (emissive === "#000000" ? pulse * 0.5 : 2 + pulse);
    } else {
      materialRef.current.emissiveIntensity = isHighlighted ? 8 : (emissive === "#000000" ? explosionBoost : 1 + explosionBoost + pulse * 0.2);
    }
  });

  return (
    <meshPhysicalMaterial 
      ref={materialRef}
      color={color}
      transparent={transparent}
      opacity={opacity}
      wireframe={wireframe}
      emissive={isHighlighted ? "#3b82f6" : emissive}
      emissiveIntensity={isHighlighted ? 6 : (emissive === "#000000" ? 0 : 2)}
      metalness={metalness}
      roughness={roughness}
      envMapIntensity={2}
      clearcoat={1}
      clearcoatRoughness={0.1}
      thickness={transparent ? 1 : 0}
      transmission={transparent ? 0.9 : 0}
    />
  );
}

/**
 * 2. COMPONENT WRAPPER (Visual Enhancer)
 */
function IndustrialPart({ 
  children, 
  color = "#888", 
  emissive = "#000", 
  transparent = false, 
  wireframe = false,
  isScanning = false,
  isHighlighted = false,
  simulationActive = false,
  explodeFactor = 0
}: { 
  children: React.ReactNode; 
  color?: string; 
  emissive?: string; 
  transparent?: boolean; 
  wireframe?: boolean;
  isScanning?: boolean;
  isHighlighted?: boolean;
  simulationActive?: boolean;
  explodeFactor?: number;
}) {
  return (
    <group>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child as React.ReactElement, {
            children: (
              <>
                {(child.props as { children?: React.ReactNode }).children}
                <TechnicalMaterial 
                  color={isScanning ? "#3b82f6" : color} 
                  emissive={isScanning ? "#3b82f6" : emissive} 
                  transparent={transparent} 
                  wireframe={wireframe} 
                  metalness={0.8}
                  roughness={0.2}
                  isHighlighted={isHighlighted}
                  simulationActive={simulationActive}
                  explodeFactor={explodeFactor}
                />
                <Edges color={isScanning || isHighlighted ? "#60a5fa" : (wireframe ? "#ffffff" : "#666666")} threshold={15} />
              </>
            )
          });
        }
        return child;
      })}
    </group>
  );
}

/**
 * CORE_UNIT_BLUEPRINT: A complex engineering module representing AETHER_FORGE synthesis.
 * Visualizes blueprints, parametric spatial modeling, and advanced computational lattice.
 */
export const CORE_UNIT_BLUEPRINT: GeneratedModelData = {
  primitives: [
    { type: "box", args: [4, 0.4, 4], position: [0, -0.6, 0], color: "#111", label: "HEAVY_CHASSIS", materialProperties: { material: "COMPOSITE_STEEL_BANTAM", purpose: "Primary load-bearing structural lattice." } },
    { type: "box", args: [2.5, 0.2, 2.5], position: [0, 0, 0], color: "#064e3b", label: "LOGIC_MOTHERBOARD", materialProperties: { material: "RO4350B_PCB", purpose: "High-speed signal routing and power distribution." } },
    { type: "cylinder", args: [0.8, 0.8, 1.4], position: [0, 0.8, 0], color: "#333", label: "THERMAL_CHAMBER", materialProperties: { material: "ACTIVE_COPPER_COOLANT", purpose: "Vapor-chamber based thermal dissipation." } },
    { type: "cylinder", args: [0.15, 0.15, 2.4], position: [1.8, 0.4, 1.8], color: "#444", label: "STRUCTURAL_STRUT", materialProperties: { material: "TITANIUM_GRADE_5", purpose: "Vertical rigidity and alignment." } },
    { type: "cylinder", args: [0.15, 0.15, 2.4], position: [-1.8, 0.4, 1.8], color: "#444", label: "STRUCTURAL_STRUT", materialProperties: { material: "TITANIUM_GRADE_5", purpose: "Vertical rigidity and alignment." } },
    { type: "cylinder", args: [0.15, 0.15, 2.4], position: [1.8, 0.4, -1.8], color: "#444", label: "STRUCTURAL_STRUT", materialProperties: { material: "TITANIUM_GRADE_5", purpose: "Vertical rigidity and alignment." } },
    { type: "cylinder", args: [0.15, 0.15, 2.4], position: [-1.8, 0.4, -1.8], color: "#444", label: "STRUCTURAL_STRUT", materialProperties: { material: "TITANIUM_GRADE_5", purpose: "Vertical rigidity and alignment." } },
    { type: "box", args: [0.5, 0.5, 0.8], position: [0, 1.6, 0], color: "#f59e0b", label: "SENSOR_POD", materialProperties: { material: "QUARTZ_SILICA", purpose: "Multi-spectral environmental telemetry." } },
  ]
};

/**
 * 3. KINEMATIC CLUSTERING ENGINE
 * Groups components logically for more meaningful explosions.
 */
function getComponentCluster(label: string): string {
  const l = label.toUpperCase();
  if (l.includes("PROP") || l.includes("ROTOR") || l.includes("MOTOR") || l.includes("ACTUATOR")) return "PROPULSION";
  if (l.includes("MCU") || l.includes("PCB") || l.includes("CONTROL") || l.includes("SENSOR") || l.includes("BRAIN")) return "ELECTRONICS";
  if (l.includes("BATT") || l.includes("CELL") || l.includes("SOLAR") || l.includes("POWER")) return "POWER";
  if (l.includes("FRAME") || l.includes("ARM") || l.includes("LEG") || l.includes("BODY")) return "STRUCTURE";
  return "AUXILIARY";
}

const CLUSTER_OFFSETS: Record<string, THREE.Vector3> = {
  PROPULSION: new THREE.Vector3(0, 1.5, 0),
  ELECTRONICS: new THREE.Vector3(0, 5, 0),
  POWER: new THREE.Vector3(0, -3, 0),
  STRUCTURE: new THREE.Vector3(0, -8, 0),
  AUXILIARY: new THREE.Vector3(0, 0, 0)
};

/**
 * 4. DISASSEMBLY PART REWORK
 * Uses Cluster Logic + Polar Expansion + Spring Physics
 */
function DisassemblyPart({
  children,
  basePosition = new THREE.Vector3(0, 0, 0),
  factor,
  isFocused,
  index = 0,
  totalParts = 1,
  label,
  onSelect,
  onHover,
  simulationActive = false,
  spreadMode = 'GRID'
}: {
  children: React.ReactNode;
  basePosition?: THREE.Vector3;
  factor: number;
  isFocused: boolean;
  index: number;
  totalParts?: number;
  label: string;
  onSelect?: (name: string) => void;
  onHover?: (hovering: boolean) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}) {
  const groupRef = useRef<THREE.Group>(null!);
  const cluster = useMemo(() => getComponentCluster(label), [label]);
  
  // Physics State
  const currentPos = useRef(basePosition.clone());
  const currentVelocity = useRef(new THREE.Vector3(0, 0, 0));

  const gridPosition = useMemo(() => {
    const size = Math.ceil(Math.sqrt(totalParts));
    const col = index % size;
    const row = Math.floor(index / size);
    const spacing = 5; // Equal distance slightly wider
    const offset = (size - 1) * spacing / 2;
    // Ground plane grid (Y=0)
    return new THREE.Vector3(col * spacing - offset, -2, row * spacing - offset);
  }, [index, totalParts]);

  const detonateDirection = useMemo(() => {
    if (spreadMode === 'GRID') {
      return gridPosition.clone().sub(basePosition);
    }
    // ... rest of detonateDirection logic
    if (spreadMode === 'COLUMN') return new THREE.Vector3(0, (index - 5) * 2, 0);
    if (spreadMode === 'LINEAR') return new THREE.Vector3((index - 5) * 4, 0, 0);
    
    // RADIAL (Cluster Based)
    const clusterOffset = CLUSTER_OFFSETS[cluster] || new THREE.Vector3(0, 0, 0);
    const radial = basePosition.clone().normalize();
    if (radial.length() < 0.1) radial.set(Math.cos(index), 1, Math.sin(index)).normalize();
    
    // Disarray logic moved inside here for radial only
    const angle = (index / 10) * Math.PI * 2;
    const radius = 2 + (index % 5);
    const disarray = new THREE.Vector3(Math.cos(angle) * radius, Math.sin(index) * 2, Math.sin(angle) * radius);
    
    return radial.multiplyScalar(15).add(clusterOffset.clone().multiplyScalar(2)).add(disarray);
  }, [basePosition, index, spreadMode, cluster, gridPosition]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    const t = state.clock.elapsedTime;
    const easedFactor = Math.pow(factor, 1.0); 
    
    // Target Position
    const targetPos = basePosition.clone().add(detonateDirection.clone().multiplyScalar(easedFactor));
    
    // Spring physics simulation
    const stiffness = 45.0; // Increased for faster response
    const damping = 0.8;
    const mass = 1.0;

    const force = new THREE.Vector3().subVectors(targetPos, currentPos.current).multiplyScalar(stiffness);
    const acceleration = force.divideScalar(mass);
    currentVelocity.current.add(acceleration.multiplyScalar(delta)).multiplyScalar(damping);
    currentPos.current.add(currentVelocity.current.clone().multiplyScalar(delta));

    // Dynamic Physics: Simulation Vibrations + Hover lift
    const vibration = simulationActive ? Math.sin(t * 60 + index) * 0.02 : 0;
    const hoverLift = isFocused ? Math.sin(t * 4) * 0.4 : 0; // Increased lift
    
    groupRef.current.position.set(
      currentPos.current.x + vibration,
      currentPos.current.y + vibration + hoverLift,
      currentPos.current.z + vibration
    );

    // Rotation: Slight organic sway
    const sway = Math.sin(t * 1.5 + index) * 0.03 * (1 - factor);
    const focusRot = isFocused ? Math.sin(t * 2) * 0.08 : 0;
    groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, focusRot + sway, 0.1);
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, (simulationActive ? t * 0.5 : 0) + focusRot + sway, 0.1);
    groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, focusRot + sway, 0.1);

    // Scale
    const s = 1 + (isFocused ? 0.35 : 0); // Significantly bigger when focused
    groupRef.current.scale.lerp(new THREE.Vector3(s, s, s), 0.1);
  });

  return (
    <group 
      ref={groupRef} 
      onClick={(e) => { e.stopPropagation(); onSelect?.(label); }}
      onPointerEnter={(e) => { e.stopPropagation(); onHover?.(true); }}
      onPointerLeave={(e) => { e.stopPropagation(); onHover?.(false); }}
    >
      {children}
      
    </group>
  );
}

/**
 * 5. EXPLOSION SHOCKWAVE EFFECT
 */
function ExplosionShockwave({ factor }: { factor: number }) {
  return null; // Removed shockwave for cleaner engineering look
}

/**
 * 4. CURSOR TOOLTIP (High-Fidelity Engineering Interface)
 */
interface TooltipContent {
  label: string;
  material?: string;
  desc?: string;
  purpose?: string;
  uid: string;
}

function MouseTooltip({ data }: { data: TooltipContent | null }) {
  const { mouse } = useThree();
  const ref = useRef<HTMLDivElement>(null!);

  useFrame(() => {
    if (ref.current && data) {
      const x = (mouse.x * window.innerWidth) / 2;
      const y = (-mouse.y * window.innerHeight) / 2;
      // Fixed offset for better legibility
      ref.current.style.transform = `translate3d(${x + 40}px, ${y - 40}px, 0)`;
    }
  });

  if (!data) return null;

  return (
    <Html fullscreen style={{ pointerEvents: 'none' }}>
      <div 
        ref={ref}
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 flex flex-col gap-0 shadow-[0_0_100px_rgba(0,0,0,0.8)]"
      >
        <div className="bg-primary text-black px-4 py-1.5 flex items-center justify-between border-b border-black/20">
          <span className="font-black text-[14px] uppercase tracking-[0.2em]">{data.label.split('_')[0]}</span>
          <span className="font-mono text-[8px] font-bold opacity-50 ml-6">{data.uid}</span>
        </div>
        <div className="bg-black/95 backdrop-blur-3xl p-4 border-l-[4px] border-primary min-w-[200px]">
          <div className="space-y-3">
            <div className="flex flex-col">
              <span className="text-[8px] text-primary/60 font-black uppercase tracking-widest">DESC</span>
              <p className="text-[11px] text-white font-medium uppercase font-mono tracking-tight leading-tight">{data.desc}</p>
            </div>
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/10">
              <div className="flex flex-col">
                <span className="text-[8px] text-primary/40 font-black uppercase">MAT</span>
                <span className="text-[10px] text-white font-bold">{data.material?.split(' ')[0]}</span>
              </div>
              <div className="flex flex-col">
                <span className="text-[8px] text-primary/40 font-black uppercase">CLS</span>
                <span className="text-[10px] text-white font-bold">{data.purpose?.split(' ')[0] || "MECH"}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Html>
  );
}

/**
 * 5. TECHNICAL COMPONENTS (Revamped Primitives)
 */
function Mainboard({ 
  wireframe, 
  active, 
  simulationActive,
  explodeFactor = 0
}: { 
  wireframe?: boolean; 
  active?: boolean; 
  simulationActive?: boolean;
  explodeFactor?: number;
}) {
  const lightRef = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    if ((simulationActive || active) && lightRef.current) {
      lightRef.current.intensity = 1.5 + Math.sin(state.clock.elapsedTime * 15) * 1.0;
    }
  });

  return (
    <group>
      {/* Substrate - High Quality PCB Mesh */}
      <IndustrialPart color="#064e3b" wireframe={wireframe} explodeFactor={explodeFactor}>
        <mesh><boxGeometry args={[2.8, 0.08, 2.2]} /></mesh>
      </IndustrialPart>
      
      {/* IC Chips - ARM/FPGA package style */}
      <group position={[0, 0.1, 0]}>
        <IndustrialPart color="#1a1a1a" emissive="#3b82f6" wireframe={wireframe} explodeFactor={explodeFactor}>
          <mesh><boxGeometry args={[0.7, 0.12, 0.7]} /></mesh>
        </IndustrialPart>
        <pointLight ref={lightRef} position={[0, 0.2, 0]} color="#3b82f6" intensity={2} distance={3} />
      </group>

      {/* Surface Mount Comps (SMD arrays) */}
      {[...Array(6)].map((_, i) => (
        <group key={`smd-${i}`} position={[(i % 3) * 0.4 - 0.8, 0.08, (i > 2 ? 0.6 : -0.6)]}>
          <IndustrialPart color="#333" explodeFactor={explodeFactor}>
            <mesh><boxGeometry args={[0.15, 0.1, 0.1]} /></mesh>
          </IndustrialPart>
        </group>
      ))}

      {/* Capacitors (Cylindrical) */}
      <group position={[-1.0, 0.2, 0.8]}>
        <IndustrialPart color="#c0c0c0" explodeFactor={explodeFactor}>
          <mesh><cylinderGeometry args={[0.15, 0.15, 0.3, 16]} /></mesh>
        </IndustrialPart>
      </group>

      {/* Connection Header Pins */}
      <group position={[1.2, 0.15, -0.8]}>
        <IndustrialPart color="#f59e0b" explodeFactor={explodeFactor}>
          <mesh><boxGeometry args={[0.04, 0.3, 0.4]} /></mesh>
        </IndustrialPart>
      </group>

      {/* Logic Traces Visual (Emissive lines) */}
      {(active || simulationActive) && (
        <group position={[0, 0.06, 0]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[2.6, 2.0]} />
            <meshBasicMaterial color="#3b82f6" transparent opacity={0.3} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function Rotor({ active }: { active?: boolean }) {
  const groupRef = useRef<THREE.Group>(null!);
  useFrame((state) => {
    if (active && groupRef.current) {
      groupRef.current.rotation.y += 1.8; // Faster for realism
      groupRef.current.position.y = 0.2 + Math.sin(state.clock.elapsedTime * 25) * 0.005;
    }
  });

  return (
    <group ref={groupRef} position={[0, 0.2, 0]}>
      {/* Motor Bell (Mechanical Housing) */}
      <IndustrialPart color="#222" metalness={0.9}>
        <mesh><cylinderGeometry args={[0.6, 0.6, 0.4, 32]} /></mesh>
        {/* Shaft */}
        <mesh position={[0, 0.4, 0]}><cylinderGeometry args={[0.05, 0.05, 0.6, 16]} /></mesh>
      </IndustrialPart>

      {/* Stator (Internal copper coils effect) */}
      <IndustrialPart color="#d97706" emissive="#78350f" metalness={1.0}>
        <mesh scale={[0.8, 1.1, 0.8]}><cylinderGeometry args={[0.5, 0.5, 0.3, 12, 1, true]} /></mesh>
      </IndustrialPart>

      {/* Airfoil Propeller - Realistic aerodynamic shape */}
      <group position={[0, 0.5, 0]}>
        <IndustrialPart color="#0a0a0a" metalness={0.5} roughness={0.1}>
          {/* Blade 1 */}
          <mesh position={[1.5, 0, 0]} rotation={[0.1, 0, 0]}>
            <boxGeometry args={[3, 0.02, 0.3]} />
          </mesh>
          {/* Blade 2 */}
          <mesh position={[-1.5, 0, 0]} rotation={[-0.1, 0, 0]}>
            <boxGeometry args={[3, 0.02, 0.3]} />
          </mesh>
          {/* Central Hub */}
          <mesh><cylinderGeometry args={[0.15, 0.15, 0.1, 16]} /></mesh>
        </IndustrialPart>
      </group>
    </group>
  );
}

/**
 * 6. AI COMPOSER
 */
export function AIGeneratedModel({ 
  data, 
  explodeFactor, 
  wireframe, 
  activeComponent, 
  onComponentSelect, 
  simulationActive,
  spreadMode = 'GRID'
}: {
  data: GeneratedModelData;
  explodeFactor: number;
  wireframe: boolean;
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}) {
  const [hoveredData, setHoveredData] = useState<TooltipContent | null>(null);

  // Scanning effect state
  const [scanY, setScanY] = useState(0);
  useFrame((state) => {
    setScanY(Math.sin(state.clock.elapsedTime * 0.5) * 10);
  });

  const getTooltipData = (label: string, comp: { materialProperties?: { material?: string; purpose?: string } }): TooltipContent => {
    const key = Object.keys(COMPONENT_REGISTRY).find(k => label.toUpperCase().includes(k)) || "CHASSIS";
    const base = COMPONENT_REGISTRY[key];
    return {
      label: label,
      desc: comp.materialProperties?.material || base.desc,
      material: comp.materialProperties?.material || base.material,
      purpose: comp.materialProperties?.purpose || base.note,
      uid: `SN-${label.length}${label.charCodeAt(0)}` 
    };
  };

  return (
    <group scale={[6, 6, 6]}>
      {/* Dynamic Cursor Tooltip */}
      <MouseTooltip data={hoveredData} />
      {/* Scanning Laser Plane */}
      {!simulationActive && (
        <mesh position={[0, scanY, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[25, 25]} />
          <meshBasicMaterial color="#3b82f6" transparent opacity={0.03} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* Shockwave Pulse */}
      <ExplosionShockwave factor={explodeFactor} />

      {/* Assembly Particles */}
      <AssemblyParticles factor={explodeFactor} />

      {data.primitives.map((comp, idx) => {
        const baseVec = new THREE.Vector3(...comp.position);
        const isFocused = activeComponent === comp.label;
        const effectiveFactor = simulationActive ? 0 : explodeFactor;
        
        // Context-aware component substitution
        const labelLower = comp.label.toLowerCase();
        const isPCB = labelLower.includes("pcb") || labelLower.includes("control") || labelLower.includes("mcu");
        const isMotor = labelLower.includes("motor") || labelLower.includes("actuator") || labelLower.includes("rotor") || labelLower.includes("propeller");
        const isBattery = labelLower.includes("battery") || labelLower.includes("power") || labelLower.includes("cell");
        const isSolar = labelLower.includes("solar") || labelLower.includes("panel");
        
        const isScanning = !simulationActive && Math.abs(baseVec.y - scanY) < 0.3;

        const isHovered = hoveredData?.label === comp.label;
        const isHighlighted = isFocused || isHovered;

        return (
              <group key={`ai-prim-${comp.label}-${idx}`}>
            <DisassemblyPart 
              label={comp.label} 
              index={idx} 
              totalParts={data.primitives.length}
              factor={effectiveFactor} 
              basePosition={baseVec} 
              isFocused={isFocused} 
              onSelect={onComponentSelect}
              onHover={(h) => setHoveredData(h ? getTooltipData(comp.label, comp) : null)}
              simulationActive={simulationActive}
              spreadMode={spreadMode}
            >
              <group rotation={comp.rotation ? new THREE.Euler(...comp.rotation) : new THREE.Euler(0, 0, 0)}>
                {isPCB ? (
                  <Mainboard wireframe={wireframe} active={isHighlighted} simulationActive={simulationActive} explodeFactor={effectiveFactor} />
                ) : isMotor ? (
                  <group>
                    <IndustrialPart 
                      color={comp.color} 
                      isScanning={isScanning} 
                      wireframe={wireframe} 
                      isHighlighted={isHighlighted}
                      simulationActive={simulationActive}
                      explodeFactor={effectiveFactor}
                    >
                      <mesh><cylinderGeometry args={comp.args && comp.args.length >= 3 ? [comp.args[0], comp.args[1], comp.args[2], 16] : [0.5, 0.5, 1, 16]} /></mesh>
                    </IndustrialPart>
                    <Rotor active={simulationActive} />
                  </group>
                ) : (isBattery || isSolar) ? (
                  <IndustrialPart 
                    color={isSolar ? "#1e293b" : "#111"} 
                    emissive={isSolar ? "#3b82f6" : "#f59e0b"} 
                    isScanning={isScanning} 
                    wireframe={wireframe} 
                    isHighlighted={isHighlighted}
                    simulationActive={simulationActive}
                    explodeFactor={effectiveFactor}
                  >
                    <mesh><boxGeometry args={comp.args && comp.args.length >= 3 ? comp.args.slice(0, 3) : [1, 1, 1]} /></mesh>
                  </IndustrialPart>
                ) : (
                  <IndustrialPart 
                    color={comp.color} 
                    isScanning={isScanning} 
                    wireframe={wireframe} 
                    isHighlighted={isHighlighted}
                    simulationActive={simulationActive}
                    explodeFactor={effectiveFactor}
                    transparent={labelLower.includes("plate") || labelLower.includes("cover")}
                  >
                    <mesh>
                      {comp.type === "sphere" ? <sphereGeometry args={comp.args && comp.args.length >= 1 ? [comp.args[0], 16, 16] : [0.5, 16, 16]} /> : 
                       comp.type === "cylinder" ? <cylinderGeometry args={comp.args && comp.args.length >= 3 ? [comp.args[0], comp.args[1], comp.args[2], 16] : [0.5, 0.5, 1, 16]} /> :
                       comp.type === "torus" ? <torusGeometry args={comp.args && comp.args.length >= 2 ? [comp.args[0], comp.args[1], 12, 24] : [0.5, 0.2, 12, 24]} /> :
                       <boxGeometry args={comp.args && comp.args.length >= 3 ? comp.args.slice(0, 3) : [1, 1, 1]} />}
                    </mesh>
                  </IndustrialPart>
                )}
              </group>
            </DisassemblyPart>
          </group>
        );
      })}
    </group>
  );
}

/**
 * 7. CORE COMPOSER (Static Models Fallback)
 */
export function ExplodableModel(props: ExplodableModelProps) {
  // We prioritize the AIGeneratedModel structure as it's more dynamic.
  // For static fallbacks, we map them into the AI Generated format for consistency.
  const staticData: GeneratedModelData = useMemo(() => {
    const type = props.projectType.toLowerCase();
    
    if (type === "aether-core" || type.includes("core-unit")) {
      return CORE_UNIT_BLUEPRINT;
    }

    if (type.includes("drone") || type.includes("uav") || type.includes("quadcopter")) {
      return {
        primitives: [
          // Lower Chassis Plate (Carbon Fiber)
          { type: "box", args: [1.8, 0.08, 1.8], position: [0, -0.4, 0], color: "#111", label: "BASE_PLATE", materialProperties: { material: "3K_CARBON_FIBER", purpose: "Main structural tension plate." } },
          // Upper Chassis Plate
          { type: "box", args: [1.8, 0.08, 1.8], position: [0, 0.4, 0], color: "#111", label: "TOP_PLATE", materialProperties: { material: "3K_CARBON_FIBER", purpose: "Protective equipment mounting surface." } },
          
          // Structural Standoffs (Aluminum)
          { type: "cylinder", args: [0.08, 0.1, 0.8], position: [0.8, 0, 0.8], color: "#555", label: "STANDOFF_FR", materialProperties: { material: "AL_7075", purpose: "Inter-plate structural spacing." } },
          { type: "cylinder", args: [0.08, 0.1, 0.8], position: [-0.8, 0, 0.8], color: "#555", label: "STANDOFF_FL", materialProperties: { material: "AL_7075", purpose: "Inter-plate structural spacing." } },
          { type: "cylinder", args: [0.08, 0.1, 0.8], position: [0.8, 0, -0.8], color: "#555", label: "STANDOFF_RR", materialProperties: { material: "AL_7075", purpose: "Inter-plate structural spacing." } },
          { type: "cylinder", args: [0.08, 0.1, 0.8], position: [-0.8, 0, -0.8], color: "#555", label: "STANDOFF_RL", materialProperties: { material: "AL_7075", purpose: "Inter-plate structural spacing." } },

          // Propulsion Arms
          { type: "box", args: [6.5, 0.12, 0.5], position: [0, 0, 0], rotation: [0, Math.PI / 4, 0], color: "#1a1a1a", label: "ARM_X1", materialProperties: { material: "4MM_CARBON_FIBER", purpose: "Load-bearing motor mount arm." } },
          { type: "box", args: [6.5, 0.12, 0.5], position: [0, 0, 0], rotation: [0, -Math.PI / 4, 0], color: "#1a1a1a", label: "ARM_X2", materialProperties: { material: "4MM_CARBON_FIBER", purpose: "Load-bearing motor mount arm." } },
          
          // Motor Assemblies
          { type: "cylinder", args: [0.45, 0.45, 0.4], position: [2.3, 0.25, 2.3], color: "#222", label: "MOTOR_2306_FR" },
          { type: "cylinder", args: [0.45, 0.45, 0.4], position: [-2.3, 0.25, 2.3], color: "#222", label: "MOTOR_2306_FL" },
          { type: "cylinder", args: [0.45, 0.45, 0.4], position: [2.3, 0.25, -2.3], color: "#222", label: "MOTOR_2306_RR" },
          { type: "cylinder", args: [0.45, 0.45, 0.4], position: [-2.3, 0.25, -2.3], color: "#222", label: "MOTOR_2306_RL" },
          
          // Integrated Stack (PDB / ESC / FC)
          { type: "box", args: [1, 0.1, 1], position: [0, 0, 0], color: "#065f46", label: "4IN1_ESC", materialProperties: { material: "PCB_TG180", purpose: "High-current electronic speed control." } },
          { type: "box", args: [1, 0.1, 1], position: [0, 0.2, 0], color: "#1e3a8a", label: "F7_FC", materialProperties: { material: "PCB_TG180", purpose: "Flight control and IMU processing." } },
          
          // Payload / Perception
          { type: "box", args: [0.6, 0.6, 0.6], position: [0, 0.1, 1.2], color: "#444", label: "FPV_CAMERA", materialProperties: { material: "MAGNESIUM_ALLOY", purpose: "Real-time visual telemetry." } },
          { type: "box", args: [1.8, 0.6, 0.8], position: [0, -0.8, 0], color: "#0a0a0a", label: "LIPO_6S", materialProperties: { material: "LITHIUM_POLYMER", purpose: "High-density energy storage." } }
        ]
      };
    }

    if (type.includes("robot") || type.includes("manipulator") || type.includes("arm")) {
      return {
        primitives: [
          { type: "cylinder", args: [2, 2, 0.6], position: [0, -1, 0], color: "#333", label: "AZIMUTH_BASE", materialProperties: { material: "STEEL_HT", purpose: "Rotation pivot for horizontal orientation." } },
          { type: "cylinder", args: [1.2, 1.2, 1.8], position: [0, 0.2, 0], color: "#555", label: "SHOULDER_JOINT", materialProperties: { material: "AL_6061_T6", purpose: "Primary vertical lift articulation." } },
          { type: "box", args: [0.8, 4, 0.8], position: [0, 2.5, 0], color: "#444", label: "LOWER_ARM", materialProperties: { material: "AL_7075", purpose: "First extension skeletal member." } },
          { type: "cylinder", args: [0.6, 0.6, 1], position: [0, 4.5, 0], color: "#222", label: "ELBOW_JOINT", materialProperties: { material: "TITANIUM_GR2", purpose: "Secondary articulation joint." } },
          { type: "box", args: [0.6, 3, 0.6], position: [0, 6, 0], color: "#444", label: "UPPER_ARM", materialProperties: { material: "CARBON_COMPOSITE", purpose: "Final reach skeletal member." } },
          { type: "box", args: [1.2, 0.4, 0.8], position: [0, 7.5, 0], color: "#7c3aed", label: "EFFECTOR_MOUNT", materialProperties: { material: "AL_6061", purpose: "Universal tool attachment interface." } }
        ]
      };
    }
    return {
      primitives: [
        { type: "box", args: [6, 0.5, 4], position: [0, 0, 0], color: "#222", label: "CHASSIS" },
        { type: "box", args: [2, 0.1, 1.5], position: [0, 0.4, 0], color: "#1e3a8a", label: "MCU" }
      ]
    };
  }, [props.projectType]);

  return <AIGeneratedModel {...props} data={staticData} />;
}
