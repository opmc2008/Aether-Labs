import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Cpu, Zap, Layers, Sparkles, Send, Type, Shield, Terminal, Gauge, Settings, Globe, HardDrive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface AdvancedForgeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onForge: (prompt: string, isDirect?: boolean, title?: string) => void;
  isLoading?: boolean;
}

export function AdvancedForgeModal({ open, onOpenChange, onForge, isLoading }: AdvancedForgeModalProps) {
  const [activeTab, setActiveTab] = useState("core");
  const [prompt, setPrompt] = useState("");
  const [title, setTitle] = useState("");
  const [complexity, setComplexity] = useState([70]);
  const [bitrate, setBitrate] = useState(0);
  const [activeParameters, setActiveParameters] = useState<string[]>(["High_Fidelity"]);
  const [platform, setPlatform] = useState("Arduino");
  const [budget, setBudget] = useState("");
  const [level, setLevel] = useState("Prototype");
  const [safety, setSafety] = useState("Standard");
  const [environment, setEnvironment] = useState("Indoor");
  const [connectivity, setConnectivity] = useState("Wireless Mesh");
  const [scale, setScale] = useState("Single Unit");
  const [power, setPower] = useState("Li-Po Battery");
  const [thermal, setThermal] = useState("Passive Fin");
  const [material, setMaterial] = useState("Aluminum/Alloy");
  const [integration, setIntegration] = useState("Direct I/O");
  const [field, setField] = useState("Engineering");
  const [sector, setSector] = useState("Industrial");
  const [weightClass, setWeightClass] = useState("Desktop");
  const [pcbType, setPcbType] = useState("Rigid FR4");
  const [securityLevel, setSecurityLevel] = useState("Standard");
  const [sensorFusion, setSensorFusion] = useState("Basic");
  const [generationMode, setGenerationMode] = useState<"SINGLE" | "MULTIPLE">("MULTIPLE");

  const onClose = () => onOpenChange(false);

  useEffect(() => {
    if (open) {
      const interval = setInterval(() => {
        setBitrate(Math.floor(Math.random() * 500) + 1200);
      }, 100);
      return () => clearInterval(interval);
    }
  }, [open]);

  const toggleParam = (param: string) => {
    setActiveParameters(prev => 
      prev.includes(param) ? prev.filter(p => p !== param) : [...prev, param]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      let enhancedPrompt = prompt.trim();
      
      const techSpecs = [
        `Field: ${field}`,
        `Sector: ${sector}`,
        `Weight Class: ${weightClass}`,
        `PCB Type: ${pcbType}`,
        `Platform: ${platform}`,
        `Deployment Level: ${level}`,
        `Safety: ${safety}`,
        `Security Level: ${securityLevel}`,
        `Sensor Fusion: ${sensorFusion}`,
        `Environment: ${environment}`,
        `Connectivity: ${connectivity}`,
        `Scale: ${scale}`,
        `Power: ${power}`,
        `Thermal: ${thermal}`,
        `Material: ${material}`,
        `Integration: ${integration}`,
        budget ? `Budget Cap: ${budget} BDT` : null,
        `Complexity: ${complexity[0]}%`
      ].filter(Boolean).join(" | ");

      enhancedPrompt = `[ADVANCED_TECH_SPEC_V4: ${techSpecs}]\n\nCORE_DIRECTIVE: ${enhancedPrompt}`;
      
      if (activeParameters.length > 0) {
        enhancedPrompt += `\n\n[NEURAL_DIRECTIVES: ${activeParameters.join(", ")}]`;
      }
      
      onForge(enhancedPrompt, generationMode === "SINGLE", title.trim() || undefined);
      setPrompt("");
      setTitle("");
      onClose();
    }
  };

  const platforms = ["Arduino", "ESP32", "Raspberry Pi", "STM32", "NVIDIA Jetson"];
  const fields = ["Engineering", "Robotics", "Energy", "IoT", "AI", "Aerospace"];
  const levels = ["Prototype", "Pre-Prod", "Industrial"];
  const safeties = ["Std", "Fail-Safe", "Critical", "ASIL-D"];
  const environments = ["Indoor", "Outdoor", "Rugged", "Space"];
  const connectivities = ["Mesh", "Cellular", "RF/LoRa", "Satellite"];
  const scales = ["Single", "Swarm", "Enterprise"];
  const powerSources = ["Li-Po", "Super-Cap", "Poe+", "Nuclear/Sim"];
  const thermals = ["Passive", "Active", "Liquid", "Cryo"];
  const materials = ["Aluminum/Alloy", "Carbon Fiber", "Polymers", "Titanium"];
  const integrations = ["Direct I/O", "RTOS", "Cloud Proxy", "Edge AI"];
  
  const sectors = ["Defense", "Medical", "Consumer", "Aerospace", "Industrial", "Research"];
  const weightClasses = ["Nano", "Micro", "Desktop", "Large", "Heavy"];
  const pcbTypes = ["Rigid FR4", "Flexible", "Rigid-Flex", "Multi-layer", "Breadboard"];
  const securityLevels = ["Standard", "Encrypted", "Air-Gapped", "Military"];
  const sensorFusions = ["None", "Basic", "Advanced", "Deep/Neural"];
  const budgets = ["Bootstrap", "Funded", "Industrial", "Enterprise", "Unbounded"];

  const paramOptions = [
    { label: "High_Fidelity", icon: Cpu, color: "text-blue-400", desc: "MAX_RESOLUTION" },
    { label: "Eco_Synergy", icon: Zap, color: "text-emerald-400", desc: "OPT_EFFICIENCY" },
    { label: "Core_Stability", icon: Layers, color: "text-amber-400", desc: "RIGID_STRUCTURE" },
    { label: "Neural_Link", icon: Shield, color: "text-purple-400", desc: "AI_INTEGRATION" },
  ];

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={isLoading ? undefined : onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-3xl bg-card border border-white/10 rounded-none overflow-y-auto max-h-[90vh] shadow-2xl"
          >
            {/* HUD Scanning Line */}
            <motion.div 
              animate={{ top: ["0%", "100%", "0%"] }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
              className="absolute left-0 right-0 h-px bg-primary/20 z-10 pointer-events-none"
            />

            {/* Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between sticky top-0 bg-card/80 backdrop-blur-xl z-20">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="p-3 bg-primary/5 border border-primary/20 text-primary">
                    <Terminal className="w-5 h-5 phosphor-glow" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-primary animate-pulse" />
                </div>
                <div>
                  <h3 className="text-white font-black text-xl uppercase tracking-[0.3em] flex items-center gap-2">
                    Advanced_Forge
                    <span className="text-[8px] bg-white/5 border border-white/10 px-2 py-0.5 text-white/40">SYS_V4.3.0</span>
                  </h3>
                  <div className="flex items-center gap-4">
                    <p className="text-[9px] text-primary/40 font-mono uppercase tracking-[0.2em] font-black italic">Advanced_Multi_Param_Synthesis</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 px-4">
                <span className="text-[9px] font-mono text-white/20 uppercase tracking-widest">STATION_LINK: STABLE</span>
                <button 
                  onClick={onClose}
                  className="p-2 hover:bg-white/5 rounded-none text-white/20 transition-colors"
                  disabled={isLoading}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-0 flex flex-col h-[70vh]">
              <form onSubmit={handleSubmit} className="flex flex-col h-full">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="flex flex-col h-full">
                  <div className="px-8 pt-6 border-b border-white/5 bg-black/20">
                    <TabsList className="grid grid-cols-4 w-full bg-white/5 rounded-none p-1 h-14">
                      <TabsTrigger value="core" className="rounded-none data-[state=active]:bg-primary data-[state=active]:text-black text-[10px] font-black uppercase tracking-widest gap-3 transition-all h-full">
                        <Settings className="w-4 h-4" />
                        <span className="hidden sm:inline">PROJECT_CORE</span>
                      </TabsTrigger>
                      <TabsTrigger value="hardware" className="rounded-none data-[state=active]:bg-primary data-[state=active]:text-black text-[10px] font-black uppercase tracking-widest gap-3 transition-all h-full">
                        <HardDrive className="w-4 h-4" />
                        <span className="hidden sm:inline">HARDWARE_STACK</span>
                      </TabsTrigger>
                      <TabsTrigger value="connectivity" className="rounded-none data-[state=active]:bg-primary data-[state=active]:text-black text-[10px] font-black uppercase tracking-widest gap-3 transition-all h-full">
                        <Globe className="w-4 h-4" />
                        <span className="hidden sm:inline">ENV_&_CONN</span>
                      </TabsTrigger>
                      <TabsTrigger value="logic" className="rounded-none data-[state=active]:bg-primary data-[state=active]:text-black text-[10px] font-black uppercase tracking-widest gap-3 transition-all h-full">
                        <Cpu className="w-4 h-4" />
                        <span className="hidden sm:inline">LOGIC_&_SYNT</span>
                      </TabsTrigger>
                    </TabsList>
                  </div>

                  <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    <TabsContent value="core" className="space-y-10 mt-0 focus-visible:outline-none">
                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Designation_Tag (Title)
                        </label>
                        <input
                          type="text"
                          placeholder="PROJECT_OMEGA_FORGE"
                          value={title}
                          onChange={(e) => setTitle(e.target.value)}
                          className="w-full bg-black border border-white/10 rounded-none px-6 py-6 text-white placeholder:text-white/5 focus:outline-none focus:border-primary focus:bg-primary/5 transition-all font-mono text-[14px] uppercase tracking-[0.3em] font-black"
                          disabled={isLoading}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Research_Field
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {fields.map((f) => (
                              <button
                                key={`field-${f}`}
                                type="button"
                                onClick={() => setField(f)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  field === f ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {f}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Operational_Sector
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {sectors.map((s) => (
                              <button
                                key={`sector-${s}`}
                                type="button"
                                onClick={() => setSector(s)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  sector === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Infrastructure_Level
                        </label>
                        <div className="grid grid-cols-3 gap-2">
                          {levels.map((l) => (
                            <button
                              key={`lvl-${l}`}
                              type="button"
                              onClick={() => setLevel(l)}
                              className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                level === l ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              {l}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Resource_Allocation (Budget Class)
                        </label>
                        <div className="grid grid-cols-5 gap-2">
                          {budgets.map((b) => (
                            <button
                              key={`budget-${b}`}
                              type="button"
                              onClick={() => setBudget(b)}
                              className={`py-4 text-[8px] font-black tracking-widest uppercase border transition-all ${
                                budget === b ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              {b}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div className="space-y-6">
                        <div className="flex items-center justify-between">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Computational_Complexity
                          </label>
                          <span className="font-mono text-primary text-[11px] font-bold">{complexity}%</span>
                        </div>
                        <Slider
                          value={complexity}
                          onValueChange={setComplexity}
                          max={100}
                          step={1}
                          className="pt-4"
                        />
                      </div>
                    </TabsContent>

                    <TabsContent value="hardware" className="space-y-10 mt-0 focus-visible:outline-none">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Power_Supply_Unit
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {powerSources.map((p) => (
                              <button
                                key={`pwr-${p}`}
                                type="button"
                                onClick={() => setPower(p)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  power === p ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {p}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Form_Factor / Weight
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {weightClasses.map((w) => (
                              <button
                                key={`weight-${w}`}
                                type="button"
                                onClick={() => setWeightClass(w)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  weightClass === w ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {w}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            PCB_Fabrication_Spec
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {pcbTypes.map((p) => (
                              <button
                                key={`pcb-${p}`}
                                type="button"
                                onClick={() => setPcbType(p)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  pcbType === p ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {p}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Arch_Platform
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {platforms.map((p) => (
                              <button
                                key={`plat-${p}`}
                                type="button"
                                onClick={() => setPlatform(p)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  platform === p ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {p}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Thermal_Array
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {thermals.map((t) => (
                              <button
                                key={`thm-${t}`}
                                type="button"
                                onClick={() => setThermal(t)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  thermal === t ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {t}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Material_Fabrication
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {materials.map((m) => (
                              <button
                                key={`mat-${m}`}
                                type="button"
                                onClick={() => setMaterial(m)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  material === m ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {m}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="connectivity" className="space-y-10 mt-0 focus-visible:outline-none">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Security_Grade
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {securityLevels.map((s) => (
                              <button
                                key={`sec-${s}`}
                                type="button"
                                onClick={() => setSecurityLevel(s)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  securityLevel === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Deployment_Env
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {environments.map((e) => (
                              <button
                                key={`env-${e}`}
                                type="button"
                                onClick={() => setEnvironment(e)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  environment === e ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {e}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Network_Topology
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {connectivities.map((c) => (
                              <button
                                key={`conn-${c}`}
                                type="button"
                                onClick={() => setConnectivity(c)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  connectivity === c ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {c}
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Assembly_Scale
                          </label>
                          <div className="grid grid-cols-3 gap-2">
                            {scales.map((s) => (
                              <button
                                key={`scale-${s}`}
                                type="button"
                                onClick={() => setScale(s)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  scale === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Safety_&_Protocol
                        </label>
                        <div className="grid grid-cols-4 gap-2">
                          {safeties.map((s) => (
                            <button
                              key={`safe-${s}`}
                              type="button"
                              onClick={() => setSafety(s)}
                              className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                safety === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              {s}
                            </button>
                          ))}
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="logic" className="space-y-10 mt-0 focus-visible:outline-none">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Synthesis_Strategy
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            <button
                              type="button"
                              onClick={() => setGenerationMode("MULTIPLE")}
                              className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                generationMode === "MULTIPLE" ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              IDEA_SYNT_POOL
                            </button>
                            <button
                              type="button"
                              onClick={() => setGenerationMode("SINGLE")}
                              className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                generationMode === "SINGLE" ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              DIRECT_SOLO_CONSTRUCT
                            </button>
                          </div>
                        </div>

                        <div className="space-y-6">
                          <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                            <div className="w-1 h-1 bg-primary" />
                            Sensor_Fusion_Logic
                          </label>
                          <div className="grid grid-cols-2 gap-2">
                            {sensorFusions.map((s) => (
                              <button
                                key={`fusion-${s}`}
                                type="button"
                                onClick={() => setSensorFusion(s)}
                                className={`py-4 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                  sensorFusion === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Neural_Directives (Comprehensive Prompt)
                        </label>
                        <textarea
                          placeholder="INIT_CORE_SYNTHESIS_PARAM..."
                          value={prompt}
                          onChange={(e) => setPrompt(e.target.value)}
                          className="w-full h-32 bg-black border border-white/10 rounded-none p-8 text-white placeholder:text-white/5 focus:outline-none focus:border-primary focus:bg-primary/5 transition-all resize-none font-mono text-[14px] uppercase tracking-[0.2em] leading-relaxed"
                          disabled={isLoading}
                        />
                      </div>

                      <div className="space-y-6">
                        <label className="text-[10px] font-black text-primary/60 uppercase tracking-[0.4em] italic pl-1">
                          Binary_Toggles
                        </label>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {paramOptions.map((item) => {
                            const isActive = activeParameters.includes(item.label);
                            return (
                              <button
                                key={item.label}
                                type="button"
                                onClick={() => toggleParam(item.label)}
                                className={`p-6 flex flex-col items-center gap-4 border transition-all relative group ${
                                  isActive ? "bg-primary/10 border-primary text-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                                }`}
                              >
                                <item.icon className="w-6 h-6" />
                                <span className="text-[9px] font-black uppercase tracking-widest">{item.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </TabsContent>
                  </div>
                </Tabs>

                <div className="p-8 bg-black/40 border-t border-white/5 flex flex-col gap-4">
                  <div className="flex items-center justify-between">
                    <div className="flex gap-4">
                      {["core", "hardware", "connectivity", "logic"].map((t) => (
                        <div 
                          key={`step-${t}`} 
                          className={`w-2 h-2 ${activeTab === t ? "bg-primary phosphor-glow" : "bg-white/10"}`} 
                        />
                      ))}
                    </div>
                    {activeTab !== "logic" ? (
                      <Button 
                        type="button" 
                        onClick={() => {
                          const tabs = ["core", "hardware", "connectivity", "logic"];
                          const nextIdx = tabs.indexOf(activeTab) + 1;
                          setActiveTab(tabs[nextIdx]);
                        }}
                        className="bg-white/5 hover:bg-white/10 border border-white/10 text-white uppercase font-black tracking-widest text-[10px] px-8 h-12 rounded-none"
                      >
                        NEXT_PARAM_STACK
                      </Button>
                    ) : (
                      <Button 
                        type="submit"
                        disabled={!prompt.trim() || isLoading}
                        className="bg-primary hover:scale-[1.02] active:scale-[0.98] text-black uppercase font-black tracking-[0.3em] text-[12px] px-12 h-14 rounded-none transition-all phosphor-glow border-none"
                      >
                        {isLoading ? "SYNTHESIZING..." : "EXECUTE_FORGE"}
                      </Button>
                    )}
                  </div>
                </div>
              </form>
            </div>

            {/* Footer */}
            <div className="px-8 py-6 bg-black/95 border-t border-white/5 flex items-center justify-between sticky bottom-0">
              <div className="flex items-center gap-8">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-none bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse" />
                  <span className="text-[10px] font-mono text-white/40 uppercase tracking-[0.5em] font-black">XFER_STABLE</span>
                </div>
                <div className="h-6 w-px bg-white/10" />
                <div className="flex items-center gap-4">
                  <Gauge className="w-4 h-4 text-white/20" />
                  <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.3em]">NEURAL_BANDWIDTH: {bitrate}kb/s</span>
                </div>
              </div>
              <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.5em] font-black">AETHER_FORGE // v4.3.0</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}


