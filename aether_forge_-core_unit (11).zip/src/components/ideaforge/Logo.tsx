import React from "react";
import { motion } from "motion/react";

export const Logo = () => {
  return (
    <motion.div 
      className="flex items-center gap-4 group cursor-pointer"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="relative w-8 h-8 flex items-center justify-center">
        {/* Hardware Branding Visual */}
        <div className="absolute inset-0 border border-primary/40 rounded-none group-hover:bg-primary/20 transition-all duration-300" />
        <div className="absolute inset-1 border border-black/40 rounded-none" />
        <div className="w-1 h-1 bg-primary rounded-none phosphor-glow" />
        
        {/* Technical Coordinate Markers */}
        <div className="absolute -top-1 -left-1 text-[5px] font-mono text-primary">00</div>
        <div className="absolute -bottom-1 -right-1 text-[5px] font-mono text-primary">FF</div>
      </div>

      <div className="flex flex-col -space-y-1.5 border-l-2 border-primary pl-4 py-0.5">
        <div className="flex items-baseline gap-2">
          <span className="font-mono font-black text-2xl text-white tracking-tighter uppercase phosphor-glow">Aether</span>
          <div className="w-1.5 h-3 bg-primary animate-pulse" />
        </div>
        <span className="text-[8px] font-mono text-white/40 uppercase tracking-[0.5em] font-bold">Advanced_Neural_Forge_v4.2</span>
      </div>
    </motion.div>
  );
};
