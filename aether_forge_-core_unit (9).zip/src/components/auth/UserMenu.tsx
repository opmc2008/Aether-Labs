import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import { signInWithGoogle, signInWithGithub, signOut } from '../../lib/firebase';
import { Button } from '@/components/ui/button';
import { 
  Github, 
  LogOut, 
  User as UserIcon,
  ChevronDown
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export const UserMenu: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <div className="h-10 w-10 rounded-full bg-muted animate-pulse" />;
  }

  if (!user) {
    return (
      <div className="flex items-center gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => signInWithGithub()}
          className="hidden md:flex gap-2"
        >
          <Github className="h-4 w-4" />
          GitHub
        </Button>
        <Button 
          variant="default" 
          size="sm" 
          onClick={() => signInWithGoogle()}
          className="gap-2"
        >
          <div className="h-4 w-4 flex items-center justify-center font-bold">G</div>
          Google Login
        </Button>
      </div>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-10 flex items-center gap-2 px-2 hover:bg-accent/50">
          <Avatar className="h-8 w-8">
            <AvatarImage src={user.photoURL || ''} alt={user.displayName || 'User'} />
            <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
          </Avatar>
          <div className="hidden md:flex flex-col items-start text-xs">
            <span className="font-medium truncate max-w-[100px]">{user.displayName}</span>
            <span className="text-muted-foreground truncate max-w-[100px]">{user.email}</span>
          </div>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{user.displayName}</p>
            <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={() => signOut()}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
