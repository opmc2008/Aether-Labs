import { Grid } from "@react-three/drei";

export function GridFloor({ position = [0, -1, 0] }: { position?: [number, number, number] }) {
  return (
    <group position={position}>
      <Grid
        infiniteGrid
        fadeDistance={30}
        fadeStrength={5}
        cellSize={1}
        sectionSize={5}
        sectionThickness={1.5}
        sectionColor="#7c3aed"
        cellColor="#334155"
        cellThickness={0.8}
      />
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.01, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshStandardMaterial
          color="#020617"
          transparent
          opacity={0.4}
          roughness={1}
        />
      </mesh>
    </group>
  );
}
