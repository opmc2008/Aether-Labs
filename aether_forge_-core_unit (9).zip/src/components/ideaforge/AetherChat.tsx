import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Settings, Volume2, VolumeX, Mic, Send, X, Sparkles, Wand2, Info, Image as ImageIcon, Download } from "lucide-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { chatWithAether, generateSpeech, generateImage } from "@/services/geminiService";

interface Msg {
  role: "user" | "assistant";
  content: string;
  isAudioPlaying?: boolean;
  image?: string;
}

interface AetherChatProps {
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  context?: {
    idea?: string;
    plan?: string;
    field?: string;
    activeComponent?: string | null;
  };
  initialMessage?: string;
  onForge?: (prompt: string) => void;
  isForging?: boolean;
}

export function AetherChat({ open: externalOpen, onOpenChange, context, initialMessage, onForge, isForging }: AetherChatProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = externalOpen !== undefined ? externalOpen : internalOpen;
  const setOpen = (val: boolean) => {
    if (onOpenChange) onOpenChange(val);
    setInternalOpen(val);
  };
  
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);
  const [useHighQualityVoice, setUseHighQualityVoice] = useState(true);
  
  const [voiceSettings, setVoiceSettings] = useState({
    voiceName: 'Kore' as 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr',
    pitch: 0.9,
    rate: 1.05
  });

  const scrollRef = useRef<HTMLDivElement>(null);
  /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
  const recognitionRef = useRef<any>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const speakSystem = useCallback((text: string) => {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text.slice(0, 300));
    utterance.rate = voiceSettings.rate;
    utterance.pitch = voiceSettings.pitch;
    window.speechSynthesis.speak(utterance);
  }, [voiceSettings]);

  const playAudio = useCallback(async (text: string) => {
    if (!voiceEnabled) return;

    if (useHighQualityVoice) {
      try {
        const base64 = await generateSpeech(text.slice(0, 500), voiceSettings.voiceName);
        if (base64) {
          const binaryString = atob(base64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          
          /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
          const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
          const float32Buffer = new Float32Array(bytes.length / 2);
          const dataView = new DataView(bytes.buffer);
          
          for (let i = 0; i < float32Buffer.length; i++) {
            float32Buffer[i] = dataView.getInt16(i * 2, true) / 32768;
          }
          
          const buffer = audioContext.createBuffer(1, float32Buffer.length, 24000);
          buffer.getChannelData(0).set(float32Buffer);
          
          const source = audioContext.createBufferSource();
          source.buffer = buffer;
          source.connect(audioContext.destination);
          source.start();
        }
      } catch (error) {
        console.error("High Quality TTS failed, falling back to system:", error);
        speakSystem(text);
      }
    } else {
      speakSystem(text);
    }
  }, [voiceEnabled, useHighQualityVoice, voiceSettings, speakSystem]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isLoading) return;
    
    const userMsg: Msg = { role: "user", content: text.trim() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await chatWithAether([...messages, userMsg], {
        ...context,
        activeComponent: context?.activeComponent
      });
      const assistantMsg: Msg = { role: "assistant", content: response.text };
      setMessages(prev => [...prev, assistantMsg]);
      playAudio(response.text);

      // Native tool call handling for forging
      if (response.functionCall?.name === "forgeProject" && onForge && !isForging) {
        const forgePrompt = response.functionCall.args.prompt as string;
        onForge(forgePrompt);
      }

      // Handle image generation
      if (response.functionCall?.name === "generateImage") {
        const imgPrompt = response.functionCall.args.prompt as string;
        const b64Image = await generateImage(imgPrompt);
        if (b64Image) {
          setMessages(prev => {
            const last = [...prev];
            if (last.length > 0 && last[last.length - 1].role === "assistant") {
              last[last.length - 1].image = b64Image;
              return last;
            }
            return [...prev, { role: "assistant", content: "Visual synthesis complete.", image: b64Image }];
          });
        }
      }
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection to core systems lost. Re-establishing link..." }]);
    } finally {
      setIsLoading(false);
    }
  }, [messages, isLoading, context, onForge, isForging, playAudio]);

  useEffect(() => {
    if (open && initialMessage && messages.length === 0) {
      sendMessage(initialMessage);
    }
  }, [open, initialMessage, messages.length, sendMessage]);

  const toggleVoiceInput = useCallback(() => {
    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    /* eslint-disable-next-line @typescript-eslint/no-explicit-any */
    recognition.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      if (e.results[0].isFinal) {
        setIsListening(false);
        sendMessage(transcript);
      } else {
        setInput(transcript);
      }
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);

    return () => {
      recognition.stop();
    };
  }, [isListening, sendMessage]);

  // Cleanup effect
  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  return (
    <>
      {/* Floating Assistant Core: Tactical Neural Link */}
      <div className="fixed bottom-6 right-6 z-[9999]">
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={() => setOpen(!open)}
          className="relative w-20 h-20 flex items-center justify-center p-0 bg-transparent group"
        >
          {/* Rotating Rings */}
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className={`absolute inset-0 border-2 rounded-full border-dashed ${open ? 'border-primary opacity-100' : 'border-white/10 opacity-40'}`}
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
            className={`absolute inset-2 border border-primary/20 rounded-full ${open ? 'opacity-100' : 'opacity-20'}`}
          />
          
          <div className={`relative w-14 h-14 flex items-center justify-center bg-[#080809] border-2 transition-all duration-500 ${
            open ? "border-primary phosphor-glow rotate-45 scale-110" : "border-white/10 rotate-0 scale-100"
          }`}>
            <AnimatePresence mode="wait">
              {open ? (
                <motion.div key="close" initial={{ opacity: 0, rotate: -45 }} animate={{ opacity: 1, rotate: -45 }} exit={{ opacity: 0, rotate: 45 }}>
                  <X className="w-6 h-6 text-primary" />
                </motion.div>
              ) : (
                <motion.div key="icon" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="relative flex items-center justify-center">
                  <div className="w-4 h-4 bg-primary animate-pulse shadow-[0_0_15px_rgba(59,130,246,0.8)] rotate-45" />
                  <div className="absolute inset-0 w-8 h-8 border border-primary/20 animate-ping rounded-full" />
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Listening Indicator */}
          {isListening && (
            <motion.div
              animate={{ scale: [1, 2], opacity: [1, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="absolute inset-0 rounded-full bg-primary/20 pointer-events-none"
            />
          )}
        </motion.button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, x: 20, rotateY: -15 }}
            animate={{ opacity: 1, x: 0, rotateY: 0 }}
            exit={{ opacity: 0, x: 20, rotateY: -15 }}
            transition={{ type: "spring", damping: 20 }}
            className="fixed bottom-24 right-8 z-[9999] w-[calc(100vw-4rem)] md:w-[28rem] h-[calc(100vh-24rem)] md:h-[38rem] bg-[#080809]/95 backdrop-blur-3xl border-2 border-primary/30 flex flex-col overflow-hidden shadow-[40px_0_100px_rgba(0,0,0,0.8)] perspective-1000"
          >
            {/* HUD Scanning Lines */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(203,213,225,0.01)_1px,transparent_1px)] bg-[length:100%_3px] pointer-events-none opacity-50" />
            <motion.div 
              animate={{ y: [0, 400, 0] }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              className="absolute inset-x-0 h-20 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none opacity-20"
            />

            {/* Tactical Rail Text */}
            <div className="absolute left-2 top-1/2 -translate-y-1/2 vertical-rl text-[8px] font-mono font-black text-primary/20 tracking-[0.6em] uppercase select-none">
              AETHER_LINK_v4.0 // SIGNAL_STRETCH: 98% // BUFFER_CAP: 1024MB
            </div>

            {/* Neural Link Header: Tactical HUD */}
            <div className="px-8 py-6 border-b-2 border-white/10 bg-[#0c0c0e]/80 flex items-center justify-between relative">
              <div className="flex items-center gap-5">
                <div className="relative">
                  <div className="w-12 h-12 bg-primary/5 border border-primary/20 flex items-center justify-center">
                    <motion.div 
                      animate={{ scale: [1, 1.2, 1] }} 
                      transition={{ duration: 2, repeat: Infinity }}
                      className="w-4 h-4 border border-primary rotate-45" 
                    />
                  </div>
                  <div className="absolute -top-2 -left-2 w-4 h-4 border-t-2 border-l-2 border-primary/50" />
                  <div className="absolute -bottom-2 -right-2 w-4 h-4 border-b-2 border-r-2 border-primary/50" />
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="text-xl font-black tracking-[0.3em] text-white uppercase">AETHER_CORE_HUD</h3>
                    <div className="w-2 h-2 bg-primary animate-pulse rounded-full" />
                  </div>
                  <span className="text-[9px] font-mono text-primary/40 font-black uppercase tracking-[0.4em]">NEURAL_INTERFACE_ACTIVE</span>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setVoiceEnabled(!voiceEnabled)}
                  className={`p-3 transition-all border-2 ${voiceEnabled ? "bg-primary border-primary text-black" : "bg-black border-white/10 text-white/20"}`}
                >
                  {voiceEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
                </button>
                <button 
                  onClick={() => setShowSettings(!showSettings)}
                  className={`p-3 transition-all border-2 ${showSettings ? "bg-white border-white text-black" : "bg-black border-white/10 text-white/20"}`}
                >
                  <Settings className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 relative overflow-hidden flex flex-col">
              {/* Settings Overlay */}
              <AnimatePresence>
                {showSettings && (
                  <motion.div
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="absolute inset-x-0 top-0 z-20 bg-black/95 backdrop-blur-2xl border-b border-white/5 p-8 space-y-8"
                  >
                    <div className="space-y-6">
                      <div className="flex items-center justify-between">
                        <label className="text-[11px] font-black uppercase text-primary tracking-[0.2em]">Voice Mode</label>
                        <button 
                          onClick={() => setUseHighQualityVoice(!useHighQualityVoice)}
                          className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase transition-all ${
                            useHighQualityVoice ? "bg-primary text-white" : "bg-white/5 text-slate-500"
                          }`}
                        >
                          {useHighQualityVoice ? "High Quality (Gemini)" : "Standard System"}
                        </button>
                      </div>

                      <div className="space-y-4">
                        <label className="text-[11px] font-black uppercase text-slate-500 tracking-[0.2em]">Assistant Personality</label>
                        <div className="grid grid-cols-5 gap-2">
                          {(['Kore', 'Puck', 'Charon', 'Fenrir', 'Zephyr'] as const).map(v => (
                            <button
                              key={`voice-${v}`}
                              onClick={() => setVoiceSettings(prev => ({ ...prev, voiceName: v }))}
                              className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                                voiceSettings.voiceName === v ? "bg-primary text-black border-primary" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                              }`}
                            >
                              {v}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Chat Messages as Data Packets */}
              <div ref={scrollRef} className="flex-1 overflow-y-auto p-12 space-y-12 scrollbar-hide relative ml-4">
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-full text-center space-y-10">
                    <div className="relative">
                      <div className="w-24 h-24 border border-primary/20 rotate-45 flex items-center justify-center">
                        <div className="w-10 h-10 border-2 border-primary animate-ping" />
                      </div>
                      <motion.div 
                        animate={{ rotate: 360 }}
                        transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
                        className="absolute -inset-12 border border-dashed border-white/5"
                      />
                    </div>
                    <div className="space-y-4">
                      <h4 className="text-xl font-black text-white tracking-[0.6em] uppercase">SYSTEM_IDLE</h4>
                      <p className="text-primary font-mono text-[9px] uppercase tracking-[0.5em] max-w-[220px] leading-relaxed mx-auto font-black bg-primary/10 py-2 px-4 border border-primary/20">
                        WAITING_FOR_UPLINK...
                      </p>
                    </div>
                    <div className="grid grid-cols-1 gap-2 w-full max-w-[280px]">
                      {[
                        "INIT_SENS_SWEEP",
                        "XFER_POWER_SCHEMA",
                        "GEN_MECH_DRAFT"
                      ].map(t => (
                        <button
                          key={`suggest-${t}`}
                          onClick={() => sendMessage(t)}
                          className="px-6 py-4 bg-white/5 border border-white/10 text-[10px] font-mono font-black text-white/30 hover:bg-primary hover:text-black hover:border-primary transition-all text-left uppercase tracking-[0.4em]"
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map((msg, i) => (
                  <motion.div
                    key={`aether-msg-v2-${i}-${msg.role}`}
                    initial={{ opacity: 0, x: msg.role === 'user' ? 20 : -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ type: "spring", stiffness: 100 }}
                    className="space-y-4 relative"
                  >
                    {/* Transmission Header */}
                    <div className={`flex items-center gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      <div className={`flex items-center gap-2 group`}>
                        <div className={`w-1.5 h-1.5 rounded-none ${msg.role === 'user' ? 'bg-primary' : 'bg-slate-600'} animate-pulse`} />
                        <span className={`text-[10px] font-mono font-black uppercase tracking-[0.5em] ${msg.role === 'user' ? 'text-primary' : 'text-slate-500'}`}>
                          {msg.role === 'user' ? 'PACKET_TX_STABLE' : 'SIGNAL_RX_LOCKED'}
                        </span>
                      </div>
                      <div className="h-px flex-1 bg-white/5" />
                      <div className="flex items-center gap-3">
                        <span className="text-[8px] font-mono text-white/5 uppercase tracking-widest font-black">
                          SRC: {msg.role === 'user' ? 'AUTH_NODE_01' : 'CORE_AETHER'}
                        </span>
                        <div className="w-px h-2 bg-white/10" />
                        <span className="text-[8px] font-mono text-white/10 uppercase tracking-widest font-black">
                          {new Date().toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                        </span>
                      </div>
                    </div>

                    {/* Data Payload */}
                    <div className={`relative ${msg.role === 'user' ? 'pl-8' : 'pr-4'}`}>
                      {msg.image && (
                        <div className="mb-6 border border-white/10 p-2 bg-black/40 shadow-inner">
                          <img 
                            src={msg.image} 
                            alt="ARC_VIS" 
                            className="w-full h-auto object-cover grayscale opacity-80 hover:grayscale-0 hover:opacity-100 transition-all cursor-zoom-in"
                            referrerPolicy="no-referrer"
                          />
                          <div className="mt-2 text-[8px] font-mono text-white/20 uppercase tracking-[0.4em]">SYNC_VISUAL_DATA_LINK</div>
                        </div>
                      )}
                      
                      <div className={`text-[14px] font-mono tracking-wide leading-relaxed ${msg.role === 'user' ? 'text-primary font-bold text-right italic' : 'text-white'}`}>
                        {msg.role === "assistant" ? (
                          <div className="prose prose-invert prose-sm max-w-none prose-p:leading-relaxed prose-code:bg-white/5 prose-code:text-primary prose-code:px-1 prose-pre:bg-black/80 prose-pre:border prose-pre:border-white/10 prose-strong:text-primary prose-strong:font-black">
                            <ReactMarkdown remarkPlugins={[remarkGfm]}>
                              {msg.content}
                            </ReactMarkdown>
                          </div>
                        ) : (
                          <div className="bg-primary/5 py-4 px-6 border-l-2 border-primary">
                            {msg.content}
                          </div>
                        )}
                      </div>

                      {msg.role === "assistant" && (msg.content.toLowerCase().includes("forge") || msg.content.toLowerCase().includes("build") || msg.content.includes("Initializing Forge Sequence")) && onForge && (
                        <motion.button
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => {
                            const prompt = msg.content.includes("Forge Sequence") ? (context?.idea || context?.field || "Current project") : msg.content.replace(/.*(forge|build|create|make)\s+/i, "").trim();
                            onForge(prompt);
                          }}
                          className="mt-8 w-full py-5 border border-primary bg-primary/10 text-primary hover:bg-primary hover:text-black font-black text-[12px] uppercase tracking-[0.6em] transition-all relative group"
                        >
                          <div className="absolute inset-0 bg-primary opacity-0 group-hover:opacity-10 transition-opacity" />
                          {isForging ? "SYNTH_ACTIVE" : "EXECUTE_FORGE_SEQ"}
                        </motion.button>
                      )}
                    </div>
                  </motion.div>
                ))}

                {isLoading && (
                  <div className="flex items-center gap-4 px-6 py-4">
                    <div className="flex gap-2">
                      {[0, 1, 2].map(idx => (
                        <motion.div
                          key={`loader-${idx}`}
                          animate={{ scale: [1, 1.5, 1], opacity: [0.3, 1, 0.3] }}
                          transition={{ duration: 0.8, repeat: Infinity, delay: idx * 0.15 }}
                          className="w-2 h-2 rounded-full bg-primary/40"
                        />
                      ))}
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-600 uppercase tracking-widest">Processing_Data...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Neural Input HUD Interface */}
            <div className="p-8 bg-black/80 border-t border-white/10 relative">
              <div className="flex items-center gap-4">
                <button
                  onClick={toggleVoiceInput}
                  className={`w-14 h-14 flex items-center justify-center transition-all border shrink-0 ${
                    isListening
                      ? "bg-primary border-primary text-black"
                      : "bg-white/5 border-white/10 text-white/20 hover:text-primary"
                  }`}
                >
                  <Mic className={`w-6 h-6 ${isListening ? "animate-pulse" : ""}`} />
                </button>
                <div className="flex-1 relative group">
                  <div className="absolute left-6 top-1/2 -translate-y-1/2 text-primary/40 font-mono text-xs select-none pointer-events-none">
                    {input ? '' : '> EXEC_CMD_'}
                  </div>
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
                    className="w-full h-14 bg-white/5 border border-white/10 px-8 pl-24 text-[14px] font-mono font-bold text-white placeholder:text-white/10 focus:outline-none focus:border-primary focus:bg-white/10 transition-all uppercase"
                  />
                  <div className="absolute right-4 bottom-2 text-[8px] font-mono text-primary/20 uppercase tracking-widest font-black">
                    CMD_BUFFER_READY
                  </div>
                </div>
                <button
                  onClick={() => sendMessage(input)}
                  disabled={!input.trim() || isLoading}
                  className="w-14 h-14 bg-primary text-black flex items-center justify-center disabled:opacity-10 transition-all hover:bg-white"
                >
                  <Send className="w-6 h-6" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

const ArrowRight = ({ className }: { className: string }) => (
  <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="m12 5 7 7-7 7"/></svg>
);
