import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { chatWithAether } from "@/services/geminiService";

interface Msg {
  role: "user" | "assistant";
  content: string;
}

interface JarvisChatProps {
  context?: {
    idea?: string;
    plan?: string;
    field?: string;
  };
}

export function JarvisChat({ context }: JarvisChatProps) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || isLoading) return;
    const userMsg: Msg = { role: "user", content: text.trim() };
    const allMessages = [...messages, userMsg];
    setMessages(allMessages);
    setInput("");
    setIsLoading(true);

    try {
      const reply = await chatWithAether(allMessages, context);
      setMessages(prev => [...prev, { role: "assistant", content: reply }]);
    } catch {
      setMessages(prev => [...prev, { role: "assistant", content: "Connection error. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  }, [messages, isLoading, context]);

  const toggleVoice = useCallback(() => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return;

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onresult = (e: SpeechRecognitionEvent) => {
      const transcript = e.results[0][0].transcript;
      setIsListening(false);
      sendMessage(transcript);
    };

    recognition.onerror = () => setIsListening(false);
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
  }, [isListening, sendMessage]);

  // Speak assistant responses
  useEffect(() => {
    if (messages.length > 0) {
      const last = messages[messages.length - 1];
      if (last.role === "assistant" && window.speechSynthesis) {
        const utterance = new SpeechSynthesisUtterance(last.content.slice(0, 300));
        utterance.rate = 1.1;
        utterance.pitch = 0.9;
        window.speechSynthesis.speak(utterance);
      }
    }
  }, [messages]);

  return (
    <>
      {/* Floating Jarvis button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg"
        style={{ boxShadow: "0 0 20px hsl(170 80% 50% / 0.4)" }}
      >
        <span className="text-xl">{open ? "✕" : "🤖"}</span>
      </motion.button>

      {/* Chat panel */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="fixed bottom-24 right-6 z-50 w-80 h-[28rem] rounded-xl border border-primary/30 bg-card flex flex-col overflow-hidden"
            style={{ boxShadow: "0 0 40px hsl(170 80% 50% / 0.15)" }}
          >
            {/* Header */}
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-primary animate-pulse-glow" />
              <span className="text-sm font-bold text-primary glow-text">J.A.R.V.I.S</span>
              <span className="text-[9px] text-muted-foreground ml-auto">AI Assistant</span>
            </div>

            {/* Messages */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto p-3 space-y-2">
              {messages.length === 0 && (
                <div className="text-xs text-muted-foreground text-center mt-8">
                  <p className="text-lg mb-2">🤖</p>
                  <p>Hello, I'm J.A.R.V.I.S.</p>
                  <p>Ask me anything about your project.</p>
                  <p className="mt-2 text-[10px]">Try voice input with the 🎤 button</p>
                </div>
              )}
              {messages.map((msg, i) => (
                <motion.div
                  key={`jarvis-msg-v2-${i}-${msg.role}`}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`text-xs px-3 py-2 rounded-lg max-w-[90%] ${
                    msg.role === "user"
                      ? "bg-primary/20 text-primary ml-auto"
                      : "bg-secondary text-foreground"
                  }`}
                >
                  {msg.content}
                </motion.div>
              ))}
              {isLoading && (
                <div className="flex items-center gap-1 text-xs text-primary">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" style={{ animationDelay: "0.2s" }} />
                  <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" style={{ animationDelay: "0.4s" }} />
                </div>
              )}
            </div>

            {/* Input */}
            <div className="p-2 border-t border-border flex gap-1">
              <button
                onClick={toggleVoice}
                className={`px-2 py-1 rounded text-sm ${isListening ? "bg-destructive/20 text-destructive" : "bg-secondary text-muted-foreground hover:text-foreground"} transition-colors`}
              >
                {isListening ? "🔴" : "🎤"}
              </button>
              <input
                type="text"
                placeholder="Ask Jarvis..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && sendMessage(input)}
                className="flex-1 text-xs bg-background border border-border rounded px-2 py-1 text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors"
              />
              <button
                onClick={() => sendMessage(input)}
                disabled={!input.trim() || isLoading}
                className="px-2 py-1 rounded bg-primary text-primary-foreground text-xs font-semibold disabled:opacity-40 transition-colors"
              >
                ➤
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
