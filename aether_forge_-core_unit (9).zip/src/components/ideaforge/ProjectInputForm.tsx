import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Cpu, Zap, Activity } from "lucide-react";

interface ProjectInputFormProps {
  isOpen: boolean;
  onClose: () => void;
  onForge: (prompt: string) => void;
  isLoading: boolean;
}

export const ProjectInputForm = ({ isOpen, onClose, onForge, isLoading }: ProjectInputFormProps) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [field, setField] = useState("Engineering");

  const fields = ["Engineering", "DIY", "Robotics", "Software", "Hardware", "Art"];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title.trim()) {
      const combinedPrompt = `Project Title: ${title}\nDescription: ${description}\nField: ${field}`;
      onForge(combinedPrompt);
      // We don't close here immediately if we want to show loading, 
      // but usually the caller handles closing on success.
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            className="relative w-full max-w-xl bg-[#050505] border border-white/10 rounded-[2rem] overflow-hidden shadow-2xl"
          >
            <div className="tech-grid absolute inset-0 opacity-10 pointer-events-none" />
            
            <header className="px-8 py-6 border-b border-white/5 flex items-center justify-between relative z-10">
              <div className="flex flex-col">
                <div className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-primary rounded-full animate-pulse" />
                  <span className="text-[8px] font-mono text-primary font-bold uppercase tracking-widest">Protocol_Input</span>
                </div>
                <h2 className="text-xl font-anton text-white uppercase tracking-wider">Initialize Forge</h2>
              </div>
              <button 
                onClick={onClose}
                className="p-2 hover:bg-white/5 rounded-full transition-colors"
                title="Close"
              >
                <X className="w-5 h-5 text-slate-500 hover:text-white" />
              </button>
            </header>

            <form onSubmit={handleSubmit} className="p-8 space-y-8 relative z-10">
              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Project_Identifier</label>
                  <input 
                    type="text" 
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter project title..."
                    required
                    disabled={isLoading}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white font-mono text-sm focus:outline-none focus:border-primary/50 transition-colors placeholder:text-slate-700"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">System_Description</label>
                  <textarea 
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe the technical parameters and scope..."
                    rows={4}
                    disabled={isLoading}
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-4 text-white font-mono text-sm focus:outline-none focus:border-primary/50 transition-colors placeholder:text-slate-700 resize-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block font-bold">Research_Field</label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {fields.map((f) => (
                      <button
                        key={f}
                        type="button"
                        onClick={() => setField(f)}
                        className={`px-3 py-2 rounded-lg border text-[10px] font-bold uppercase tracking-widest transition-all ${
                          field === f 
                            ? "bg-primary text-white border-primary shadow-[0_0_15px_rgba(139,92,246,0.3)]" 
                            : "bg-white/5 border-white/5 text-slate-500 hover:border-white/20 hover:text-slate-300"
                        }`}
                      >
                        {f}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-white/5">
                <button
                  type="submit"
                  disabled={isLoading || !title.trim()}
                  className="w-full py-5 bg-white text-black font-anton text-lg uppercase tracking-[0.2em] rounded-2xl hover:bg-slate-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed group"
                >
                  <div className="flex items-center justify-center gap-3">
                    {isLoading ? (
                      <div className="w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    ) : (
                      <Zap className="w-5 h-5 group-hover:fill-current transition-all" />
                    )}
                    <span>{isLoading ? "Synthesizing..." : "Initiate Forge"}</span>
                  </div>
                </button>
              </div>

              <div className="flex items-center justify-center gap-4 text-[8px] font-mono text-slate-600 uppercase tracking-widest">
                <div className="flex items-center gap-1">
                  <Activity className="w-3 h-3" />
                  <span>CPU_Optimal</span>
                </div>
                <div className="flex items-center gap-1">
                  <Cpu className="w-3 h-3" />
                  <span>Logic_Bound</span>
                </div>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};
