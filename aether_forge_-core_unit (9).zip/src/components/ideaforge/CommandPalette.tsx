import React, { useEffect, useState } from "react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from "@/components/ui/command";
import { Idea } from "@/services/geminiService";
import { Search, Box, BookOpen, Layers, ArrowRight } from "lucide-react";

interface CommandPaletteProps {
  ideas: Idea[];
  onSelectProject: (idea: Idea) => void;
}

export function CommandPalette({ ideas, onSelectProject }: CommandPaletteProps) {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((open) => !open);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  const handleSelect = (idea: Idea) => {
    setOpen(false);
    onSelectProject(idea);
  };

  // Flatten nested items for search
  const allReferences = ideas.flatMap(i => 
    (i.research?.references || []).map(ref => ({ idea: i, ref }))
  );
  
  const allComponents = ideas.flatMap(i => 
    (i.components || []).map(comp => ({ idea: i, comp }))
  );

  return (
    <>
      <button 
        onClick={() => setOpen(true)}
        className="fixed bottom-8 left-8 z-[60] flex items-center gap-3 px-4 py-2 bg-black/80 backdrop-blur-md border border-white/10 rounded-full hover:border-primary/50 transition-all group"
      >
        <Search className="w-4 h-4 text-slate-500 group-hover:text-primary transition-colors" />
        <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Command Palette</span>
        <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border border-white/10 bg-white/5 px-1.5 font-mono text-[10px] font-medium text-slate-500 opacity-100">
          <span className="text-xs">⌘</span>K
        </kbd>
      </button>

      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder="Search projects, research, components..." />
        <CommandList className="max-h-[400px]">
          <CommandEmpty>No results found.</CommandEmpty>
          
          <CommandGroup heading="Projects">
            {ideas.map((idea, idx) => (
              <CommandItem
                key={`project-cmd-${idea.id || idea.idea}-${idx}`}
                onSelect={() => handleSelect(idea)}
                className="flex items-center justify-between cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <Box className="w-4 h-4 text-primary" />
                  <span className="font-medium">{idea.idea}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-slate-500 uppercase">{idea.difficulty}</span>
                  <ArrowRight className="w-3 h-3 text-slate-700" />
                </div>
              </CommandItem>
            ))}
          </CommandGroup>

          <CommandSeparator />

          {allReferences.length > 0 && (
            <CommandGroup heading="Research References">
              {allReferences.slice(0, 10).map(({ idea, ref }, idx) => (
                <CommandItem
                  key={`ref-${idx}`}
                  onSelect={() => handleSelect(idea)}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <BookOpen className="w-4 h-4 text-amber-500/50" />
                    <div className="flex flex-col">
                      <span className="text-xs font-medium truncate max-w-[200px]">{ref}</span>
                      <span className="text-[9px] text-slate-500 uppercase">Project: {idea.idea}</span>
                    </div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}

          <CommandSeparator />

          {allComponents.length > 0 && (
            <CommandGroup heading="Components (BOM)">
              {allComponents.slice(0, 10).map(({ idea, comp }, idx) => (
                <CommandItem
                  key={`comp-${idx}`}
                  onSelect={() => handleSelect(idea)}
                  className="flex items-center justify-between cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <Layers className="w-4 h-4 text-slate-500" />
                    <div className="flex flex-col">
                      <span className="text-xs font-medium">{comp.name}</span>
                      <span className="text-[9px] text-slate-500 uppercase">{comp.category} • Project: {idea.idea}</span>
                    </div>
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </>
  );
}
