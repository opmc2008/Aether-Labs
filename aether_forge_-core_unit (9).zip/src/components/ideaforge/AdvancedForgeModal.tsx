import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Cpu, Zap, Layers, Sparkles, Send, Type, Shield, Terminal, Gauge } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";

interface AdvancedForgeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onForge: (prompt: string, title?: string) => void;
  isLoading?: boolean;
}

export function AdvancedForgeModal({ open, onOpenChange, onForge, isLoading }: AdvancedForgeModalProps) {
  const [prompt, setPrompt] = useState("");
  const [title, setTitle] = useState("");
  const [complexity, setComplexity] = useState([70]);
  const [bitrate, setBitrate] = useState(0);
  const [activeParameters, setActiveParameters] = useState<string[]>(["High_Fidelity"]);
  const [platform, setPlatform] = useState("Arduino");
  const [budget, setBudget] = useState("");
  const [level, setLevel] = useState("Prototype");
  const [safety, setSafety] = useState("Standard");
  const [environment, setEnvironment] = useState("Indoor");
  const [connectivity, setConnectivity] = useState("Wireless Mesh");
  const [scale, setScale] = useState("Single Unit");
  const [power, setPower] = useState("Li-Po Battery");
  const [thermal, setThermal] = useState("Passive Fin");

  const onClose = () => onOpenChange(false);

  useEffect(() => {
    if (open) {
      const interval = setInterval(() => {
        setBitrate(Math.floor(Math.random() * 500) + 1200);
      }, 100);
      return () => clearInterval(interval);
    }
  }, [open]);

  const toggleParam = (param: string) => {
    setActiveParameters(prev => 
      prev.includes(param) ? prev.filter(p => p !== param) : [...prev, param]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      let enhancedPrompt = prompt.trim();
      
      const techSpecs = [
        `Platform: ${platform}`,
        `Deployment Level: ${level}`,
        `Safety: ${safety}`,
        `Environment: ${environment}`,
        `Connectivity: ${connectivity}`,
        `Scale: ${scale}`,
        `Power: ${power}`,
        `Thermal: ${thermal}`,
        budget ? `Budget Cap: ${budget} BDT` : null,
        `Complexity: ${complexity[0]}%`
      ].filter(Boolean).join(" | ");

      enhancedPrompt = `[TECH_SPEC: ${techSpecs}]\n\n${enhancedPrompt}`;
      
      if (activeParameters.length > 0) {
        enhancedPrompt += `\n\nTechnical Directives: ${activeParameters.join(", ")}.`;
      }
      
      onForge(enhancedPrompt, title.trim() || undefined);
      setPrompt("");
      setTitle("");
      onClose();
    }
  };

  const platforms = ["Arduino", "ESP32", "Raspberry Pi", "STM32", "Web/App"];
  const levels = ["Prototype", "MVP", "Industrial"];
  const safeties = ["Standard", "Enhanced", "Industrial", "Mil-Spec"];
  const environments = ["Indoor", "Outdoor", "Rugged", "Aerospace"];
  const connectivities = ["Wireless Mesh", "Cellular", "Offline", "Satellite"];
  const scales = ["Single Unit", "Swarm", "Fleet"];
  const powerSources = ["Li-Po Battery", "Solar Grid", "Super-Capacitor", "Wireless Xfer"];
  const thermals = ["Passive Fin", "Active Fan", "Liquid Loop", "Phase Change"];

  const paramOptions = [
    { label: "High_Fidelity", icon: Cpu, color: "text-blue-400", desc: "MAX_RESOLUTION" },
    { label: "Eco_Synergy", icon: Zap, color: "text-emerald-400", desc: "OPT_EFFICIENCY" },
    { label: "Core_Stability", icon: Layers, color: "text-amber-400", desc: "RIGID_STRUCTURE" },
    { label: "Neural_Link", icon: Shield, color: "text-purple-400", desc: "AI_INTEGRATION" },
  ];

  return (
    <AnimatePresence>
      {open && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={isLoading ? undefined : onClose}
            className="absolute inset-0 bg-black/80 backdrop-blur-md"
          />
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            className="relative w-full max-w-3xl bg-card border border-white/10 rounded-none overflow-y-auto max-h-[90vh] shadow-2xl"
          >
            {/* HUD Scanning Line */}
            <motion.div 
              animate={{ top: ["0%", "100%", "0%"] }}
              transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
              className="absolute left-0 right-0 h-px bg-primary/20 z-10 pointer-events-none"
            />

            {/* Header */}
            <div className="p-6 border-b border-white/5 flex items-center justify-between sticky top-0 bg-card/80 backdrop-blur-xl z-20">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="p-3 bg-primary/5 border border-primary/20 text-primary">
                    <Terminal className="w-5 h-5 phosphor-glow" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-primary animate-pulse" />
                </div>
                <div>
                  <h3 className="text-white font-black text-xl uppercase tracking-[0.3em] flex items-center gap-2">
                    Advanced_Forge
                    <span className="text-[8px] bg-white/5 border border-white/10 px-2 py-0.5 text-white/40">SYS_V4.3.0</span>
                  </h3>
                  <div className="flex items-center gap-4">
                    <p className="text-[9px] text-primary/40 font-mono uppercase tracking-[0.2em] font-black italic">Advanced_Multi_Param_Synthesis</p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 px-4">
                <span className="text-[9px] font-mono text-white/20 uppercase tracking-widest">STATION_LINK: STABLE</span>
                <button 
                  onClick={onClose}
                  className="p-2 hover:bg-white/5 rounded-none text-white/20 transition-colors"
                  disabled={isLoading}
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Content */}
            <div className="p-8 space-y-12">
              <form onSubmit={handleSubmit} className="space-y-12">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  {/* Basic Info */}
                  <div className="space-y-10">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Designation_Tag
                      </label>
                      <input
                        type="text"
                        placeholder="PROJECT_ALPH_LINK"
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full bg-black/50 border border-white/10 rounded-none px-6 py-5 text-white placeholder:text-white/5 focus:outline-none focus:border-primary focus:bg-primary/5 transition-all font-mono text-[11px] uppercase tracking-[0.3em] font-black"
                        disabled={isLoading}
                      />
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                          <div className="w-1 h-1 bg-primary" />
                          Computational_Depth
                        </label>
                        <span className="text-[10px] font-mono text-white/40">{complexity}%</span>
                      </div>
                      <div className="pt-4">
                        <Slider
                          value={complexity}
                          onValueChange={setComplexity}
                          max={100}
                          step={1}
                          className="cursor-pointer"
                          disabled={isLoading}
                        />
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Infrastructure_Level
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {levels.map((l) => (
                          <button
                            key={`lvl-${l}`}
                            type="button"
                            onClick={() => setLevel(l)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              level === l ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {l}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Power_Source
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {powerSources.map((p) => (
                          <button
                            key={`pwr-${p}`}
                            type="button"
                            onClick={() => setPower(p)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              power === p ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Thermal_Management
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {thermals.map((t) => (
                          <button
                            key={`thm-${t}`}
                            type="button"
                            onClick={() => setThermal(t)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              thermal === t ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {t}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Safety_Protocols
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {safeties.map((s) => (
                          <button
                            key={`safe-${s}`}
                            type="button"
                            onClick={() => setSafety(s)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              safety === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Technical Selectors */}
                  <div className="space-y-10">
                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Architecture_Platform
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {platforms.map((p) => (
                          <button
                            key={`plat-${p}`}
                            type="button"
                            onClick={() => setPlatform(p)}
                            className={`py-3 px-2 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              platform === p ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {p}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Environment
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {environments.map((e) => (
                          <button
                            key={`env-${e}`}
                            type="button"
                            onClick={() => setEnvironment(e)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              environment === e ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {e}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Connectivity
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {connectivities.map((c) => (
                          <button
                            key={`conn-${c}`}
                            type="button"
                            onClick={() => setConnectivity(c)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              connectivity === c ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Project_Scale
                      </label>
                      <div className="grid grid-cols-3 gap-2">
                        {scales.map((s) => (
                          <button
                            key={`scale-${s}`}
                            type="button"
                            onClick={() => setScale(s)}
                            className={`py-3 text-[9px] font-black tracking-widest uppercase border transition-all ${
                              scale === s ? "bg-primary text-black border-primary phosphor-glow" : "bg-black border-white/10 text-white/20 hover:border-white/40"
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-4">
                      <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                        <div className="w-1 h-1 bg-primary" />
                        Resource_Boundaries (Budget)
                      </label>
                      <div className="relative">
                        <div className="absolute left-6 top-1/2 -translate-y-1/2 text-primary font-black text-sm">৳</div>
                        <input
                          type="number"
                          placeholder="UNBOUNDED"
                          value={budget}
                          onChange={(e) => setBudget(e.target.value)}
                          className="w-full bg-black/50 border border-white/10 rounded-none px-12 py-5 text-white placeholder:text-white/5 focus:outline-none focus:border-primary focus:bg-primary/5 transition-all font-mono text-[11px] uppercase tracking-[0.3em] font-black"
                          disabled={isLoading}
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-primary uppercase tracking-[0.4em] flex items-center gap-3">
                    <div className="w-1 h-1 bg-primary" />
                    Neural_Directive_Buffer
                  </label>
                  <textarea
                    autoFocus
                    placeholder="ENTER_CORE_PROJECT_OBJECTIVES_AND_SPECIFIC_HARDWARE_REQUIREMENTS..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full h-48 bg-black/50 border border-white/10 rounded-none p-8 text-white placeholder:text-white/5 focus:outline-none focus:border-primary focus:bg-primary/5 transition-all resize-none font-mono text-[13px] uppercase tracking-[0.2em] leading-relaxed"
                    disabled={isLoading}
                  />
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-black text-primary/60 uppercase tracking-[0.4em] px-1 italic">
                    Binary_Synthesis_Toggles
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {paramOptions.map((item) => {
                      const isActive = activeParameters.includes(item.label);
                      return (
                        <div 
                          key={item.label} 
                          onClick={() => !isLoading && toggleParam(item.label)}
                          className={`bg-black border p-6 flex flex-col items-center gap-4 transition-all cursor-pointer group relative overflow-hidden ${
                            isActive 
                              ? "border-primary phosphor-glow bg-primary/5" 
                              : "border-white/5 opacity-40 hover:opacity-100 hover:border-white/20"
                          }`}
                        >
                          {isActive && (
                            <motion.div 
                              layoutId="active-param-indicator"
                              className="absolute top-0 right-0 w-2 h-2 bg-primary shadow-[0_0_8px_white]" 
                            />
                          )}
                          <item.icon className={`w-6 h-6 ${isActive ? item.color : "text-white/40"} group-hover:scale-110 transition-transform`} />
                          <div className="flex flex-col items-center gap-1">
                            <span className={`text-[10px] font-black uppercase tracking-widest text-center ${isActive ? "text-white" : "text-white/20"}`}>
                              {item.label}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="sticky bottom-0 pt-8 pb-4 bg-gradient-to-t from-card via-card to-transparent z-10">
                  <Button 
                    type="submit"
                    className="w-full h-20 bg-primary hover:bg-white text-black font-black text-[16px] uppercase tracking-[0.8em] shadow-[0_0_50px_rgba(var(--primary),0.2)] rounded-none relative group overflow-hidden border-none"
                    disabled={!prompt.trim() || isLoading}
                  >
                    <div className="absolute inset-0 bg-white/10 -translate-x-full group-hover:translate-x-0 transition-transform duration-700 ease-out" />
                    {isLoading ? (
                      <div className="flex items-center gap-6 relative z-10">
                        <div className="w-6 h-6 border-2 border-black/20 border-t-black rounded-full animate-spin" />
                        SYNTH_LEVEL_CRITICAL...
                      </div>
                    ) : (
                      <div className="flex items-center justify-center gap-6 relative z-10">
                        <Send className="w-6 h-6 group-hover:translate-x-4 group-hover:-translate-y-4 transition-all duration-500" />
                        EXECUTE_CONSTRUCT_PROTOCOL
                      </div>
                    )}
                  </Button>
                </div>
              </form>
            </div>

            {/* Footer */}
            <div className="px-8 py-6 bg-black/95 border-t border-white/5 flex items-center justify-between sticky bottom-0">
              <div className="flex items-center gap-8">
                <div className="flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-none bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)] animate-pulse" />
                  <span className="text-[10px] font-mono text-white/40 uppercase tracking-[0.5em] font-black">XFER_STABLE</span>
                </div>
                <div className="h-6 w-px bg-white/10" />
                <div className="flex items-center gap-4">
                  <Gauge className="w-4 h-4 text-white/20" />
                  <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.3em]">NEURAL_BANDWIDTH: {bitrate}kb/s</span>
                </div>
              </div>
              <span className="text-[10px] font-mono text-white/20 uppercase tracking-[0.5em] font-black">AETHER_FORGE // v4.3.0</span>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}


