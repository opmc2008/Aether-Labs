import React, { useState } from "react";
import { motion } from "motion/react";
import { Search, Terminal, Cpu, Zap, Activity } from "lucide-react";

interface HeroSectionProps {
  onForge: (prompt: string, isDirect?: boolean) => void;
  onAdvancedForge: () => void;
  isLoading: boolean;
}

export const HeroSection = ({ onForge, onAdvancedForge, isLoading }: HeroSectionProps) => {
  const [prompt, setPrompt] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (prompt.trim()) {
      onForge(prompt);
    }
  };

  const exampleTags = [
    "Autonomous Drone",
    "Smart Hydroponics",
    "Neural Interface",
    "Solar Tracker",
    "IoT Smart Lock",
    "Robotic Arm"
  ];

  return (
    <section className="relative min-h-screen flex flex-col items-center justify-center px-4 md:px-8 pt-20 overflow-hidden bg-background">
      {/* Dark Technical Atmosphere */}
      <div className="absolute inset-0 atmosphere opacity-100 pointer-events-none" />
      <div className="absolute inset-0 tech-grid opacity-30 pointer-events-none" />
      
      {/* Schematic Accents */}
      <div className="absolute top-0 left-0 w-full h-[30vh] border-b border-white/[0.03] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-full h-[40vh] border-t border-white/[0.03] pointer-events-none" />
      <div className="absolute left-[20%] top-0 w-px h-full bg-white/[0.03] pointer-events-none" />
      <div className="absolute right-[20%] top-0 w-px h-full bg-white/[0.03] pointer-events-none" />

      {/* Numerical Marking Accents */}
      <div className="absolute top-1/2 -translate-y-1/2 left-4 vertical-rl text-[9px] font-mono text-white/5 tracking-[1em] pointer-events-none">
        AETHER_FORGE_SYNTH_HUB
      </div>
      <div className="absolute top-1/2 -translate-y-1/2 right-4 vertical-rl text-[9px] font-mono text-white/5 tracking-[1em] pointer-events-none rotate-180">
        GEOMETRIC_ASSEMBLY_SYSTEM_v4.2
      </div>

      {/* Floating Cardboard Schematics */}
      <div className="absolute top-1/4 left-10 w-48 h-48 border border-white/10 bg-white/[0.02] rounded-none pointer-events-none animate-float shadow-[8px_8px_0px_rgba(0,0,0,0.8)] flex items-center justify-center">
        <div className="w-10 h-px bg-white/10" />
        <div className="h-10 w-px bg-white/10 absolute" />
      </div>
      <div className="absolute bottom-1/4 right-10 w-80 h-80 border border-white/10 bg-white/[0.02] rounded-none rotate-12 pointer-events-none animate-float-delayed shadow-[12px_12px_0px_rgba(0,0,0,0.8)] flex items-center justify-center">
        <Activity className="w-12 h-12 text-white/5" />
      </div>

      <div className="relative z-10 max-w-6xl w-full flex flex-col items-center">
        {/* Lab Unit Indicator */}
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center mb-12"
        >
          <div className="flex items-center gap-6 mb-4">
            <div className="h-[2px] w-12 bg-primary" />
            <span className="font-mono text-sm text-primary tracking-[0.6em] font-black phosphor-glow">AETHER_FORGE_SYNTH_CORE</span>
            <div className="h-[2px] w-12 bg-primary" />
          </div>
          <span className="text-[10px] font-mono tracking-[0.2em] text-white/30 uppercase font-black">STATION_TYPE: PARAMETRIC_FORGE</span>
        </motion.div>

        {/* Industrial Engineering Title */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="text-center mb-24 relative"
        >
          <h1 className="text-[12vw] font-black tracking-tighter leading-none text-white uppercase flex flex-col items-center">
            <span className="phosphor-glow">Aether</span>
            <span className="opacity-10" style={{ WebkitTextStroke: '1px rgba(255,255,255,0.4)' }}>Forge_</span>
          </h1>
          
          {/* Status Label (Stamp look) */}
          <div className="absolute -top-12 -right-8 hidden lg:block">
            <div className="p-4 bg-primary text-black flex flex-col gap-1 rounded-none -rotate-2">
              <span className="text-[11px] font-mono font-black tracking-widest">CRITICAL_SYSTEM</span>
              <span className="text-[8px] font-mono uppercase tracking-[0.2em] leading-none text-left opacity-80">PROT: 0xDEADBEEF</span>
            </div>
          </div>
        </motion.div>

        {/* Drafting Interface */}
        <motion.form 
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.8 }}
          onSubmit={handleSubmit}
          className="w-full max-w-4xl relative"
        >
          <div className="absolute -inset-1 border border-primary/20 rounded-none -z-10" />
          
          <div className="relative flex flex-col md:flex-row items-center bg-black border-2 border-primary rounded-none p-1 shadow-[20px_20px_0px_rgba(255,255,255,0.03)]">
            <div className="hidden md:flex pl-8 text-primary/40">
              <Terminal className="w-5 h-5" />
            </div>
            
            <input 
              type="text" 
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="INIT_NEURAL_PROMPT_SEQUENCE..."
              className="w-full bg-transparent border-none focus:outline-none py-8 md:py-12 px-8 text-white font-mono text-xs md:text-sm placeholder:text-white/10 uppercase tracking-[0.3em] font-medium"
              disabled={isLoading}
            />
            
            <div className="flex items-center gap-1 pr-1 w-full md:w-auto">
              <button 
                type="button"
                onClick={onAdvancedForge}
                className="hidden lg:flex items-center gap-3 px-8 py-8 bg-white/5 border border-white/10 rounded-none text-[10px] font-mono text-white/40 hover:text-white hover:bg-white/10 transition-all uppercase tracking-widest font-bold"
              >
                <Cpu className="w-4 h-4" />
                <span>ADV_ARCH</span>
              </button>
              
              <button 
                type="submit"
                disabled={isLoading || !prompt.trim()}
                className="flex-1 md:flex-none flex items-center justify-center gap-4 bg-primary text-black px-16 py-8 rounded-none font-sans font-black uppercase tracking-[0.2em] text-[14px] hover:invert transition-all disabled:opacity-50"
              >
                {isLoading ? "FORGING..." : "EXEC_CODE"}
                <Search className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.form>

        {/* Example Tags */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 flex flex-wrap justify-center gap-4"
        >
          {exampleTags.map((tag) => (
            <button
              key={`example-${tag}`}
              onClick={() => setPrompt(tag)}
              className="text-[10px] font-mono tracking-widest text-primary/40 uppercase px-4 py-2 border border-primary/10 rounded-none hover:bg-primary/10 hover:text-primary transition-all"
            >
              &gt; {tag.replace(/\s+/g, '_')}
            </button>
          ))}
        </motion.div>
      </div>

      {/* Bottom Accents */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
      <div className="absolute bottom-8 left-8 flex items-center gap-4 text-[8px] font-mono text-white/20 uppercase tracking-[0.3em]">
        <div className="w-12 h-px bg-white/10" />
        <span>Aether_Forge_v4.0</span>
      </div>
    </section>
  );
};
