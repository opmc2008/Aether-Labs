import { useRef, useMemo } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface Idea {
  idea: string;
  plan: string;
  code: string;
  field: string;
}

interface ProjectVisualizerProps {
  field: string | null;
  idea: Idea | null;
}

// Keyword matching to pick the right visualization
function detectProjectType(idea: Idea | null, field: string | null): string {
  if (!idea && !field) return "none";
  const text = (idea?.idea || "").toLowerCase() + " " + (idea?.plan || "").toLowerCase() + " " + (field || "").toLowerCase();

  if (text.match(/robot|arm|servo|motor|actuator|gripper|manipulator|dof|kinematic/)) return "robotic-arm";
  if (text.match(/drone|uav|quadcopter|flight|propeller|aerial/)) return "drone";
  if (text.match(/neural|network|cnn|deep.?learning|vision|tensorflow|model|training/)) return "neural-net";
  if (text.match(/solar|panel|mppt|photovoltaic|renewable|charge.?controller/)) return "solar";
  if (text.match(/circuit|led|resistor|capacitor|voltage|current|ohm/)) return "circuit";
  if (text.match(/sensor|iot|mesh|lora|mqtt|temperature|humidity|moisture/)) return "iot-mesh";
  if (text.match(/rover|obstacle|autonomous|navigation|lidar|ultrasonic/)) return "rover";
  if (text.match(/balanc|imu|gyro|pid|mpu/)) return "balancer";
  if (text.match(/swarm|formation|multi.?agent|flock/)) return "swarm";
  if (text.match(/energy|battery|power|wind|turbine/)) return "energy";
  if (text.match(/ai|artificial|intelligence|machine.?learning/)) return "neural-net";
  if (field === "Robotics") return "robotic-arm";
  if (field === "Energy") return "solar";
  if (field === "IoT") return "iot-mesh";
  if (field === "AI") return "neural-net";
  return "generic";
}

// ========== Visualizations ==========

function RoboticArmViz() {
  const base = useRef<THREE.Group>(null!);
  const arm1 = useRef<THREE.Group>(null!);
  const arm2 = useRef<THREE.Group>(null!);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (base.current) base.current.rotation.y = Math.sin(t * 0.3) * 0.8;
    if (arm1.current) arm1.current.rotation.z = Math.sin(t * 0.5) * 0.4 - 0.2;
    if (arm2.current) arm2.current.rotation.z = Math.sin(t * 0.7 + 1) * 0.5;
  });

  return (
    <group position={[0, -2, 0]} scale={[4, 4, 4]}>
      {/* Base */}
      <mesh><cylinderGeometry args={[1, 1.2, 0.3, 16]} /><meshStandardMaterial color="#374151" metalness={0.8} roughness={0.2} /></mesh>
      <group ref={base}>
        {/* Shoulder */}
        <mesh position={[0, 0.3, 0]}><cylinderGeometry args={[0.2, 0.2, 0.4, 12]} /><meshStandardMaterial color="#7c3aed" metalness={0.7} roughness={0.3} /></mesh>
        <group ref={arm1} position={[0, 0.5, 0]}>
          {/* Upper arm */}
          <mesh position={[0, 0.6, 0]}><boxGeometry args={[0.12, 1.2, 0.12]} /><meshStandardMaterial color="#9333ea" emissive="#9333ea" emissiveIntensity={0.15} metalness={0.6} roughness={0.3} /></mesh>
          {/* Elbow joint */}
          <mesh position={[0, 1.2, 0]}><sphereGeometry args={[0.12, 16, 16]} /><meshStandardMaterial color="#a855f7" emissive="#a855f7" emissiveIntensity={0.3} /></mesh>
          <group ref={arm2} position={[0, 1.2, 0]}>
            {/* Forearm */}
            <mesh position={[0, 0.45, 0]}><boxGeometry args={[0.09, 0.9, 0.09]} /><meshStandardMaterial color="#c084fc" emissive="#c084fc" emissiveIntensity={0.1} metalness={0.6} roughness={0.3} /></mesh>
            {/* Gripper */}
            <mesh position={[-0.08, 0.95, 0]}><boxGeometry args={[0.04, 0.2, 0.06]} /><meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.3} /></mesh>
            <mesh position={[0.08, 0.95, 0]}><boxGeometry args={[0.04, 0.2, 0.06]} /><meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.3} /></mesh>
          </group>
        </group>
      </group>
    </group>
  );
}

function DroneViz() {
  const body = useRef<THREE.Group>(null!);
  const props = useRef<THREE.Group[]>([]);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (body.current) {
      body.current.position.y = 1 + Math.sin(t * 0.8) * 0.3;
      body.current.rotation.y = t * 0.2;
      body.current.rotation.z = Math.sin(t * 0.5) * 0.05;
    }
    props.current.forEach(p => { if (p) p.rotation.y = t * 25; });
  });

  const armPositions: [number, number, number][] = [[1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1]];

  return (
    <group ref={body} position={[0, 1, 0]} scale={[3.5, 3.5, 3.5]}>
      {/* Center body */}
      <mesh><boxGeometry args={[0.5, 0.15, 0.5]} /><meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.2} /></mesh>
      {/* Camera */}
      <mesh position={[0, -0.15, 0.15]}><sphereGeometry args={[0.08, 12, 12]} /><meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.5} /></mesh>
      {/* Arms + propellers */}
      {armPositions.map((pos, i) => (
        <group key={`drone-arm-${i}`}>
          <mesh position={[pos[0] * 0.5, 0, pos[2] * 0.5]} rotation={[0, Math.atan2(pos[2], pos[0]), 0]}>
            <boxGeometry args={[0.7, 0.05, 0.05]} /><meshStandardMaterial color="#475569" metalness={0.7} />
          </mesh>
          <group position={[pos[0], 0.05, pos[2]]} ref={el => { if (el) props.current[i] = el; }}>
            <mesh><cylinderGeometry args={[0.3, 0.3, 0.02, 3]} /><meshStandardMaterial color="#00d4aa" transparent opacity={0.4} /></mesh>
          </group>
          {/* Motor */}
          <mesh position={[pos[0], 0, pos[2]]}><cylinderGeometry args={[0.08, 0.08, 0.1, 8]} /><meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.3} /></mesh>
        </group>
      ))}
    </group>
  );
}

function NeuralNetViz() {
  const layers = useMemo(() => {
    const l1: [number, number, number][] = [[-2, 1.5, 0], [-2, 0.5, 0], [-2, -0.5, 0], [-2, -1.5, 0]];
    const l2: [number, number, number][] = [[-0.7, 1, 0], [-0.7, 0, 0], [-0.7, -1, 0], [-0.7, 1, 1], [-0.7, -1, -1]];
    const l3: [number, number, number][] = [[0.7, 0.7, 0], [0.7, -0.3, 0], [0.7, 0, 0.8]];
    const l4: [number, number, number][] = [[2, 0.2, 0], [2, -0.5, 0]];
    return [l1, l2, l3, l4];
  }, []);

  return (
    <group position={[0, 0.5, 0]} scale={[4, 4, 4]}>
      {layers.map((layer, li) =>
        layer.map((pos, ni) => (
          <NeuralNodeViz
            key={`${li}-${ni}`}
            position={pos}
            connections={li < layers.length - 1 ? layers[li + 1] : []}
            layerIndex={li}
          />
        ))
      )}
    </group>
  );
}

function NeuralNodeViz({ position, connections, layerIndex }: { position: [number, number, number]; connections: [number, number, number][]; layerIndex: number }) {
  const ref = useRef<THREE.Mesh>(null!);
  const colors = ["#00d4aa", "#3b82f6", "#f59e0b", "#ef4444"];
  const color = colors[layerIndex % colors.length];

  useFrame(({ clock }) => {
    if (!ref.current) return;
    const mat = ref.current.material as THREE.MeshStandardMaterial;
    mat.emissiveIntensity = 0.2 + Math.sin(clock.elapsedTime * 2 + position[0] * 3 + layerIndex) * 0.4;
  });

  const lineMat = useMemo(() => new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.2 }), [color]);
  const geos = useMemo(() => connections.map(t => new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...position), new THREE.Vector3(...t)])), [position, connections]);

  return (
    <group>
      <mesh ref={ref} position={position}>
        <sphereGeometry args={[0.12, 16, 16]} />
        <meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.3} metalness={0.8} roughness={0.2} />
      </mesh>
      {geos.map((g, i) => <primitive key={`geo-${i}`} object={new THREE.Line(g, lineMat)} />)}
    </group>
  );
}

function SolarViz() {
  const panels = useRef<THREE.Group>(null!);
  const randomOffsets = useMemo(() => [0, 1, 2, 3, 4].map((i) => (i % 5) * 0.05), []);

  useFrame(({ clock }) => {
    if (panels.current) panels.current.rotation.x = Math.sin(clock.elapsedTime * 0.2) * 0.15 - 0.3;
  });

  return (
    <group position={[0, -1, 0]} scale={[3.0, 3.0, 3.0]}>
      {/* Ground */}
      <mesh rotation={[-Math.PI / 2, 0, 0]}><planeGeometry args={[8, 6]} /><meshStandardMaterial color="#0f172a" transparent opacity={0.5} /></mesh>
      {/* Panel array */}
      {[[-2, 0], [0, 0], [2, 0], [-1, -1.5], [1, -1.5]].map(([x, z], i) => (
        <group key={`panel-${i}`} ref={i === 0 ? panels : undefined} position={[x, 1.2 + randomOffsets[i], z]}>
          <mesh><boxGeometry args={[1.4, 0.04, 0.9]} /><meshStandardMaterial color="#1e40af" emissive="#3b82f6" emissiveIntensity={0.15} metalness={0.6} /></mesh>
          {[-0.35, 0, 0.35].map((gx, gi) => (
            <mesh key={`grid-${gi}`} position={[gx, 0.025, 0]}><boxGeometry args={[0.02, 0.01, 0.88]} /><meshStandardMaterial color="#93c5fd" emissive="#93c5fd" emissiveIntensity={0.2} /></mesh>
          ))}
          <mesh position={[0, -0.5, 0.3]}><boxGeometry args={[0.05, 1, 0.05]} /><meshStandardMaterial color="#475569" metalness={0.7} /></mesh>
        </group>
      ))}
      {/* Battery box */}
      <mesh position={[3.2, 0.3, 0]}><boxGeometry args={[0.6, 0.6, 0.4]} /><meshStandardMaterial color="#f59e0b" emissive="#f59e0b" emissiveIntensity={0.2} /></mesh>
    </group>
  );
}

function IoTMeshViz() {
  const positions = useMemo(() => {
    const pts: [number, number, number][] = [];
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const r = 1.5 + (i % 2) * 1;
      pts.push([Math.cos(a) * r, 0.3 + Math.sin(i * 1.2) * 0.6, Math.sin(a) * r]);
    }
    return pts;
  }, []);
  const colors = ["#00d4aa", "#f59e0b", "#3b82f6", "#ef4444", "#7c3aed", "#10b981", "#f97316", "#06b6d4"];

  return (
    <group scale={[4, 4, 4]}>
      {/* Central hub */}
      <mesh position={[0, 0.5, 0]}>
        <dodecahedronGeometry args={[0.3, 0]} />
        <meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.5} metalness={0.9} roughness={0.1} />
      </mesh>
      {positions.map((pos, i) => <SensorNodeViz key={`sensor-${i}`} position={pos} color={colors[i]} hubPos={[0, 0.5, 0]} />)}
    </group>
  );
}

function SensorNodeViz({ position, color, hubPos }: { position: [number, number, number]; color: string; hubPos: [number, number, number] }) {
  const ref = useRef<THREE.Group>(null!);
  const ringRef = useRef<THREE.Mesh>(null!);

  useFrame(({ clock }) => {
    if (ref.current) ref.current.position.y = position[1] + Math.sin(clock.elapsedTime * 0.8 + position[0]) * 0.15;
    if (ringRef.current) {
      ringRef.current.rotation.z = clock.elapsedTime * 0.5;
      const s = 1 + Math.sin(clock.elapsedTime * 2) * 0.1;
      ringRef.current.scale.set(s, s, 1);
    }
  });

  const lineMat = useMemo(() => new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.25 }), [color]);
  const lineGeo = useMemo(() => new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(...position), new THREE.Vector3(...hubPos)]), [position, hubPos]);

  return (
    <group>
      <group ref={ref} position={position}>
        <mesh><octahedronGeometry args={[0.2, 0]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.4} metalness={0.9} roughness={0.1} /></mesh>
        <mesh ref={ringRef}><torusGeometry args={[0.35, 0.015, 8, 32]} /><meshStandardMaterial color={color} emissive={color} emissiveIntensity={0.3} transparent opacity={0.5} /></mesh>
      </group>
      <primitive object={new THREE.Line(lineGeo, lineMat)} />
    </group>
  );
}

function RoverViz() {
  const rover = useRef<THREE.Group>(null!);
  const wheels = useRef<THREE.Mesh[]>([]);

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    if (rover.current) {
      rover.current.position.x = Math.sin(t * 0.3) * 2;
      rover.current.position.z = Math.cos(t * 0.3) * 2;
      rover.current.rotation.y = -t * 0.3 + Math.PI / 2;
    }
    wheels.current.forEach(w => { if (w) w.rotation.x = t * 3; });
  });

  const wheelPositions: [number, number, number][] = [[-0.4, -0.15, 0.35], [0.4, -0.15, 0.35], [-0.4, -0.15, -0.35], [0.4, -0.15, -0.35]];

  return (
    <group ref={rover} position={[0, -1.5, 0]} scale={[4, 4, 4]}>
      {/* Body */}
      <mesh><boxGeometry args={[0.9, 0.25, 0.6]} /><meshStandardMaterial color="#374151" metalness={0.7} roughness={0.3} /></mesh>
      {/* Sensor turret */}
      <mesh position={[0.3, 0.2, 0]}><cylinderGeometry args={[0.1, 0.1, 0.15, 8]} /><meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.3} /></mesh>
      {/* Ultrasonic sensor */}
      <mesh position={[0.5, 0.05, 0]}><boxGeometry args={[0.08, 0.06, 0.15]} /><meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.4} /></mesh>
      {/* Wheels */}
      {wheelPositions.map((pos, i) => (
        <mesh key={`wheel-${i}`} position={pos} rotation={[0, 0, Math.PI / 2]} ref={el => { if (el) wheels.current[i] = el; }}>
          <cylinderGeometry args={[0.12, 0.12, 0.08, 12]} />
          <meshStandardMaterial color="#1e1e1e" metalness={0.5} roughness={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function BalancerViz() {
  const body = useRef<THREE.Group>(null!);

  useFrame(({ clock }) => {
    if (body.current) body.current.rotation.z = Math.sin(clock.elapsedTime * 1.5) * 0.15;
  });

  return (
    <group ref={body} position={[0, -1, 0]} scale={[4, 4, 4]}>
      {/* Body */}
      <mesh position={[0, 0.8, 0]}><boxGeometry args={[0.4, 1.2, 0.3]} /><meshStandardMaterial color="#475569" metalness={0.7} roughness={0.3} /></mesh>
      {/* IMU */}
      <mesh position={[0, 1, 0.16]}><boxGeometry args={[0.15, 0.15, 0.03]} /><meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.5} /></mesh>
      {/* Wheels */}
      <mesh position={[-0.25, 0.15, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.15, 0.15, 0.08, 16]} /><meshStandardMaterial color="#1e1e1e" /></mesh>
      <mesh position={[0.25, 0.15, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.15, 0.15, 0.08, 16]} /><meshStandardMaterial color="#1e1e1e" /></mesh>
    </group>
  );
}

function SwarmViz() {
  const agents = useMemo(() => {
    const pts: { pos: [number, number, number]; speed: number; offset: number }[] = [];
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      // Deterministic "random" values based on index
      const speed = 0.3 + (i % 3) * 0.1;
      pts.push({ pos: [Math.cos(a) * 2, 0.3, Math.sin(a) * 2], speed, offset: i * 1.2 });
    }
    return pts;
  }, []);

  return (
    <group scale={[4, 4, 4]}>
      {agents.map((a, i) => <SwarmAgent key={`agent-${i}`} initialPos={a.pos} speed={a.speed} offset={a.offset} />)}
    </group>
  );
}

function SwarmAgent({ initialPos, speed, offset }: { initialPos: [number, number, number]; speed: number; offset: number }) {
  const ref = useRef<THREE.Mesh>(null!);

  useFrame(({ clock }) => {
    if (!ref.current) return;
    const t = clock.elapsedTime * speed + offset;
    ref.current.position.x = initialPos[0] + Math.sin(t) * 0.5;
    ref.current.position.z = initialPos[2] + Math.cos(t * 1.3) * 0.5;
    ref.current.position.y = initialPos[1] + Math.sin(t * 2) * 0.15;
  });

  return (
    <mesh ref={ref} position={initialPos}>
      <coneGeometry args={[0.12, 0.25, 4]} />
      <meshStandardMaterial color="#f59e0b" emissive="#f59e0b" emissiveIntensity={0.3} metalness={0.7} roughness={0.3} />
    </mesh>
  );
}

function CircuitViz() {
  const ledRef = useRef<THREE.Mesh>(null!);

  useFrame(({ clock }) => {
    if (ledRef.current) {
      (ledRef.current.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.3 + Math.sin(clock.elapsedTime * 3) * 0.5;
    }
  });

  return (
    <group position={[0, -1, 0]} scale={[4, 4, 4]}>
      {/* PCB board */}
      <mesh><boxGeometry args={[3, 0.08, 2]} /><meshStandardMaterial color="#065f46" metalness={0.3} roughness={0.7} /></mesh>
      {/* Chip */}
      <mesh position={[0, 0.1, 0]}><boxGeometry args={[0.5, 0.12, 0.5]} /><meshStandardMaterial color="#1e1e1e" metalness={0.8} /></mesh>
      {/* LED */}
      <mesh ref={ledRef} position={[0.8, 0.15, 0.3]}><cylinderGeometry args={[0.06, 0.06, 0.15, 8]} /><meshStandardMaterial color="#ef4444" emissive="#ef4444" emissiveIntensity={0.5} /></mesh>
      {/* Resistors */}
      {[[-0.5, 0.5], [0.3, -0.5], [-0.8, -0.3]].map(([x, z], i) => (
        <mesh key={`res-${i}`} position={[x, 0.08, z]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.04, 0.04, 0.2, 8]} /><meshStandardMaterial color="#f59e0b" /></mesh>
      ))}
      {/* Traces */}
      {[[0, 0.8], [0.5, -0.2], [-1, 0]].map(([x, z], i) => (
        <mesh key={`trace-${i}`} position={[x, 0.045, z]}><boxGeometry args={[0.8, 0.005, 0.02]} /><meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.4} /></mesh>
      ))}
    </group>
  );
}

function GenericViz() {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame(({ clock }) => {
    if (ref.current) {
      ref.current.rotation.x = clock.elapsedTime * 0.3;
      ref.current.rotation.y = clock.elapsedTime * 0.5;
    }
  });

  return (
    <mesh ref={ref} position={[0, 0.5, 0]} scale={[4, 4, 4]}>
      <icosahedronGeometry args={[1, 1]} />
      <meshStandardMaterial color="#00d4aa" emissive="#00d4aa" emissiveIntensity={0.2} wireframe metalness={0.8} roughness={0.2} />
    </mesh>
  );
}

export function ProjectVisualizer({ field, idea }: ProjectVisualizerProps) {
  const projectType = detectProjectType(idea, field);

  switch (projectType) {
    case "robotic-arm": return <RoboticArmViz />;
    case "drone": return <DroneViz />;
    case "neural-net": return <NeuralNetViz />;
    case "solar": return <SolarViz />;
    case "energy": return <SolarViz />;
    case "circuit": return <CircuitViz />;
    case "iot-mesh": return <IoTMeshViz />;
    case "rover": return <RoverViz />;
    case "balancer": return <BalancerViz />;
    case "swarm": return <SwarmViz />;
    case "generic": return <GenericViz />;
    default: return null;
  }
}
