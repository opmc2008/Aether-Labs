import React from "react";
import { motion } from "motion/react";
import { Scene3D } from "@/components/ideaforge/Scene3D";
import { Idea } from "@/services/geminiService";
import { Trash2, ArrowUpRight, Box, Zap, DollarSign, Cloud, Save } from "lucide-react";

interface IdeaCardProps {
  idea: Idea & { isSaved?: boolean };
  index: number;
  isSelected: boolean;
  onSelect: () => void;
  onDelete: () => void;
  onSave?: () => void;
  isSaving?: boolean;
}

export const IdeaCard = ({ idea, index, isSelected, onSelect, onDelete, onSave, isSaving }: IdeaCardProps) => {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ y: -4 }}
      className={`relative group transition-all duration-200 cursor-pointer flex flex-col h-full bg-card border-2 border-primary/10 hover:border-primary/40 engineering-card`}
      onClick={onSelect}
    >
      {/* Decorative Rail Text */}
      <div className="absolute top-1/2 -translate-y-1/2 -left-3 vertical-rl opacity-10 pointer-events-none rotate-180">
        <span className="text-[6px] font-mono text-white tracking-[1em] uppercase">SYSTEM_ASSEMBLY_LOG_722_P_04</span>
      </div>

      {/* Hardware Coordinate Markers */}
      <div className="absolute top-2 left-2 p-1 text-[6px] font-mono text-primary/40 leading-none font-black">X_COORD_01</div>
      <div className="absolute bottom-2 left-2 p-1 text-[6px] font-mono text-primary/40 leading-none font-black">Y_COORD_72</div>

      {/* Technical Header */}
      <div className="flex justify-between items-center px-4 py-3 border-b border-primary/20 bg-primary/5">
        <div className="flex flex-col">
          <div className="flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-primary phosphor-glow animate-pulse-glow" />
            <span className="text-[10px] font-mono text-primary uppercase tracking-[0.4em] font-black">FORGE_ENTITY</span>
          </div>
          <span className="text-[9px] font-mono text-white/20 uppercase tracking-widest mt-1 font-black">ID: {idea.idea.slice(0, 8).toUpperCase()}</span>
        </div>
        
        <div className="flex items-center gap-1">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              if (!idea.isSaved && onSave) onSave();
            }}
            disabled={idea.isSaved || isSaving}
            className={`p-2 transition-all border ${
              idea.isSaved 
                ? 'bg-primary border-primary text-black' 
                : 'bg-black border-white/10 text-white/20 hover:text-white hover:border-primary'
            }`}
          >
            {idea.isSaved ? <Cloud className="w-3.5 h-3.5" /> : <Save className="w-3.5 h-3.5" />}
          </button>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
            className="p-2 bg-black border border-white/10 text-white/10 hover:text-red-600 hover:border-red-600 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Extreme Tech Preview */}
      <div className="relative h-44 md:h-52 bg-[#050505] tech-grid overflow-hidden border-b border-primary/20">
        <Scene3D selectedIdea={idea} isMini={true} activeField={idea.field} />
        
        <div className="absolute top-3 right-3">
          <div className="px-2 py-1 bg-black border border-primary text-primary text-[9px] font-mono font-black uppercase tracking-[0.2em]">
            &gt; {idea.field || "SYS"}
          </div>
        </div>
      </div>

      {/* Data Sheet Content */}
      <div className="p-6 md:p-8 flex-1 flex flex-col relative bg-black">
        <div className="space-y-4 flex-1 relative z-10">
          <div className="flex items-center gap-2">
            <div className="h-[1px] w-6 bg-primary" />
            <span className="font-mono text-[9px] text-primary uppercase tracking-[0.3em] font-bold">SPEC_BLOCK_04</span>
          </div>
          <h3 className="text-xl md:text-2xl font-sans font-black text-white uppercase tracking-tighter leading-tight line-clamp-2">
            {idea.idea}
          </h3>
          <p className="text-[10px] md:text-xs text-white/40 font-mono leading-relaxed line-clamp-3 uppercase tracking-tight">
            [DESC]: {idea.plan}
          </p>
        </div>

        <button 
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          className="mt-8 w-full flex items-center justify-between px-6 py-4 bg-primary text-black font-black uppercase tracking-[0.3em] group/btn hover:invert transition-all text-[11px]"
        >
          <span>BUILD_LOGIC</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Engineering Mark */}
      <div className="absolute bottom-2 right-2 flex items-center gap-1 opacity-20 pointer-events-none">
        <div className="w-4 h-px bg-primary" />
        <div className="w-1 h-px bg-primary" />
      </div>
    </motion.div>
  );
};
