import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { OrbitControls, Stars, Stage, Environment, ContactShadows, PerspectiveCamera, KeyboardControls, useKeyboardControls, GizmoHelper, GizmoViewport } from "@react-three/drei";
import { EffectComposer, Bloom, Noise, Vignette, SSAO } from "@react-three/postprocessing";
import { GridFloor } from "./GridFloor";
import { ProjectVisualizer } from "./ProjectVisualizer";
import { ExplodableModel, AIGeneratedModel } from "./ExplodableModel";
import { Suspense, useRef, useEffect } from "react";
import { GeneratedModelData, Idea } from "@/services/geminiService";
import * as THREE from "three";

interface Scene3DProps {
  activeField: string | null;
  selectedIdea: Idea | null;
  modelEmbedUrl?: string | null;
  explodeFactor?: number;
  generatedModelData?: GeneratedModelData | null;
  autoRotate?: boolean;
  showGrid?: boolean;
  wireframe?: boolean;
  ghost?: boolean;
  isMini?: boolean;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
}

function FreeMoveControls({ autoRotate, isMini, ideaId }: { autoRotate: boolean; isMini?: boolean; ideaId?: string }) {
  const { camera } = useThree();
  const [, get] = useKeyboardControls();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const controlsRef = useRef<any>(null);
  
  const lastIdeaId = useRef(ideaId);
  const isResetting = useRef(false);

  useEffect(() => {
    if (ideaId && ideaId !== lastIdeaId.current && !isMini) {
      isResetting.current = true;
      lastIdeaId.current = ideaId;
    }
  }, [ideaId, isMini]);

  useFrame((state, delta) => {
    if (isMini) return;
    const { forward, backward, left, right, up, down, reset } = get();
    
    if (reset || isResetting.current) {
      const targetPos = new THREE.Vector3(8, 6, 10);
      const alpha = 0.08; // Faster, snappier alpha transition
      camera.position.lerp(targetPos, alpha);
      
      if (controlsRef.current) {
        controlsRef.current.target.lerp(new THREE.Vector3(0, 0, 0), alpha);
      }

      if (camera.position.distanceTo(targetPos) < 0.01) {
        isResetting.current = false;
      }
    }

    if (forward || backward || left || right || up || down) {
      const speed = 60 * delta;
      const direction = new THREE.Vector3();
      const frontVector = new THREE.Vector3(0, 0, Number(backward) - Number(forward));
      const sideVector = new THREE.Vector3(Number(left) - Number(right), 0, 0);
      const verticalVector = new THREE.Vector3(0, Number(up) - Number(down), 0);

      direction
        .subVectors(frontVector, sideVector)
        .normalize()
        .multiplyScalar(speed)
        .applyQuaternion(camera.quaternion);
      
      // Add vertical movement
      direction.y += (Number(up) - Number(down)) * speed;

      camera.position.add(direction);
      if (controlsRef.current) {
        controlsRef.current.target.add(direction);
      }
    }
  });

  return (
    <group>
      <OrbitControls 
        ref={controlsRef}
        enableDamping 
        dampingFactor={0.05} 
        autoRotate={autoRotate} 
        autoRotateSpeed={0.5}
        maxPolarAngle={Math.PI / 1.5}
        minDistance={1}
        maxDistance={100}
        makeDefault
        enableZoom={!isMini}
        enablePan={!isMini}
        enableRotate={!isMini}
        screenSpacePanning={true}
      />
      {!isMini && (
        <GizmoHelper alignment="bottom-right" margin={[80, 80]}>
          <GizmoViewport axisColors={["#ef4444", "#22c55e", "#3b82f6"]} labelColor="white" />
        </GizmoHelper>
      )}
    </group>
  );
}

// Keyword matching to pick the right visualization type
function detectProjectType(idea: Idea | null, field: string | null): string {
  if (!idea && !field) return "none";
  const text = (idea?.idea || "").toLowerCase() + " " + (idea?.plan || "").toLowerCase() + " " + (field || "").toLowerCase();
  if (text.match(/aether|forge|core.?unit|synthesis|lattice|spatial/)) return "aether-core";
  if (text.match(/robot|arm|servo|motor|actuator|gripper|manipulator|dof|kinematic/)) return "robotic-arm";
  if (text.match(/drone|uav|quadcopter|flight|propeller|aerial/)) return "drone";
  if (text.match(/neural|network|cnn|deep.?learning|vision|tensorflow|model|training/)) return "neural-net";
  if (text.match(/solar|panel|mppt|photovoltaic|renewable|charge.?controller/)) return "solar";
  if (text.match(/circuit|led|resistor|capacitor|voltage|current|ohm/)) return "circuit";
  if (text.match(/sensor|iot|mesh|lora|mqtt|temperature|humidity|moisture/)) return "iot-mesh";
  if (text.match(/rover|obstacle|autonomous|navigation|lidar|ultrasonic/)) return "rover";
  if (text.match(/balanc|imu|gyro|pid|mpu/)) return "balancer";
  if (text.match(/swarm|formation|multi.?agent|flock/)) return "swarm";
  if (text.match(/energy|battery|power|wind|turbine/)) return "energy";
  if (text.match(/ai|artificial|intelligence|machine.?learning/)) return "neural-net";
  if (field === "Robotics") return "robotic-arm";
  if (field === "Energy") return "solar";
  if (field === "IoT") return "iot-mesh";
  if (field === "AI") return "neural-net";
  return "generic";
}

export function Scene3D({ 
  activeField, 
  selectedIdea, 
  explodeFactor = 0, 
  generatedModelData, 
  autoRotate = true, 
  showGrid = true, 
  wireframe = false, 
  ghost = false,
  isMini = false,
  simulationActive = false,
  spreadMode = 'GRID',
  activeComponent = null,
  onComponentSelect
}: Scene3DProps) {
  const projectType = detectProjectType(selectedIdea, activeField);

  return (
    <KeyboardControls
      map={[
        { name: "forward", keys: ["ArrowUp", "w", "W"] },
        { name: "backward", keys: ["ArrowDown", "s", "S"] },
        { name: "left", keys: ["ArrowLeft", "a", "A"] },
        { name: "right", keys: ["ArrowRight", "d", "D"] },
        { name: "up", keys: ["Space", "q", "Q"] },
        { name: "down", keys: ["Shift", "e", "E"] },
        { name: "reset", keys: ["r", "R"] },
      ]}
    >
      <Canvas shadows gl={{ antialias: true, stencil: false, depth: true }} style={{ background: "transparent" }}>
        <PerspectiveCamera makeDefault position={isMini ? [5, 4, 5] : [8, 6, 10]} fov={isMini ? 35 : 45} />
        
        <ambientLight intensity={0.4} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} castShadow />
        <pointLight position={[-10, -10, -10]} intensity={1} color="#7c3aed" />
        
        <Suspense fallback={null}>
          <Environment preset="city" />
          
          <Stage intensity={0.8} environment="city" adjustCamera={0.6} contactShadow={true} shadowBias={-0.001}>
            {generatedModelData ? (
              <AIGeneratedModel 
                data={generatedModelData} 
                explodeFactor={explodeFactor} 
                wireframe={wireframe} 
                ghost={ghost}
                activeComponent={activeComponent}
                onComponentSelect={onComponentSelect}
                simulationActive={simulationActive}
                spreadMode={spreadMode}
              />
            ) : projectType !== "none" ? (
              <ExplodableModel 
                projectType={projectType} 
                explodeFactor={explodeFactor} 
                wireframe={wireframe} 
                ghost={ghost} 
                activeComponent={activeComponent}
                onComponentSelect={onComponentSelect}
                simulationActive={simulationActive}
                spreadMode={spreadMode}
              />
            ) : (
              <ProjectVisualizer field={activeField} idea={selectedIdea} />
            )}
          </Stage>

          {showGrid && !isMini && <GridFloor position={[0, -1, 0]} />}
          {!isMini && <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />}
          
          <EffectComposer disableNormalPass>
            <Bloom luminanceThreshold={1} luminanceSmoothing={0.9} height={300} opacity={0.5} />
            {!isMini && <Noise opacity={0.02} />}
            {!isMini && <Vignette eskil={false} offset={0.1} darkness={1.1} />}
          </EffectComposer>
        </Suspense>

        <FreeMoveControls autoRotate={autoRotate} isMini={isMini} ideaId={selectedIdea?.id} />
      </Canvas>
    </KeyboardControls>
  );
}
