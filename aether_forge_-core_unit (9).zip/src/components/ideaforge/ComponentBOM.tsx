import { useMemo } from "react";
import { motion } from "motion/react";

interface Component {
  name: string;
  price: number;
  quantity: number;
  category: string;
}

interface Idea {
  idea: string;
  plan: string;
  code: string;
  field: string;
  components?: Component[];
}

// Generate BOM from project keywords — prices in BDT
function generateBOM(idea: Idea): Component[] {
  if (idea.components?.length) return idea.components;

  const text = (idea.idea + " " + idea.plan).toLowerCase();
  const parts: Component[] = [];

  // MCU
  if (text.match(/arduino|atmega/)) parts.push({ name: "Arduino Uno R3", price: 1500, quantity: 1, category: "MCU" });
  else if (text.match(/esp32|wifi|bluetooth|iot/)) parts.push({ name: "ESP32 DevKit", price: 1100, quantity: 1, category: "MCU" });
  else if (text.match(/raspberry|pi|linux/)) parts.push({ name: "Raspberry Pi 4B", price: 6600, quantity: 1, category: "MCU" });
  else if (text.match(/stm32/)) parts.push({ name: "STM32 Blue Pill", price: 550, quantity: 1, category: "MCU" });
  else parts.push({ name: "Arduino Nano", price: 850, quantity: 1, category: "MCU" });

  // Sensors
  if (text.match(/temperature|temp|therm/)) parts.push({ name: "DHT22 Temp/Humidity", price: 550, quantity: 1, category: "Sensor" });
  if (text.match(/ultrasonic|distance|obstacle/)) parts.push({ name: "HC-SR04 Ultrasonic", price: 360, quantity: 2, category: "Sensor" });
  if (text.match(/imu|gyro|accel|mpu|balanc/)) parts.push({ name: "MPU6050 IMU", price: 420, quantity: 1, category: "Sensor" });
  if (text.match(/moisture|soil|plant/)) parts.push({ name: "Soil Moisture Sensor", price: 240, quantity: 2, category: "Sensor" });
  if (text.match(/light|ldr|photo|lux/)) parts.push({ name: "LDR Photoresistor", price: 60, quantity: 3, category: "Sensor" });
  if (text.match(/pir|motion|infrared/)) parts.push({ name: "HC-SR501 PIR", price: 300, quantity: 1, category: "Sensor" });
  if (text.match(/camera|vision|image/)) parts.push({ name: "OV7670 Camera", price: 970, quantity: 1, category: "Sensor" });
  if (text.match(/gps|location|track/)) parts.push({ name: "NEO-6M GPS Module", price: 1200, quantity: 1, category: "Sensor" });
  if (text.match(/lidar|tof/)) parts.push({ name: "VL53L0X ToF LiDAR", price: 1090, quantity: 1, category: "Sensor" });
  if (text.match(/emg|muscle|myoware/)) parts.push({ name: "MyoWare 2.0 EMG Sensor", price: 4800, quantity: 1, category: "Sensor" });
  if (text.match(/eeg|brain|neuro/)) parts.push({ name: "AD8232 ECG/EEG Module", price: 600, quantity: 1, category: "Sensor" });
  if (text.match(/current|acs712|power.?monitor/)) parts.push({ name: "ACS712 Current Sensor", price: 350, quantity: 1, category: "Sensor" });
  if (text.match(/gas|mq|smoke|air.?quality/)) parts.push({ name: "MQ-135 Gas Sensor", price: 280, quantity: 1, category: "Sensor" });
  if (text.match(/color|tcs|rgb.?sensor/)) parts.push({ name: "TCS34725 Color Sensor", price: 520, quantity: 1, category: "Sensor" });
  if (text.match(/ir.?line|line.?follow|tcrt/)) parts.push({ name: "TCRT5000 IR Sensor", price: 80, quantity: 5, category: "Sensor" });

  // Actuators
  if (text.match(/motor|dc|drive|wheel|rover/)) parts.push({ name: "DC Motor + Driver L298N", price: 780, quantity: 2, category: "Actuator" });
  if (text.match(/servo|arm|gripper|pan|tilt/)) parts.push({ name: "SG90 Micro Servo", price: 420, quantity: 3, category: "Actuator" });
  if (text.match(/stepper|cnc|3d.?print/)) parts.push({ name: "NEMA 17 Stepper", price: 1450, quantity: 2, category: "Actuator" });
  if (text.match(/relay|switch|control|pump/)) parts.push({ name: "4-Channel Relay", price: 600, quantity: 1, category: "Actuator" });
  if (text.match(/propeller|drone|quadcopter|brushless/)) parts.push({ name: "A2212 Brushless Motor", price: 1090, quantity: 4, category: "Actuator" });
  if (text.match(/solenoid|valve|water/)) parts.push({ name: "12V Solenoid Valve", price: 450, quantity: 1, category: "Actuator" });

  // Display
  if (text.match(/display|oled|screen|lcd/)) parts.push({ name: '0.96" OLED Display', price: 720, quantity: 1, category: "Display" });
  if (text.match(/tft|color.?display|ili9341/)) parts.push({ name: '2.4" TFT LCD Display', price: 1200, quantity: 1, category: "Display" });
  if (text.match(/led.?bar|bar.?graph/)) parts.push({ name: "10-Segment LED Bar Graph", price: 120, quantity: 1, category: "Display" });

  // Communication
  if (text.match(/lora|long.?range/)) parts.push({ name: "LoRa SX1278 Module", price: 1150, quantity: 2, category: "Communication" });
  if (text.match(/nrf|mesh|wireless/)) parts.push({ name: "nRF24L01+ Module", price: 360, quantity: 2, category: "Communication" });
  if (text.match(/mqtt|cloud|server/)) parts.push({ name: "WiFi Antenna", price: 180, quantity: 1, category: "Communication" });
  if (text.match(/bluetooth|ble|hc.?05/)) parts.push({ name: "HC-05 Bluetooth Module", price: 480, quantity: 1, category: "Communication" });

  // Power
  if (text.match(/solar|photovoltaic/)) parts.push({ name: "6V 2W Solar Panel", price: 1090, quantity: 2, category: "Power" });
  if (text.match(/battery|lipo|lithium/)) parts.push({ name: "3.7V 2200mAh LiPo", price: 970, quantity: 1, category: "Power" });
  else parts.push({ name: "9V Battery + Holder", price: 420, quantity: 1, category: "Power" });
  if (text.match(/mppt|charge/)) parts.push({ name: "TP4056 Charge Module", price: 180, quantity: 1, category: "Power" });

  // Passives always included
  parts.push({ name: "Resistor Kit (assorted)", price: 480, quantity: 1, category: "Passive" });
  parts.push({ name: "Capacitor Kit (assorted)", price: 540, quantity: 1, category: "Passive" });
  parts.push({ name: "LED Pack (RGB)", price: 300, quantity: 1, category: "Passive" });
  parts.push({ name: "Breadboard + Jumpers", price: 720, quantity: 1, category: "Passive" });
  parts.push({ name: "PCB Prototype Board", price: 480, quantity: 1, category: "Passive" });

  return parts;
}

const categoryColors: Record<string, string> = {
  MCU: "text-white",
  Sensor: "text-zinc-300",
  Actuator: "text-zinc-400",
  Display: "text-zinc-200",
  Communication: "text-zinc-500",
  Power: "text-white",
  Passive: "text-muted-foreground",
};

const categoryIcons: Record<string, string> = {
  MCU: "💻",
  Sensor: "📡",
  Actuator: "⚙️",
  Display: "🖥️",
  Communication: "📶",
  Power: "🔋",
  Passive: "🔧",
};

function formatBDT(amount: number): string {
  return `৳${amount.toLocaleString("en-IN")}`;
}

export function ComponentBOM({ 
  idea, 
  activeComponent = null, 
  onComponentSelect 
}: { 
  idea: Idea; 
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
}) {
  const components = useMemo(() => {
    if (idea.components && idea.components.length > 0) return idea.components;
    return generateBOM(idea);
  }, [idea]);
  const total = useMemo(() => components.reduce((sum, c) => sum + c.price * c.quantity, 0), [components]);

  const grouped = useMemo(() => {
    const groups: Record<string, Component[]> = {};
    components.forEach(c => {
      let cat = c.category.trim()
        .replace(/_/g, ' ')
        .split(' ')
        .map(word => {
          const upper = word.toUpperCase();
          if (['MCU', 'PCB', 'IOT', 'LED', 'LCD', 'BOM', 'IC', 'CPU'].includes(upper)) return upper;
          return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();
        })
        .join(' ');
      
      // Grouping logic for Passive Components
      if (['Passive', 'Resistor', 'Capacitor', 'Led'].includes(cat)) {
        cat = 'Passive Components';
      }
      
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(c);
    });
    return groups;
  }, [components]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-8 md:p-12 space-y-12"
    >
      {/* Total banner */}
      <div className="flex items-center justify-between p-10 border-2 border-primary relative overflow-hidden bg-black">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 pointer-events-none" />
        <div className="space-y-3 relative z-10">
          <span className="text-[10px] font-black text-primary uppercase tracking-[0.4em]">SYNTHESIS_TOTAL_COST_EST</span>
          <p className="text-[9px] text-white/20 font-black uppercase tracking-widest">
            *EST_MARKET_VAL: REGION_BD_MARKET_NODES
          </p>
        </div>
        <div className="text-right flex flex-col items-end gap-2">
          <span className="text-4xl md:text-5xl font-black text-white tracking-tighter phosphor-glow italic">
            {formatBDT(total)}
          </span>
          <div className="h-1 w-24 bg-primary/20" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
        {Object.entries(grouped).map(([category, items], catIdx) => (
          <div key={`cat-${category}-${catIdx}`} className="border border-white/10 p-10 space-y-8 bg-black/40">
            <div className="flex items-center gap-6">
              <div className="w-12 h-12 bg-white/5 border border-white/10 flex items-center justify-center text-xl">
                {categoryIcons[category] || "📦"}
              </div>
              <div className="flex flex-col gap-1">
                <span className={`text-[11px] font-black uppercase tracking-[0.4em] ${categoryColors[category] || "text-white/40"}`}>
                  {category}_SUITE
                </span>
                <div className="h-px w-12 bg-primary/20" />
              </div>
            </div>
            <div className="space-y-3">
              {items.map((item, i) => {
                const isHighlighted = activeComponent === item.name || 
                                     (activeComponent?.toUpperCase() === category.toUpperCase()) || 
                                     (item.category === "Passive" && activeComponent === "PASSIVES") ||
                                     (item.category === "MCU" && activeComponent === "MICROCONTROLLER") ||
                                     (item.category === "MCU" && activeComponent === "MAIN PCB");

                return (
                  <div 
                    key={`item-${item.name.replace(/\s+/g, '-')}-${i}-${category}`} 
                    onClick={() => onComponentSelect?.(item.name)}
                    className={`flex items-center justify-between group cursor-pointer p-4 transition-all duration-300 border-2 ${
                      isHighlighted 
                        ? "bg-primary text-black border-primary phosphor-glow" 
                        : "bg-transparent border-white/5 hover:border-white/20 hover:bg-white/2"
                    }`}
                  >
                    <div className="flex items-center gap-4">
                      <span className={`text-[11px] font-black uppercase tracking-wider transition-colors`}>
                        {item.name}
                      </span>
                      {item.quantity > 1 && (
                        <span className={`text-[9px] px-2 py-0.5 font-black transition-all ${isHighlighted ? "bg-black/20 text-black" : "bg-white/5 text-white/20"}`}>
                          QTY: {item.quantity}
                        </span>
                      )}
                    </div>
                    <span className={`text-[11px] font-black tracking-tighter`}>
                      {formatBDT(item.price * item.quantity)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
