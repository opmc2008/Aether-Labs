import { useState, useEffect, useCallback } from "react";
import { motion } from "motion/react";
import { Volume2, ExternalLink } from "lucide-react";
import { playAetherVoice } from "@/lib/audio";
import { generateResearch, type ResearchData } from "@/services/geminiService";
import type { Idea } from "@/pages/Index";

interface ProjectResearchProps {
  idea: Idea;
  onUpdate?: (research: ResearchData) => void;
}

export function ProjectResearch({ idea, onUpdate }: ProjectResearchProps) {
  const [research, setResearch] = useState<ResearchData | null>(idea.research || null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSpeak = async () => {
    if (!research || isSpeaking) return;
    setIsSpeaking(true);
    await playAetherVoice(research.overview);
    window.setTimeout(() => setIsSpeaking(false), 5000); // Simple debounce
  };

  const fetchResearch = useCallback(async () => {
    if (idea.research) return; // Already have it

    setIsLoading(true);
    setError(null);
    try {
      const data = await generateResearch(idea.idea, idea.plan);
      setResearch(data);
      if (onUpdate) onUpdate(data);
    } catch (err: unknown) {
      const errorObj = err as { message?: string; status?: number };
      const isQuota = errorObj?.message?.includes("Overloaded") || errorObj?.status === 429;
      setError(isQuota ? "Neural Link Overloaded: API Quota Exceeded. Re-sync in a few seconds." : "Failed to fetch research data");
    } finally {
      setIsLoading(false);
    }
  }, [idea, onUpdate]);

  useEffect(() => {
    if (!idea.research && !research) {
      fetchResearch();
    }
  }, [idea.research, research, fetchResearch]);

  const isUrl = (str: string) => {
    try {
      new URL(str);
      return true;
    } catch {
      return str.startsWith('http://') || str.startsWith('https://');
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-32 gap-8">
        <div className="relative w-24 h-24 flex items-center justify-center">
          <motion.div 
            animate={{ rotate: 360 }}
            transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
            className="absolute inset-0 border border-primary/20 border-dashed"
          />
          <motion.div 
            animate={{ rotate: -360 }}
            transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
            className="absolute inset-4 border border-primary/40"
          />
          <div className="w-2 h-2 bg-primary phosphor-glow animate-pulse" />
        </div>
        <p className="text-[11px] font-black text-primary uppercase tracking-[0.5em] animate-pulse">NEURAL_RESEARCH_SYNC_IN_PROGRESS...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20 space-y-8">
        <div className="p-12 border-2 border-red-500/20 bg-red-500/5 max-w-xl mx-auto">
          <p className="text-[11px] font-black text-red-400 uppercase tracking-[0.6em] mb-8">{error}</p>
          <button 
            onClick={fetchResearch} 
            className="px-10 py-4 border-2 border-primary text-primary text-[11px] font-black hover:bg-primary hover:text-black transition-all uppercase tracking-widest"
          >
            RETRY_SYNC
          </button>
        </div>
      </div>
    );
  }

  if (!research) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-20 p-8 md:p-12">
      {/* Detailed Analysis Section (Aether AI Deep Dive) */}
      {(research.detailedAnalysis || research.materialScience || research.futureEvolution) && (
        <div className="space-y-16">
          {research.detailedAnalysis && (
            <div className="p-10 md:p-16 border-2 border-primary/20 relative space-y-10 bg-black">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 pointer-events-none" />
              <div className="flex items-center gap-6">
                <div className="w-3 h-3 bg-primary phosphor-glow" />
                <h3 className="text-[14px] font-black text-white uppercase tracking-[0.4em]">DEEP_ENGINEERING_ANALYSIS</h3>
              </div>
              <p className="text-lg md:text-xl text-white/70 leading-relaxed font-bold uppercase tracking-tight">
                {research.detailedAnalysis}
              </p>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            {research.materialScience && (
              <div className="p-10 border border-white/10 space-y-8">
                <h4 className="text-[10px] font-mono font-black text-primary uppercase tracking-[0.5em] flex items-center gap-4">
                  <div className="w-1.5 h-1.5 bg-primary" />
                  MATERIAL_SCIENCE_DATA
                </h4>
                <p className="text-xs text-white/40 leading-loose uppercase tracking-widest">
                  {research.materialScience}
                </p>
              </div>
            )}
            {research.futureEvolution && (
              <div className="p-10 border border-white/10 space-y-8">
                <h4 className="text-[10px] font-mono font-black text-amber-500 uppercase tracking-[0.5em] flex items-center gap-4">
                  <div className="w-1.5 h-1.5 bg-amber-500" />
                  EVOLUTION_SCALING_NODE
                </h4>
                <p className="text-xs text-white/40 leading-loose uppercase tracking-widest">
                  {research.futureEvolution}
                </p>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pt-16 border-t-2 border-white/5">
            {research.marketAnalysis && (
              <div className="space-y-6">
                <h4 className="text-[10px] font-mono font-black text-blue-400 uppercase tracking-[0.5em]">SYSTEM_MARKET_CAP</h4>
                <p className="text-[9px] text-white/30 leading-relaxed uppercase tracking-widest font-bold">
                  {research.marketAnalysis}
                </p>
              </div>
            )}
            {research.regulatorySafety && (
              <div className="space-y-6">
                <h4 className="text-[10px] font-mono font-black text-green-400 uppercase tracking-[0.5em]">SAFETY_COMPLIANCE_722</h4>
                <p className="text-[9px] text-white/30 leading-relaxed uppercase tracking-widest font-bold">
                  {research.regulatorySafety}
                </p>
              </div>
            )}
            {research.ethicalImplications && (
              <div className="space-y-6">
                <h4 className="text-[10px] font-mono font-black text-purple-400 uppercase tracking-[0.5em]">ETHICAL_CONSTRAINT_LOG</h4>
                <p className="text-[9px] text-white/30 leading-relaxed uppercase tracking-widest font-bold">
                  {research.ethicalImplications}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Overview */}
      <div className="space-y-10 pt-16 border-t font-mono">
        <div className="flex items-center justify-between">
          <h3 className="text-[10px] font-black text-white/30 uppercase tracking-[0.8em] flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-white/20" />
            SYNTHESIS_OVERVIEW
          </h3>
          <button 
            onClick={handleSpeak}
            disabled={isSpeaking}
            className={`px-4 py-2 border-2 transition-all font-black text-[9px] uppercase tracking-widest ${isSpeaking ? "bg-primary border-primary text-black animate-pulse" : "bg-black border-white/10 text-white/40 hover:text-white"}`}
          >
            {isSpeaking ? "SYNTH_OUTPUT_ACTIVE" : "EXECUTE_VOCAL_DUMP"}
          </button>
        </div>
        <p className="text-xl text-white/80 leading-relaxed font-black uppercase tracking-tight">{research.overview}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
        {/* Applications */}
        <div className="space-y-10">
          <h3 className="text-[10px] font-black text-white/30 uppercase tracking-[0.6em] flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-white/10" />
            REAL_WORLD_APP_VECTORS
          </h3>
          <ul className="space-y-4 border-l border-white/5 pl-8">
            {(research.applications || []).map((app, i) => (
              <li key={`app-${i}-${app.substring(0, 5)}`} className="text-[11px] font-black text-white/40 uppercase tracking-widest flex items-start gap-4 group">
                <span className="text-primary font-black group-hover:translate-x-1 transition-transform">0{i+1}_&gt;</span>
                <span className="group-hover:text-white transition-colors leading-relaxed">{app}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Challenges */}
        <div className="space-y-10">
          <h3 className="text-[10px] font-black text-red-500/40 uppercase tracking-[0.6em] flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-red-500/20" />
            CRITICAL_BLOCKER_LOG
          </h3>
          <ul className="space-y-4 border-l border-red-500/5 pl-8">
            {(research.challenges || []).map((ch, i) => (
              <li key={`ch-${i}-${ch.substring(0, 5)}`} className="text-[11px] font-black text-white/40 uppercase tracking-widest flex items-start gap-4 group">
                <span className="text-red-500 font-black group-hover:translate-x-1 transition-transform">X_&gt;</span>
                <span className="group-hover:text-red-400 transition-colors leading-relaxed">{ch}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Technologies */}
      <div className="space-y-10 pt-16 border-t border-white/5">
        <h3 className="text-[10px] font-black text-primary uppercase tracking-[0.8em] flex items-center gap-3">
          <div className="w-1.5 h-1.5 bg-primary/20" />
          TECH_STANDARD_STACK
        </h3>
        <div className="flex flex-wrap gap-4">
          {(research.technologies || []).map((tech, i) => (
            <span key={`tech-${i}-${tech}`} className="px-6 py-3 border border-white/10 text-[10px] font-black text-white/40 uppercase tracking-[0.2em] hover:text-primary hover:border-primary/40 transition-all bg-black">
              {tech}
            </span>
          ))}
        </div>
      </div>

      {/* References */}
      <div className="space-y-10 pt-16 border-t border-white/5">
        <h3 className="text-[10px] font-black text-white/20 uppercase tracking-[0.8em] flex items-center gap-3">
          <div className="w-1.5 h-1.5 bg-white/5" />
          EXT_DATASHEET_REFS
        </h3>
        <ul className="space-y-4">
          {(research.references || []).map((ref, i) => {
            const urlMatch = ref.match(/(https?:\/\/[^\s]+)/g);
            const isLink = isUrl(ref) || !!urlMatch;
            const finalUrl = urlMatch ? urlMatch[0] : ref;

            if (isLink) {
              return (
                <li key={`ref-link-${i}`} className="text-[11px] font-black">
                  <a 
                    href={finalUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center justify-between group p-4 border border-white/5 bg-white/2 hover:bg-primary hover:text-black transition-all"
                  >
                    <div className="flex items-center gap-4">
                      <span className="text-white/20 font-black shrink-0">[0{i + 1}]</span>
                      <span className="truncate uppercase tracking-wider">{ref}</span>
                    </div>
                    <ExternalLink className="w-4 h-4 shrink-0" />
                  </a>
                </li>
              );
            }

            return (
              <li key={`ref-text-${i}`} className="text-[11px] font-black text-white/40 uppercase tracking-widest flex items-start gap-4 p-4 border border-white/5">
                <span className="text-white/20 font-black shrink-0">[0{i + 1}]</span>
                <span>{ref}</span>
              </li>
            );
          })}
        </ul>
      </div>
    </motion.div>
  );
}
