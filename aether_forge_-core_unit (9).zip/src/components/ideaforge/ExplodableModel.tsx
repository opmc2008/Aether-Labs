import React, { useRef, useState, useMemo, useEffect } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { Html, Line, Edges, Float, MeshDistortMaterial, Sparkles } from "@react-three/drei";
import * as THREE from "three";
import { motion, AnimatePresence } from "motion/react";
import { GeneratedModelData } from "@/services/geminiService";

/**
 * AETHER CAD CORE v5.0 // TOTAL REVAMP
 * -----------------------------------
 * Industrial-grade parametric assembly system with high-fidelity 
 * materials and quadrants-based disassembly logic.
 */

interface ExplodableModelProps {
  projectType: string;
  explodeFactor: number;
  wireframe?: boolean;
  ghost?: boolean;
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}

interface ComponentMetadata {
  desc: string;
  material: string;
  voltage?: string;
  current?: string;
  specs: string[];
  note: string;
}

const COMPONENT_REGISTRY: Record<string, ComponentMetadata> = {
  "CHASSIS": { 
    desc: "Core Structural Assembly", 
    material: "6061-T6 Aluminum", 
    voltage: "GND",
    current: "0A",
    specs: ["Coating: Matte Black Anodized", "Density: 2.7 g/cm³"], 
    note: "Main structural backbone." 
  },
  "MCU": { 
    desc: "Neural Logic Array", 
    material: "Doped Silicon", 
    voltage: "3.3V / 5.0V", 
    current: "450mA",
    specs: ["Throughput: 800 MIPS", "Protocol: I2C/SPI"], 
    note: "System processing core." 
  },
  "PCB": { 
    desc: "Signal Routing Substrate", 
    material: "Rogers 4350B", 
    voltage: "1.8V - 12V",
    current: "Up to 5A",
    specs: ["Layers: 6-Layer Stackup", "TG: 170°C"], 
    note: "High-density interconnect." 
  },
  "BATTERY": { 
    desc: "Energy Storage Unit", 
    material: "Li-Ion Gen-3 Cells", 
    voltage: "14.8V Nominal", 
    current: "2200mAh / 45C",
    specs: ["Capacity: 32.5 Wh", "Max Discharge: 100A"], 
    note: "Primary power reservoir." 
  },
  "MOTOR": { 
    desc: "Brushless Drive Actuator", 
    material: "Neodymium / Copper", 
    voltage: "Max 25V", 
    current: "22A Peak",
    specs: ["RPM: 2400 KV", "Thrust: 1.2kg"], 
    note: "High-torque mechanical drive." 
  },
  "SENSOR": { 
    desc: "Environmental Transducer", 
    material: "MEMS Silicon", 
    voltage: "3.3V",
    current: "20mA",
    specs: ["Precision: 0.01°", "Sampling: 2kHz"], 
    note: "Environmental data acquisition." 
  },
  "FRAME": { 
    desc: "Rigid Structural Frame", 
    material: "Toray T700 Carbon Fiber", 
    specs: ["Vibration Damping: 0.85", "Modulus: 230 GPa"], 
    note: "Lightweight aerodynamic support." 
  },
  "SHIELD": { 
    desc: "EMI/RFI Protective Barrier", 
    material: "Nickel-Silver Alloy", 
    specs: ["Attenuation: -60dB", "Thickness: 0.2mm"], 
    note: "RF interference suppression." 
  },
  "HEATSINK": { 
    desc: "Thermal Dissipation Matrix", 
    material: "C11000 Copper", 
    specs: ["Area: 14500 mm²", "Thermal Cond: 390 W/mK"], 
    note: "Advanced thermal management." 
  },
};

/**
 * 0. ASSEMBLY PARTICLES
 */
function AssemblyParticles({ factor }: { factor: number }) {
  // Use useMemo with a stable seed-like logic or just accept the randomness for particles
  const points = useMemo(() => {
    const p = [];
    const seed = 0.5; // Dummy stable seed reference 
    for (let i = 0; i < 50; i++) {
      // Use a deterministic-ish pattern for the linter if it complains about purity
      const rx = Math.sin(i * 12.9898 + seed) * 43758.5453123 % 1;
      const ry = Math.sin(i * 78.233 + seed) * 43758.5453123 % 1;
      const rz = Math.sin(i * 54.321 + seed) * 43758.5453123 % 1;
      p.push(new THREE.Vector3(rx * 20 - 10, ry * 20 - 10, rz * 20 - 10));
    }
    return p;
  }, []);

  return (
    <group>
      <Sparkles 
        count={Math.floor(factor * 200)} 
        scale={60} 
        size={2} 
        speed={0.5} 
        opacity={factor * 0.5} 
        color="#3b82f6" 
      />
      {factor > 0.5 && points.map((p, i) => (
        <mesh key={`particle-${i}`} position={p}>
          <boxGeometry args={[0.02, 0.02, 0.02]} />
          <meshBasicMaterial color="#3b82f6" transparent opacity={0.2} />
        </mesh>
      ))}
    </group>
  );
}

/**
 * 1. INDUSTRIAL MATERIAL REPOSITORY
 */
function TechnicalMaterial({ 
  color = "#ffffff", 
  transparent = false, 
  opacity = 1, 
  wireframe = false, 
  emissive = "#000000", 
  metalness = 0.5, 
  roughness = 0.5, 
  isHighlighted = false,
  simulationActive = false,
  explodeFactor = 0
}) {
  const materialRef = useRef<THREE.MeshPhysicalMaterial>(null!);

  useFrame((state) => {
    if (!materialRef.current) return;
    
    // Power pulse effect + Explosion Overload
    const pulse = Math.sin(state.clock.elapsedTime * 4) * 0.5 + 0.5;
    const explosionBoost = explodeFactor * 2.5;
    
    if (simulationActive) {
      materialRef.current.emissiveIntensity = isHighlighted ? 6 : (emissive === "#000000" ? pulse * 0.5 : 2 + pulse);
    } else {
      materialRef.current.emissiveIntensity = isHighlighted ? 8 : (emissive === "#000000" ? explosionBoost : 1 + explosionBoost + pulse * 0.2);
    }
  });

  return (
    <meshPhysicalMaterial 
      ref={materialRef}
      color={color}
      transparent={transparent}
      opacity={opacity}
      wireframe={wireframe}
      emissive={isHighlighted ? "#3b82f6" : emissive}
      emissiveIntensity={isHighlighted ? 6 : (emissive === "#000000" ? 0 : 2)}
      metalness={metalness}
      roughness={roughness}
      envMapIntensity={2}
      clearcoat={1}
      clearcoatRoughness={0.1}
      thickness={transparent ? 1 : 0}
      transmission={transparent ? 0.9 : 0}
    />
  );
}

/**
 * 2. COMPONENT WRAPPER (Visual Enhancer)
 */
function IndustrialPart({ 
  children, 
  color = "#888", 
  emissive = "#000", 
  transparent = false, 
  wireframe = false,
  isScanning = false,
  isHighlighted = false,
  simulationActive = false,
  explodeFactor = 0
}: { 
  children: React.ReactNode; 
  color?: string; 
  emissive?: string; 
  transparent?: boolean; 
  wireframe?: boolean;
  isScanning?: boolean;
  isHighlighted?: boolean;
  simulationActive?: boolean;
  explodeFactor?: number;
}) {
  return (
    <group>
      {React.Children.map(children, (child) => {
        if (React.isValidElement(child)) {
          return React.cloneElement(child as React.ReactElement, {
            children: (
              <>
                {(child.props as { children?: React.ReactNode }).children}
                <TechnicalMaterial 
                  color={isScanning ? "#3b82f6" : color} 
                  emissive={isScanning ? "#3b82f6" : emissive} 
                  transparent={transparent} 
                  wireframe={wireframe} 
                  metalness={0.8}
                  roughness={0.2}
                  isHighlighted={isHighlighted}
                  simulationActive={simulationActive}
                  explodeFactor={explodeFactor}
                />
                <Edges color={isScanning || isHighlighted ? "#60a5fa" : (wireframe ? "#ffffff" : "#444444")} threshold={15} />
              </>
            )
          });
        }
        return child;
      })}
    </group>
  );
}

/**
 * CORE_UNIT_BLUEPRINT: A complex engineering module representing AETHER_FORGE synthesis.
 * Visualizes blueprints, parametric spatial modeling, and advanced computational lattice.
 */
export const CORE_UNIT_BLUEPRINT: GeneratedModelData = {
  primitives: [
    { type: "box", args: [2.5, 0.4, 2], position: [0, -0.4, 0], color: "#111", label: "BASE_PLATE", materialProperties: { material: "COMPOSITE_STEEL", purpose: "Structural foundation for parametric synthesis." } },
    { type: "cylinder", args: [0.8, 0.8, 1.8], position: [0, 0.7, 0], color: "#7c3aed", label: "AETHER_CORE", materialProperties: { material: "QUANTUM_CRYSTAL", purpose: "Primary intelligence hub and computational lattice." } },
    { type: "box", args: [0.2, 1.2, 0.2], position: [1.2, 0.5, 1], color: "#3b82f6", label: "UPRIGHT_A", materialProperties: { material: "TITANIUM_ALLOY", purpose: "Geometric stabilization pillar." } },
    { type: "box", args: [0.2, 1.2, 0.2], position: [-1.2, 0.5, 1], color: "#3b82f6", label: "UPRIGHT_B", materialProperties: { material: "TITANIUM_ALLOY", purpose: "Geometric stabilization pillar." } },
    { type: "box", args: [0.2, 1.2, 0.2], position: [1.2, 0.5, -1], color: "#3b82f6", label: "UPRIGHT_C", materialProperties: { material: "TITANIUM_ALLOY", purpose: "Geometric stabilization pillar." } },
    { type: "box", args: [0.2, 1.2, 0.2], position: [-1.2, 0.5, -1], color: "#3b82f6", label: "UPRIGHT_D", materialProperties: { material: "TITANIUM_ALLOY", purpose: "Geometric stabilization pillar." } },
    { type: "box", args: [2.6, 0.2, 2.2], position: [0, 1.2, 0], color: "#222", label: "ARRAY_PLATE", materialProperties: { material: "CARBIDE_CERAMIC", purpose: "High-temperature sensor array mount." } },
    { type: "box", args: [1.5, 0.1, 1.5], position: [0, 1.35, 0], color: "#00d4aa", label: "CONTROL_PCB", materialProperties: { material: "FR4_ADVANCED", purpose: "Logic control for spatial modeling." } },
    { type: "sphere", args: [0.3, 16, 16], position: [0, 1.8, 0], color: "#f59e0b", label: "NEURAL_TRANSCEIVER", materialProperties: { material: "GOLD_PLUTON", purpose: "Long-range blueprint broadcast unit." } },
    { type: "cylinder", args: [0.2, 0.2, 0.8], position: [1.4, 0.2, 0], color: "#444", label: "COOLING_LINE", materialProperties: { material: "CONDUCTIVE_LIQUID", purpose: "Thermal dissipation system." } },
    { type: "cylinder", args: [0.2, 0.2, 0.8], position: [-1.4, 0.2, 0], color: "#444", label: "COOLING_LINE_B", materialProperties: { material: "CONDUCTIVE_LIQUID", purpose: "Thermal dissipation system." } },
  ]
};

/**
 * 3. KINEMATIC CLUSTERING ENGINE
 * Groups components logically for more meaningful explosions.
 */
function getComponentCluster(label: string): string {
  const l = label.toUpperCase();
  if (l.includes("PROP") || l.includes("ROTOR") || l.includes("MOTOR") || l.includes("ACTUATOR")) return "PROPULSION";
  if (l.includes("MCU") || l.includes("PCB") || l.includes("CONTROL") || l.includes("SENSOR") || l.includes("BRAIN")) return "ELECTRONICS";
  if (l.includes("BATT") || l.includes("CELL") || l.includes("SOLAR") || l.includes("POWER")) return "POWER";
  if (l.includes("FRAME") || l.includes("ARM") || l.includes("LEG") || l.includes("BODY")) return "STRUCTURE";
  return "AUXILIARY";
}

const CLUSTER_OFFSETS: Record<string, THREE.Vector3> = {
  PROPULSION: new THREE.Vector3(0, 1.5, 0),
  ELECTRONICS: new THREE.Vector3(0, 5, 0),
  POWER: new THREE.Vector3(0, -3, 0),
  STRUCTURE: new THREE.Vector3(0, -8, 0),
  AUXILIARY: new THREE.Vector3(0, 0, 0)
};

/**
 * 4. DISASSEMBLY PART REWORK
 * Uses Cluster Logic + Polar Expansion + Spring Physics
 */
function DisassemblyPart({
  children,
  basePosition = new THREE.Vector3(0, 0, 0),
  factor,
  isFocused,
  index = 0,
  totalParts = 1,
  label,
  onSelect,
  onHover,
  simulationActive = false,
  spreadMode = 'GRID'
}: {
  children: React.ReactNode;
  basePosition?: THREE.Vector3;
  factor: number;
  isFocused: boolean;
  index: number;
  totalParts?: number;
  label: string;
  onSelect?: (name: string) => void;
  onHover?: (hovering: boolean) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}) {
  const groupRef = useRef<THREE.Group>(null!);
  const cluster = useMemo(() => getComponentCluster(label), [label]);
  
  // Physics State
  const currentPos = useRef(basePosition.clone());
  const currentVelocity = useRef(new THREE.Vector3(0, 0, 0));

  const gridPosition = useMemo(() => {
    const size = Math.ceil(Math.sqrt(totalParts));
    const col = index % size;
    const row = Math.floor(index / size);
    const spacing = 5; // Equal distance slightly wider
    const offset = (size - 1) * spacing / 2;
    // Ground plane grid (Y=0)
    return new THREE.Vector3(col * spacing - offset, -2, row * spacing - offset);
  }, [index, totalParts]);

  const detonateDirection = useMemo(() => {
    if (spreadMode === 'GRID') {
      return gridPosition.clone().sub(basePosition);
    }
    // ... rest of detonateDirection logic
    if (spreadMode === 'COLUMN') return new THREE.Vector3(0, (index - 5) * 2, 0);
    if (spreadMode === 'LINEAR') return new THREE.Vector3((index - 5) * 4, 0, 0);
    
    // RADIAL (Cluster Based)
    const clusterOffset = CLUSTER_OFFSETS[cluster] || new THREE.Vector3(0, 0, 0);
    const radial = basePosition.clone().normalize();
    if (radial.length() < 0.1) radial.set(Math.cos(index), 1, Math.sin(index)).normalize();
    
    // Disarray logic moved inside here for radial only
    const angle = (index / 10) * Math.PI * 2;
    const radius = 2 + (index % 5);
    const disarray = new THREE.Vector3(Math.cos(angle) * radius, Math.sin(index) * 2, Math.sin(angle) * radius);
    
    return radial.multiplyScalar(15).add(clusterOffset.clone().multiplyScalar(2)).add(disarray);
  }, [basePosition, index, spreadMode, cluster, gridPosition]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    const t = state.clock.elapsedTime;
    const easedFactor = Math.pow(factor, 1.0); 
    
    // Target Position
    const targetPos = basePosition.clone().add(detonateDirection.clone().multiplyScalar(easedFactor));
    
    // Spring physics simulation
    const stiffness = 45.0; // Increased for faster response
    const damping = 0.8;
    const mass = 1.0;

    const force = new THREE.Vector3().subVectors(targetPos, currentPos.current).multiplyScalar(stiffness);
    const acceleration = force.divideScalar(mass);
    currentVelocity.current.add(acceleration.multiplyScalar(delta)).multiplyScalar(damping);
    currentPos.current.add(currentVelocity.current.clone().multiplyScalar(delta));

    // Dynamic Physics: Simulation Vibrations + Hover lift
    const vibration = simulationActive ? Math.sin(t * 60 + index) * 0.02 : 0;
    const hoverLift = isFocused ? Math.sin(t * 4) * 0.4 : 0; // Increased lift
    
    groupRef.current.position.set(
      currentPos.current.x + vibration,
      currentPos.current.y + vibration + hoverLift,
      currentPos.current.z + vibration
    );

    // Rotation: Slight organic sway
    const sway = Math.sin(t * 1.5 + index) * 0.03 * (1 - factor);
    const focusRot = isFocused ? Math.sin(t * 2) * 0.08 : 0;
    groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, focusRot + sway, 0.1);
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, (simulationActive ? t * 0.5 : 0) + focusRot + sway, 0.1);
    groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, focusRot + sway, 0.1);

    // Scale
    const s = 1 + (isFocused ? 0.35 : 0); // Significantly bigger when focused
    groupRef.current.scale.lerp(new THREE.Vector3(s, s, s), 0.1);
  });

  return (
    <group 
      ref={groupRef} 
      onClick={(e) => { e.stopPropagation(); onSelect?.(label); }}
      onPointerEnter={(e) => { e.stopPropagation(); onHover?.(true); }}
      onPointerLeave={(e) => { e.stopPropagation(); onHover?.(false); }}
    >
      {children}
      
      {/* Structural Backbone Line (Only semi-visible during explosion) */}
      {factor > 0.1 && (
        <Line 
          points={[[0, 0, 0], basePosition.clone().multiplyScalar(-1.5).toArray() as [number, number, number]]}
          color="#3b82f6"
          lineWidth={0.5}
          transparent
          opacity={factor * 0.1}
        />
      )}
    </group>
  );
}

/**
 * 5. EXPLOSION SHOCKWAVE EFFECT
 */
function ExplosionShockwave({ factor }: { factor: number }) {
  const ref = useRef<THREE.Mesh>(null!);
  useFrame((state) => {
    if (!ref.current) return;
    const scale = factor * 40;
    ref.current.scale.set(scale, scale, scale);
    (ref.current.material as THREE.MeshBasicMaterial).opacity = Math.max(0, (1 - factor) * factor * 0.5);
  });

  return (
    <mesh ref={ref} rotation={[-Math.PI / 2, 0, 0]}>
      <ringGeometry args={[0.95, 1, 64]} />
      <meshBasicMaterial color="#3b82f6" transparent side={THREE.DoubleSide} />
    </mesh>
  );
}

/**
 * 4. HOLOGRAPHIC HUD LABEL
 */
function HUDLabel({
  label,
  factor,
  isFocused,
  onHover,
  simulationActive,
  index = 0,
  description,
  material,
  purpose,
  isHovered = false
}: {
  label: string;
  factor: number;
  isFocused: boolean;
  onHover: (hovering: boolean) => void;
  simulationActive?: boolean;
  index?: number;
  description?: string;
  material?: string;
  purpose?: string;
  isHovered?: boolean;
}) {
  // Dynamic offset staggering to prevent overlaps
  const labelOffset = useMemo(() => {
    const horizontalShift = index % 2 === 0 ? 1.2 : -1.2;
    const verticalShift = (index % 3) * 0.3;
    return new THREE.Vector3(horizontalShift, 0.6 + verticalShift, 0);
  }, [index]);

  const [localHovered, setLocalHovered] = useState(false);
  const [detailExpanded, setDetailExpanded] = useState(false);
  const shouldShow = isFocused || isHovered || localHovered;
  const opacity = shouldShow ? 1 : 0;
  
  const metadata = useMemo(() => {
    const key = Object.keys(COMPONENT_REGISTRY).find(k => label.toUpperCase().includes(k)) || "CHASSIS";
    const base = COMPONENT_REGISTRY[key];
    return {
      material: material || base.material,
      desc: description || base.desc,
      note: purpose || base.note,
      voltage: base.voltage,
      current: base.current
    };
  }, [label, material, description, purpose]);

  const [uid] = useState(() => Math.random().toString(16).slice(2, 10).toUpperCase());

  // Use derived state instead of an effect to reset expansion
  const effectiveDetailExpanded = isFocused && detailExpanded;

  if (simulationActive && !isFocused) return null;

  return (
    <group position={labelOffset} scale={isFocused ? 2.0 : (isHovered || localHovered ? 1.6 : 1.4)}>
      {/* Callout Line with Anchor Dot */}
      <mesh position={[-labelOffset.x, -labelOffset.y, -labelOffset.z]}>
        <sphereGeometry args={[0.06, 16, 16]} />
        <meshBasicMaterial color={isFocused || isHovered || localHovered ? "#3b82f6" : "#ffffff"} transparent opacity={opacity * 0.9} />
      </mesh>
      
      <Line
        points={[[0, 0, 0], [-labelOffset.x, -labelOffset.y, -labelOffset.z]]}
        color={isFocused || isHovered || localHovered ? "#3b82f6" : "#ffffff"}
        lineWidth={isFocused || isHovered || localHovered ? 2.5 : 1.5}
        transparent
        opacity={opacity * 0.6}
      />
      
      <Html 
        distanceFactor={8} 
        center 
        style={{ pointerEvents: 'none' }}
      >
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity, x: 0 }}
          className="pointer-events-auto flex flex-col gap-3 items-start"
          onMouseEnter={() => { onHover(true); setLocalHovered(true); }}
          onMouseLeave={() => { onHover(false); setLocalHovered(false); }}
        >
          {/* Main ID Label - Technical & Large */}
          <div className={`
             transition-all duration-300 backdrop-blur-3xl px-12 py-4 clip-path-polygon
            ${isFocused ? "bg-primary text-black border-l-[16px] border-white shadow-[0_0_100px_rgba(59,130,246,1)]" : 
              (isHovered || localHovered ? "bg-primary/20 text-white border-l-[12px] border-primary shadow-[0_0_60px_rgba(59,130,246,0.6)]" : 
              "bg-black/90 text-primary border-l-[8px] border-primary shadow-[0_0_40px_rgba(59,130,246,0.3)]")}
          `}>
            <span className={`
              font-black uppercase tracking-[0.5em] leading-none text-[48px] filter drop-shadow-[0_0_15px_rgba(255,255,255,0.4)]
            `}>
              {label}
            </span>
          </div>

          {/* Persistent Spec Panel on Selection or Hover (Compact on Hover) */}
          <AnimatePresence>
            {(isFocused || isHovered || localHovered) && (
              <motion.div
                initial={{ opacity: 0, height: 0, width: 350 }}
                animate={{ opacity: 1, height: 'auto', width: isFocused ? 650 : 450 }}
                exit={{ opacity: 0, height: 0 }}
                className={`bg-black/95 border-l-[12px] ${isFocused ? 'border-primary' : 'border-white/20'} p-12 mt-6 overflow-hidden backdrop-blur-3xl shadow-[0_0_120px_rgba(59,130,246,0.3)] cursor-pointer`}
                onClick={(e) => { e.stopPropagation(); if (isFocused) setDetailExpanded(!detailExpanded); }}
              >
                <div className="space-y-8">
                  <div className="flex flex-col gap-3 border-b border-white/10 pb-6">
                    <span className="text-[14px] text-white/40 uppercase font-mono tracking-[0.3em]">COMPONENT_CLASS</span>
                    <span className="text-[36px] text-white uppercase font-black tracking-widest leading-tight">{label}</span>
                  </div>

                  <div className="grid grid-cols-1 gap-6">
                    <div className="flex flex-col">
                      <span className="text-[14px] text-white/40 uppercase font-mono tracking-widest">PURPOSE</span>
                      <span className="text-[20px] text-primary font-bold uppercase leading-tight">{metadata.note}</span>
                    </div>
                  </div>

                  {isFocused && (
                    <div className="grid grid-cols-2 gap-10 pt-6 border-t border-white/5">
                      <div className="flex flex-col">
                        <span className="text-[14px] text-white/40 uppercase font-mono">DENSITY / MATERIAL</span>
                        <span className="text-[24px] text-primary font-black uppercase">{metadata.material}</span>
                      </div>
                      {metadata.voltage && (
                        <div className="flex flex-col">
                          <span className="text-[14px] text-white/40 uppercase font-mono">POWER_FLOW / POTENTIAL</span>
                          <span className="text-[24px] text-white font-black uppercase">{metadata.voltage}</span>
                        </div>
                      )}
                    </div>
                  )}
                  
                  <div className="pt-6 border-t border-white/10">
                    <p className={`text-[18px] text-white/80 font-medium leading-relaxed uppercase font-mono tracking-widest ${isFocused ? 'line-clamp-none' : 'line-clamp-2'}`}>
                      {metadata.desc}
                    </p>
                    {effectiveDetailExpanded && isFocused && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        className="mt-8 pt-8 border-t border-white/10 space-y-8"
                      >
                         <div className="flex flex-col gap-4">
                          <span className="text-[16px] text-primary font-bold tracking-[0.2em]">DEEP_BLUEPRINT_ANALYSIS:</span>
                          <p className="text-[18px] text-white/90 leading-relaxed font-sans font-medium">{metadata.note}</p>
                        </div>
                        <div className="grid grid-cols-2 gap-8 text-[14px] font-mono opacity-50">
                          <div>UID_REF: {uid}</div>
                          <div>SYSTEM_REVISION: v2.4.0_STABLE</div>
                        </div>
                      </motion.div>
                    )}
                    {isFocused && (
                      <p className={`text-[16px] text-primary/70 mt-6 italic font-mono ${effectiveDetailExpanded ? 'hidden' : ''}`}>
                        CLICK_FOR_DEEP_INSIGHT
                      </p>
                    )}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </Html>
    </group>
  );
}

/**
 * 4.5. MOUSE TOOLTIP (Unidirectional Following)
 */
function MouseTooltip({ content }: { content: string | null }) {
  const { mouse } = useThree();
  const ref = useRef<HTMLDivElement>(null!);

  useFrame(() => {
    if (ref.current && content) {
      // Calculate pixel position from NDC (-1 to 1)
      const x = (mouse.x * window.innerWidth) / 2;
      const y = (-mouse.y * window.innerHeight) / 2;
      // Use fixed offset for "unidirectional" feel
      ref.current.style.transform = `translate3d(${x + 20}px, ${y + 20}px, 0)`;
    }
  });

  if (!content) return null;

  return (
    <Html fullscreen style={{ pointerEvents: 'none' }}>
      <div 
        ref={ref}
        className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 whitespace-nowrap bg-black/95 p-4 border-l-[4px] border-primary backdrop-blur-3xl shadow-[0_0_50px_rgba(0,0,0,0.5)] min-w-[180px]"
      >
        <p className="text-[12px] text-white font-black uppercase tracking-[0.1em] leading-none">{content}</p>
      </div>
    </Html>
  );
}

/**
 * 5. TECHNICAL COMPONENTS (Revamped Primitives)
 */
function Mainboard({ 
  wireframe, 
  active, 
  simulationActive,
  explodeFactor = 0
}: { 
  wireframe?: boolean; 
  active?: boolean; 
  simulationActive?: boolean;
  explodeFactor?: number;
}) {
  const lightRef = useRef<THREE.PointLight>(null!);
  useFrame((state) => {
    if ((simulationActive || active) && lightRef.current) {
      lightRef.current.intensity = 1.5 + Math.sin(state.clock.elapsedTime * 15) * 1.0;
    }
  });

  return (
    <group>
      {/* Substrate */}
      <IndustrialPart color="#1e3a8a" wireframe={wireframe} explodeFactor={explodeFactor}>
        <mesh><boxGeometry args={[2.8, 0.05, 2.2]} /></mesh>
      </IndustrialPart>
      
      {/* Core SoC */}
      <group position={[0, 0.08, 0]}>
        <IndustrialPart color="#111" emissive="#3b82f6" wireframe={wireframe} explodeFactor={explodeFactor}>
          <mesh><boxGeometry args={[0.6, 0.1, 0.6]} /></mesh>
        </IndustrialPart>
        <pointLight ref={lightRef} position={[0, 0.2, 0]} color="#3b82f6" intensity={2} distance={3} />
      </group>

      {/* Surface Mount Comps */}
      <group position={[1.0, 0.05, 0.8]}>
        <IndustrialPart color="#222" explodeFactor={explodeFactor}><mesh><boxGeometry args={[0.3, 0.06, 0.3]} /></mesh></IndustrialPart>
      </group>
      <group position={[-1.0, 0.05, -0.8]}>
        <IndustrialPart color="#222" explodeFactor={explodeFactor}><mesh><boxGeometry args={[0.4, 0.08, 0.2]} /></mesh></IndustrialPart>
      </group>

      {/* Logic Traces Visual (Emissive lines) */}
      {(active || simulationActive) && (
        <group position={[0, 0.04, 0]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]}>
            <planeGeometry args={[2.6, 2.0]} />
            <meshBasicMaterial color="#3b82f6" transparent opacity={0.15} />
          </mesh>
        </group>
      )}
    </group>
  );
}

function Rotor({ active }: { active?: boolean }) {
  const groupRef = useRef<THREE.Group>(null!);
  useFrame((state) => {
    if (active && groupRef.current) {
      groupRef.current.rotation.y += 1.2;
      groupRef.current.position.y = 0.2 + Math.sin(state.clock.elapsedTime * 20) * 0.01;
    }
  });
  return (
    <group ref={groupRef} position={[0, 0.2, 0]}>
      <IndustrialPart color="#0a0a0a">
        <mesh><boxGeometry args={[1.5, 0.02, 0.1]} /></mesh>
        <mesh rotation={[0, Math.PI / 2, 0]}><boxGeometry args={[1.5, 0.02, 0.1]} /></mesh>
        <mesh position={[0, 0.05, 0]}><cylinderGeometry args={[0.06, 0.06, 0.1, 8]} /></mesh>
      </IndustrialPart>
    </group>
  );
}

/**
 * 6. AI COMPOSER
 */
export function AIGeneratedModel({ 
  data, 
  explodeFactor, 
  wireframe, 
  activeComponent, 
  onComponentSelect, 
  simulationActive,
  spreadMode = 'GRID'
}: {
  data: GeneratedModelData;
  explodeFactor: number;
  wireframe: boolean;
  activeComponent?: string | null;
  onComponentSelect?: (name: string | null) => void;
  simulationActive?: boolean;
  spreadMode?: 'RADIAL' | 'LINEAR' | 'COLUMN' | 'GRID';
}) {
  const [hovered, setHovered] = useState<string | null>(null);

  // Scanning effect state
  const [scanY, setScanY] = useState(0);
  useFrame((state) => {
    setScanY(Math.sin(state.clock.elapsedTime * 0.5) * 10);
  });

  const selectionNote = useMemo(() => {
    if (!activeComponent) return null;
    const comp = data.primitives.find(p => p.label === activeComponent);
    let note = comp?.materialProperties?.purpose;
    if (!note) {
      const key = Object.keys(COMPONENT_REGISTRY).find(k => activeComponent.toUpperCase().includes(k)) || "CHASSIS";
      note = COMPONENT_REGISTRY[key]?.note || "Precision component.";
    }
    // Truncate to very short semantic note
    return note.length > 35 ? note.substring(0, 32) + "..." : note;
  }, [activeComponent, data.primitives]);

  return (
    <group scale={[6, 6, 6]}>
      {/* Scanning Laser Plane */}
      {!simulationActive && (
        <mesh position={[0, scanY, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <planeGeometry args={[25, 25]} />
          <meshBasicMaterial color="#3b82f6" transparent opacity={0.03} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* Shockwave Pulse */}
      <ExplosionShockwave factor={explodeFactor} />

      {/* Assembly Particles */}
      <AssemblyParticles factor={explodeFactor} />

      {data.primitives.map((comp, idx) => {
        const baseVec = new THREE.Vector3(...comp.position);
        const isFocused = activeComponent === comp.label;
        const effectiveFactor = simulationActive ? 0 : explodeFactor;
        
        // Context-aware component substitution
        const labelLower = comp.label.toLowerCase();
        const isPCB = labelLower.includes("pcb") || labelLower.includes("control") || labelLower.includes("mcu");
        const isMotor = labelLower.includes("motor") || labelLower.includes("actuator") || labelLower.includes("rotor") || labelLower.includes("propeller");
        const isBattery = labelLower.includes("battery") || labelLower.includes("power") || labelLower.includes("cell");
        const isSolar = labelLower.includes("solar") || labelLower.includes("panel");
        
        const isScanning = !simulationActive && Math.abs(baseVec.y - scanY) < 0.3;

        const isHovered = hovered === comp.label;
        const isHighlighted = isFocused || isHovered;

        return (
              <group key={`ai-prim-${comp.label}-${idx}`}>
            <DisassemblyPart 
              label={comp.label} 
              index={idx} 
              totalParts={data.primitives.length}
              factor={effectiveFactor} 
              basePosition={baseVec} 
              isFocused={isFocused} 
              onSelect={onComponentSelect}
              onHover={(h) => setHovered(h ? comp.label : null)}
              simulationActive={simulationActive}
              spreadMode={spreadMode}
            >
              <group rotation={comp.rotation ? new THREE.Euler(...comp.rotation) : new THREE.Euler(0, 0, 0)}>
                {isPCB ? (
                  <Mainboard wireframe={wireframe} active={isHighlighted} simulationActive={simulationActive} explodeFactor={effectiveFactor} />
                ) : isMotor ? (
                  <group>
                    <IndustrialPart 
                      color={comp.color} 
                      isScanning={isScanning} 
                      wireframe={wireframe} 
                      isHighlighted={isHighlighted}
                      simulationActive={simulationActive}
                      explodeFactor={effectiveFactor}
                    >
                      <mesh><cylinderGeometry args={comp.args && comp.args.length >= 3 ? [comp.args[0], comp.args[1], comp.args[2], 16] : [0.5, 0.5, 1, 16]} /></mesh>
                    </IndustrialPart>
                    <Rotor active={simulationActive} />
                  </group>
                ) : (isBattery || isSolar) ? (
                  <IndustrialPart 
                    color={isSolar ? "#1e293b" : "#111"} 
                    emissive={isSolar ? "#3b82f6" : "#f59e0b"} 
                    isScanning={isScanning} 
                    wireframe={wireframe} 
                    isHighlighted={isHighlighted}
                    simulationActive={simulationActive}
                    explodeFactor={effectiveFactor}
                  >
                    <mesh><boxGeometry args={comp.args && comp.args.length >= 3 ? comp.args.slice(0, 3) : [1, 1, 1]} /></mesh>
                  </IndustrialPart>
                ) : (
                  <IndustrialPart 
                    color={comp.color} 
                    isScanning={isScanning} 
                    wireframe={wireframe} 
                    isHighlighted={isHighlighted}
                    simulationActive={simulationActive}
                    explodeFactor={effectiveFactor}
                    transparent={labelLower.includes("plate") || labelLower.includes("cover")}
                  >
                    <mesh>
                      {comp.type === "sphere" ? <sphereGeometry args={comp.args && comp.args.length >= 1 ? [comp.args[0], 16, 16] : [0.5, 16, 16]} /> : 
                       comp.type === "cylinder" ? <cylinderGeometry args={comp.args && comp.args.length >= 3 ? [comp.args[0], comp.args[1], comp.args[2], 16] : [0.5, 0.5, 1, 16]} /> :
                       comp.type === "torus" ? <torusGeometry args={comp.args && comp.args.length >= 2 ? [comp.args[0], comp.args[1], 12, 24] : [0.5, 0.2, 12, 24]} /> :
                       <boxGeometry args={comp.args && comp.args.length >= 3 ? comp.args.slice(0, 3) : [1, 1, 1]} />}
                    </mesh>
                  </IndustrialPart>
                )}
              </group>
                {/* HUD Label is now a child of the disassembly group so it follows the part */}
                <HUDLabel 
                  label={comp.label} 
                  factor={effectiveFactor} 
                  isFocused={isFocused} 
                  isHovered={isHovered}
                  description={comp.materialProperties?.material}
                  material={comp.materialProperties?.material}
                  purpose={comp.materialProperties?.purpose}
                  onHover={(h) => setHovered(h ? comp.label : null)} 
                  simulationActive={simulationActive} 
                  index={idx}
                />
            </DisassemblyPart>
          </group>
        );
      })}
    </group>
  );
}

/**
 * 7. CORE COMPOSER (Static Models Fallback)
 */
export function ExplodableModel(props: ExplodableModelProps) {
  // We prioritize the AIGeneratedModel structure as it's more dynamic.
  // For static fallbacks, we map them into the AI Generated format for consistency.
  const staticData: GeneratedModelData = useMemo(() => {
    const type = props.projectType.toLowerCase();
    
    if (type === "aether-core" || type.includes("core-unit")) {
      return CORE_UNIT_BLUEPRINT;
    }

    if (type.includes("drone") || type.includes("uav")) {
      return {
        primitives: [
          { type: "box", args: [8, 0.1, 8], position: [0, -0.5, 0], color: "#0a0a0a", label: "CHASSIS" },
          { type: "box", args: [2.5, 0.05, 2], position: [0, 0.1, 0], color: "#1e3a8a", label: "PCB" },
          { type: "cylinder", args: [0.2, 0.2, 0.4], position: [4, 0.3, 4], color: "#333", label: "MOTOR" },
          { type: "cylinder", args: [0.2, 0.2, 0.4], position: [-4, 0.3, 4], color: "#333", label: "MOTOR" },
          { type: "cylinder", args: [0.2, 0.2, 0.4], position: [4, 0.3, -4], color: "#333", label: "MOTOR" },
          { type: "cylinder", args: [0.2, 0.2, 0.4], position: [-4, 0.3, -4], color: "#333", label: "MOTOR" }
        ]
      };
    }
    return {
      primitives: [
        { type: "box", args: [6, 0.5, 4], position: [0, 0, 0], color: "#222", label: "CHASSIS" },
        { type: "box", args: [2, 0.1, 1.5], position: [0, 0.4, 0], color: "#1e3a8a", label: "MCU" }
      ]
    };
  }, [props.projectType]);

  return <AIGeneratedModel {...props} data={staticData} />;
}
