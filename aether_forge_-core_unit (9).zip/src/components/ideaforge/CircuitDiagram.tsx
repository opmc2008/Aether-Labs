import { useState, useEffect, useCallback, useMemo } from "react";
import { motion } from "motion/react";
import { generateCircuit, type CircuitData } from "@/services/geminiService";
import type { Idea } from "@/pages/Index";

interface CircuitDiagramProps {
  idea: Idea;
  onUpdate?: (circuit: CircuitData) => void;
}

export function CircuitDiagram({ idea, onUpdate }: CircuitDiagramProps) {
  const [circuit, setCircuit] = useState<CircuitData | null>(idea.circuit || null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchCircuit = useCallback(async () => {
    if (idea.circuit) return; // Already have it

    setIsLoading(true);
    setError(null);
    try {
      const data = await generateCircuit(idea.idea, idea.plan);
      setCircuit(data);
      if (onUpdate) onUpdate(data);
    } catch (err: unknown) {
      const errorObj = err as { message?: string; status?: number };
      const isQuota = errorObj?.message?.includes("Overloaded") || errorObj?.status === 429;
      setError(isQuota ? "Neural Link Overloaded: API Quota Exceeded. Re-sync in a few seconds." : "Failed to generate circuit diagram");
    } finally {
      setIsLoading(false);
    }
  }, [idea, onUpdate]);

  useEffect(() => {
    if (!idea.circuit && !circuit) {
      fetchCircuit();
    }
  }, [idea.circuit, circuit, fetchCircuit]);

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-48 gap-8">
        <div className="w-16 h-16 border-4 border-primary/20 rotate-45 flex items-center justify-center">
          <div className="w-6 h-6 bg-primary animate-pulse" />
        </div>
        <p className="text-[11px] font-black text-primary uppercase tracking-[0.5em] animate-pulse">ANALYZING_TOPOLOGY_FLUX...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-20 space-y-10">
        <div className="p-12 border-2 border-red-500/20 bg-red-500/5 max-w-xl mx-auto">
          <p className="text-[11px] font-black text-red-400 uppercase tracking-[0.6em] mb-8">{error}</p>
          <button 
            onClick={fetchCircuit} 
            className="px-10 py-4 border-2 border-primary text-primary text-[11px] font-black hover:bg-primary hover:text-black transition-all uppercase tracking-widest"
          >
            RETRY_SYNTH
          </button>
        </div>
      </div>
    );
  }

  if (!circuit) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-16 p-12">
      {/* Textual Schematic */}
      {circuit.textualSchematic && (
        <div className="space-y-8">
          <h3 className="text-[11px] font-black text-primary uppercase tracking-[0.6em] flex items-center gap-4">
            <div className="w-2.5 h-2.5 bg-primary phosphor-glow" />
            TEXTUAL_SCHEMATIC_DUMP
          </h3>
          <div className="bg-black border-2 border-white/10 p-10 font-mono text-[11px] text-primary/80 leading-relaxed whitespace-pre overflow-x-auto phosphor-glow">
            {circuit.textualSchematic}
          </div>
        </div>
      )}

      {/* Circuit description */}
      <div className="space-y-8">
        <h3 className="text-[11px] font-black text-white/40 uppercase tracking-[0.6em] flex items-center gap-4">
          <div className="w-2.5 h-2.5 bg-white/10" />
          CORE_ANALYSIS_REPORT
        </h3>
        <p className="text-xl text-white/60 leading-relaxed font-black uppercase tracking-tight whitespace-pre-wrap">{circuit.description}</p>
      </div>

      {/* Interactive 3D-style connection diagram */}
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <h3 className="text-[11px] font-black text-primary uppercase tracking-[0.6em] flex items-center gap-4">
            <div className="w-2.5 h-2.5 bg-primary/20" />
            CONN_TOPOLOGY_MAP
          </h3>
          <span className="text-[10px] font-black text-primary/40 uppercase tracking-[0.3em]">{(circuit.connections || []).length}_ACTIVE_NODES</span>
        </div>
        <div className="bg-black border-2 border-white/10 p-12 overflow-hidden shadow-2xl">
          <CircuitTopology connections={circuit.connections || []} />
        </div>
      </div>

      {/* Connections table */}
      {(circuit.connections || []).length > 0 && (
        <div className="space-y-8">
          <h3 className="text-[11px] font-black text-primary uppercase tracking-[0.6em] flex items-center gap-4">
            <div className="w-2.5 h-2.5 bg-primary/10" />
            HARDWARE_WIRING_LOG
          </h3>
          <div className="bg-black border-2 border-white/10 overflow-hidden">
            <table className="w-full text-left font-mono">
              <thead>
                <tr className="border-b-2 border-white/10 bg-white/5">
                  <th className="px-10 py-6 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">SEQ</th>
                  <th className="px-10 py-6 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">FROM_ADDR</th>
                  <th className="px-10 py-6 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">TO_ADDR</th>
                  <th className="px-10 py-6 text-[10px] font-black text-white/40 uppercase tracking-[0.3em]">XFER_TYPE</th>
                </tr>
              </thead>
              <tbody>
                {(circuit.connections || []).map((conn, i) => (
                  <tr key={`${conn.from}-${conn.to}-${i}`} className="border-b border-white/5 hover:bg-primary hover:text-black transition-all group">
                    <td className="px-10 py-6 text-[10px] font-black text-white/20 uppercase">{String(i + 1).padStart(2, '0')}</td>
                    <td className="px-10 py-6 text-[11px] font-black text-white group-hover:text-black uppercase">{conn.from}</td>
                    <td className="px-10 py-6 text-[11px] font-black text-white group-hover:text-black/60 uppercase">{conn.to}</td>
                    <td className="px-10 py-6">
                      <span className="px-4 py-2 bg-white/5 text-[9px] font-black text-primary uppercase tracking-widest border border-primary/20 group-hover:bg-black group-hover:text-primary transition-all">
                        {conn.via}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </motion.div>
  );
}

// Enhanced circuit topology visualization
function CircuitTopology({ connections }: { connections: { from: string; to: string; via: string }[] }) {
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  const layout = useMemo(() => {
    const nodeSet = new Set<string>();
    (connections || []).forEach(c => { nodeSet.add(c.from); nodeSet.add(c.to); });
    const allNames = Array.from(nodeSet);

    // Categorize nodes: MCU center, sensors left, actuators right
    const mcuKeywords = /arduino|esp32|esp8266|raspberry|stm32|atmega|teensy|pico/i;
    const sensorKeywords = /sensor|dht|bmp|mpu|hc-sr|ldr|ir|gps|neo|bme|adc|analog|input|button|switch|potentiometer/i;
    
    const mcuNodes: string[] = [];
    const sensorNodes: string[] = [];
    const actuatorNodes: string[] = [];

    allNames.forEach(name => {
      if (mcuKeywords.test(name)) mcuNodes.push(name);
      else if (sensorKeywords.test(name)) sensorNodes.push(name);
      else actuatorNodes.push(name);
    });

    // If no MCU detected, use the most connected node as center
    if (mcuNodes.length === 0 && allNames.length > 0) {
      const connectionCount = new Map<string, number>();
      (connections || []).forEach(c => {
        connectionCount.set(c.from, (connectionCount.get(c.from) || 0) + 1);
        connectionCount.set(c.to, (connectionCount.get(c.to) || 0) + 1);
      });
      const sorted = allNames.sort((a, b) => (connectionCount.get(b) || 0) - (connectionCount.get(a) || 0));
      mcuNodes.push(sorted[0]);
      const remaining = sorted.slice(1);
      const half = Math.ceil(remaining.length / 2);
      sensorNodes.push(...remaining.slice(0, half).filter(n => !sensorNodes.includes(n)));
      actuatorNodes.push(...remaining.slice(half).filter(n => !actuatorNodes.includes(n)));
    }

    const width = 900;
    const height = Math.max(400, Math.max(sensorNodes.length, actuatorNodes.length) * 100 + 100);
    const centerX = width / 2;
    const centerY = height / 2;

    const nodes = new Map<string, { x: number; y: number; type: 'mcu' | 'sensor' | 'actuator' }>();

    // Place MCU nodes in center
    mcuNodes.forEach((name, i) => {
      nodes.set(name, {
        x: centerX,
        y: centerY - (mcuNodes.length - 1) * 40 + i * 80,
        type: 'mcu',
      });
    });

    // Place sensors on the left in a column
    sensorNodes.forEach((name, i) => {
      const spacing = Math.min(100, (height - 100) / Math.max(sensorNodes.length, 1));
      nodes.set(name, {
        x: 150,
        y: (height / 2) - ((sensorNodes.length - 1) * spacing / 2) + i * spacing,
        type: 'sensor',
      });
    });

    // Place actuators on the right
    actuatorNodes.forEach((name, i) => {
      const spacing = Math.min(100, (height - 100) / Math.max(actuatorNodes.length, 1));
      nodes.set(name, {
        x: width - 150,
        y: (height / 2) - ((actuatorNodes.length - 1) * spacing / 2) + i * spacing,
        type: 'actuator',
      });
    });

    return { nodes, width, height };
  }, [connections]);

  const getNodeColor = (type: 'mcu' | 'sensor' | 'actuator') => {
    switch (type) {
      case 'mcu': return { stroke: 'rgba(255,255,255,0.5)', bg: 'rgba(255,255,255,0.1)', text: '#fff' };
      case 'sensor': return { stroke: 'rgba(255,255,255,0.1)', bg: 'rgba(255,255,255,0.05)', text: 'rgba(255,255,255,0.7)' };
      case 'actuator': return { stroke: 'rgba(255,255,255,0.1)', bg: 'rgba(255,255,255,0.05)', text: 'rgba(255,255,255,0.7)' };
    }
  };

  return (
    <svg width="100%" viewBox={`0 0 ${layout.width} ${layout.height}`} className="overflow-visible">
      <defs>
        <filter id="glow-node">
          <feGaussianBlur stdDeviation="6" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
        <filter id="glow-line">
          <feGaussianBlur stdDeviation="4" result="glow" />
          <feMerge>
            <feMergeNode in="glow" />
            <feMergeNode in="glow" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <linearGradient id="line-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="rgba(203, 213, 225, 0.2)" />
          <stop offset="50%" stopColor="rgba(203, 213, 225, 0.8)" />
          <stop offset="100%" stopColor="rgba(203, 213, 225, 0.2)" />
        </linearGradient>
      </defs>

      {/* Connection lines with curves */}
      {(connections || []).map((conn, i) => {
        const from = layout.nodes.get(conn.from);
        const to = layout.nodes.get(conn.to);
        if (!from || !to) return null;
        
        const isRelated = hoveredNode === conn.from || hoveredNode === conn.to;
        const dx = to.x - from.x;
        const cpOffset = Math.abs(dx) * 0.4;
        const cp1x = from.x + (dx > 0 ? cpOffset : -cpOffset);
        const cp2x = to.x - (dx > 0 ? cpOffset : -cpOffset);
        const path = `M ${from.x} ${from.y} C ${cp1x} ${from.y}, ${cp2x} ${to.y}, ${to.x} ${to.y}`;
        
        const midX = (from.x + to.x) / 2;
        const midY = (from.y + to.y) / 2 - 20;
        
        return (
          <g key={`conn-${conn.from}-${conn.to}-${i}`} className="transition-all duration-300">
            {/* Primary Schematic Line - Solid & Clear */}
            <path 
              d={path} 
              fill="none" 
              stroke={isRelated ? "rgba(203, 213, 225, 1)" : "rgba(203, 213, 225, 0.4)"} 
              strokeWidth={isRelated ? "3" : "1.5"} 
              className="transition-all duration-300"
            />

            {/* Pulsing Active Glow - Conditional */}
            <motion.path 
              d={path} 
              fill="none" 
              stroke="rgba(203, 213, 225, 1)" 
              strokeWidth={isRelated ? "6" : "0"} 
              filter="url(#glow-line)"
              initial={{ opacity: 0 }}
              animate={{ opacity: isRelated ? [0.4, 0.8, 0.4] : 0 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Data Flow Trail */}
            <motion.path 
              d={path} 
              fill="none" 
              stroke={isRelated ? "#fff" : "rgba(203, 213, 225, 0.4)"} 
              strokeWidth={isRelated ? 2 : 1} 
              strokeDasharray="4 20"
              animate={{ strokeDashoffset: [0, -48] }}
              transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            />
            
            {/* Focal Signal Particle */}
            <motion.circle r={isRelated ? 4 : 2} fill="#fff" filter={isRelated ? "url(#glow-line)" : undefined}>
              <animateMotion dur={`${(isRelated ? 1 : 4) + i % 2}s`} repeatCount="indefinite" path={path} />
            </motion.circle>
            {conn.via && (
              <g transform={`translate(${midX}, ${midY})`}>
                <rect x={-conn.via.length * 5} y={-12} width={conn.via.length * 10} height={24}
                  fill="black" stroke={isRelated ? "#fff" : "rgba(255,255,255, 0.1)"} strokeWidth="2" />
                <text y={5} textAnchor="middle" fill={isRelated ? "white" : "white/40"} fontSize="10" fontStyle="normal" fontWeight="black" className="uppercase tracking-[0.2em] font-mono">
                  {conn.via}
                </text>
              </g>
            )}
          </g>
        );
      })}

      {/* Nodes */}
      {Array.from(layout.nodes.entries()).map(([name, pos]) => {
        const colors = getNodeColor(pos.type);
        const nodeW = pos.type === 'mcu' ? 200 : 180;
        const nodeH = pos.type === 'mcu' ? 70 : 60;
        
        return (
          <g 
            key={`circuit-node-${name}`} 
            filter={pos.type === 'mcu' ? 'url(#glow-node)' : undefined}
            onMouseEnter={() => setHoveredNode(name)}
            onMouseLeave={() => setHoveredNode(null)}
            className="cursor-pointer group"
          >
            <rect
              x={pos.x - nodeW / 2} y={pos.y - nodeH / 2}
              width={nodeW} height={nodeH}
              fill="rgba(8, 8, 9, 0.95)" 
              stroke={hoveredNode === name ? "rgba(203, 213, 225, 1)" : "rgba(203, 213, 225, 0.2)"}
              strokeWidth={hoveredNode === name ? 2 : 1}
              className="transition-all duration-200"
            />

            {/* Tactical Brackets */}
            <g className={`transition-opacity duration-300 ${hoveredNode === name ? 'opacity-100' : 'opacity-20'}`}>
              <path d={`M ${pos.x - nodeW/2} ${pos.y - nodeH/2 + 10} V ${pos.y - nodeH/2} H ${pos.x - nodeW/2 + 10}`} fill="none" stroke="currentColor" strokeWidth="1.5" className="text-primary" />
              <path d={`M ${pos.x + nodeW/2} ${pos.y - nodeH/2 + 10} V ${pos.y - nodeH/2} H ${pos.x + nodeW/2 - 10}`} fill="none" stroke="currentColor" strokeWidth="1.5" className="text-primary" />
              <path d={`M ${pos.x - nodeW/2} ${pos.y + nodeH/2 - 10} V ${pos.y + nodeH/2} H ${pos.x - nodeW/2 + 10}`} fill="none" stroke="currentColor" strokeWidth="1.5" className="text-primary" />
              <path d={`M ${pos.x + nodeW/2} ${pos.y + nodeH/2 - 10} V ${pos.y + nodeH/2} H ${pos.x + nodeW/2 - 10}`} fill="none" stroke="currentColor" strokeWidth="1.5" className="text-primary" />
            </g>

            <text x={pos.x} y={pos.y + (pos.type === 'mcu' ? -2 : 5)}
              textAnchor="middle" fill={hoveredNode === name ? "white" : "rgba(203, 213, 225, 0.8)"}
              fontSize={pos.type === 'mcu' ? 14 : 12}
              fontWeight="black" fontStyle="normal" className="uppercase tracking-[0.2em] font-mono transition-colors duration-200">
              {name.length > 20 ? name.slice(0, 18) + "…" : name}
            </text>
            {pos.type === 'mcu' && (
              <text x={pos.x} y={pos.y + 18} textAnchor="middle" fill="white/20" fontSize="9" fontWeight="black" className="uppercase tracking-[0.5em] font-mono">
                ARC_CORE_0x0
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}
