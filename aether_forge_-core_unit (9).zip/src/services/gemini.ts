import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface Message {
  role: "user" | "model";
  text: string;
}

export async function chatWithAI(messages: Message[], language: string, level: string) {
  const systemInstruction = `You are a helpful language learning partner. 
  The user is practicing ${language} at a ${level} level. 
  Keep your responses concise, encouraging, and appropriate for their level. 
  If they make a mistake, gently correct them. 
  Always respond in ${language} unless they ask for a translation or explanation in English.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    })),
    config: {
      systemInstruction,
    },
  });

  return response.text || "I'm sorry, I couldn't generate a response.";
}
