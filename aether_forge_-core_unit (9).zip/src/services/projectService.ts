import { db, setDoc, doc, getDoc, serverTimestamp, handleFirestoreError, OperationType, deleteDoc } from "@/lib/firebase";
import { Idea } from "./geminiService";

export interface ProjectPersistence {
  id: string;
  userId: string;
  title: string;
  description: string;
  field: string;
  difficulty: string;
  estimatedCost: string;
  userInputtedName?: string;
  blueprint: {
    plan: string;
    code: string;
    bom: Array<{ name: string; price: number; quantity: number; category: string }>;
    research: Record<string, unknown>;
    circuit: Record<string, unknown>;
    components: Array<{ name: string; price: number; quantity: number; category: string }>;
    modelDescription: string;
  };
  updatedAt: unknown;
  createdAt?: unknown;
}

export async function saveProject(idea: Idea & { isSaved?: boolean }, userId: string): Promise<boolean> {
  try {
    // Sanitize ID: alphanumeric and underscores only, max length 128
    const projectId = (idea.userInputtedName || idea.idea)
      .replace(/[^a-zA-Z0-9_-]/g, "_")
      .toLowerCase()
      .slice(0, 120);

    const projectData: ProjectPersistence = {
      id: projectId,
      userId,
      title: idea.idea,
      description: idea.description || "",
      field: idea.field,
      difficulty: idea.difficulty || "Basic",
      estimatedCost: idea.estimatedCost || "TBD",
      userInputtedName: idea.userInputtedName,
      blueprint: {
        plan: idea.plan,
        code: idea.code,
        bom: idea.components || [],
        research: idea.research || {},
        circuit: idea.circuit || {},
        components: idea.components || [],
        modelDescription: idea.modelData ? JSON.stringify(idea.modelData) : ""
      },
      updatedAt: serverTimestamp(),
    };

    const docRef = doc(db, "projects", projectId);
    const existingDoc = await getDoc(docRef);
    
    if (existingDoc.exists()) {
      // Update: preserve createdAt
      await setDoc(docRef, projectData, { merge: true });
    } else {
      // Create: set createdAt
      await setDoc(docRef, {
        ...projectData,
        createdAt: serverTimestamp()
      });
    }

    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `projects/${idea.idea}`);
    return false;
  }
}

export async function deleteProject(ideaKey: string): Promise<boolean> {
  try {
    const projectId = ideaKey.replace(/\s+/g, "_").toLowerCase();
    await deleteDoc(doc(db, "projects", projectId));
    return true;
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `projects/${ideaKey}`);
    return false;
  }
}
