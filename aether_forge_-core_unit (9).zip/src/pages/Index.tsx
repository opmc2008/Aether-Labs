import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HeroSection } from "@/components/ideaforge/HeroSection";
import { IdeaCard } from "@/components/ideaforge/IdeaCard";
import { ProjectDetail } from "@/components/ideaforge/ProjectDetail";
import { AetherChat } from "@/components/ideaforge/AetherChat";
import { AdvancedForgeModal } from "@/components/ideaforge/AdvancedForgeModal";
import { Logo } from "@/components/ideaforge/Logo";
import { UserMenu } from "@/components/auth/UserMenu";
import { useAuth } from "@/hooks/use-auth";
import { db, collection, query, where, onSnapshot } from "@/lib/firebase";
import { 
  generateIdeas, 
  buildIdea, 
  Idea
} from "@/services/geminiService";
import { deleteProject, saveProject } from "@/services/projectService";
import { toast } from "sonner";
import { Terminal, Cpu, Zap, Layers, ShieldAlert } from "lucide-react";

const Index = () => {
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Idea | null>(null);
  const [isBlueprintLoading, setIsBlueprintLoading] = useState(false);
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [loadingStatus, setLoadingStatus] = useState("Initializing_Neural_Link");
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isAdvancedModalOpen, setIsAdvancedModalOpen] = useState(false);
  const [savingIdeas, setSavingIdeas] = useState<Record<string, boolean>>({});
  const [chatPrompt, setChatPrompt] = useState<string | undefined>(undefined);
  const { user } = useAuth();

  // Cloud Persistence
  useEffect(() => {
    if (!user) {
      // Logic for non-logged in users (maybe still use localStorage?)
      const savedIdeas = localStorage.getItem("ideaforge_ideas");
      if (savedIdeas) {
        try {
          setIdeas(JSON.parse(savedIdeas));
        } catch (e) {
          console.error("Failed to load local ideas", e);
        }
      }
      return;
    }

    // Load from Firestore
    const q = query(
      collection(db, "projects"),
      where("userId", "==", user.uid)
    );

    interface ProjectDoc {
      id: string;
      title: string;
      description: string;
      field: string;
      difficulty: string;
      estimatedCost: string;
      blueprint: {
        plan?: string;
        code?: string;
        bom?: { name: string; price: number; quantity: number; category: string }[];
        research?: Record<string, unknown>;
        circuit?: Record<string, unknown>;
      };
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const cloudProjects = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as unknown as ProjectDoc[];
      
      // Map cloud projects back to Idea format
      const mappedIdeas: Idea[] = cloudProjects.map((p) => ({
        idea: p.id,
        title: p.title,
        description: p.description,
        field: p.field,
        difficulty: p.difficulty,
        estimatedCost: p.estimatedCost,
        plan: p.blueprint?.plan || "",
        code: p.blueprint?.code || "",
        bom: p.blueprint?.bom || [],
        research: p.blueprint?.research || {},
        circuit: p.blueprint?.circuit || {},
        originalPrompt: "", 
        isSaved: true
      }));

      // Optimization: Merge local ideas and cloud projects?
      // For now, let's prioritize cloud data if logged in
      setIdeas(mappedIdeas);
    }, (error) => {
      console.error("Firestore sync error:", error);
      toast.error("Failed to sync project data from the cloud.");
    });

    return () => unsubscribe();
  }, [user]);

  // Local Storage Fallback for unsaved ideas
  useEffect(() => {
    if (!user && ideas.length > 0) {
      localStorage.setItem("ideaforge_ideas", JSON.stringify(ideas));
    }
  }, [ideas, user]);

  useEffect(() => {
    const loadingSteps = [
      { progress: 10, status: "Establishing_Neural_Link..." },
      { progress: 25, status: "Calibrating_Aether_Core..." },
      { progress: 45, status: "Scanning_Dimensions..." },
      { progress: 65, status: "Synthesizing_Architectures..." },
      { progress: 85, status: "Finalizing_Realities..." },
      { progress: 100, status: "Sequence_Complete" },
    ];

    if (isLoading) {
      let currentStep = 0;
      const interval = setInterval(() => {
        if (currentStep < loadingSteps.length) {
          setLoadingProgress(loadingSteps[currentStep].progress);
          setLoadingStatus(loadingSteps[currentStep].status);
          currentStep++;
        } else {
          clearInterval(interval);
        }
      }, 700);
      return () => clearInterval(interval);
    } else {
      setLoadingProgress(0);
      setLoadingStatus("Idle_State");
    }
  }, [isLoading]);

  const handleUpdateIdea = useCallback((updatedIdea: Idea) => {
    setIdeas(prev => prev.map(i => i.idea === updatedIdea.idea ? updatedIdea : i));
    setSelectedProject(prev => {
      if (prev?.idea === updatedIdea.idea) {
        return { ...prev, ...updatedIdea };
      }
      return prev;
    });
  }, []);

  const handleSelectProject = useCallback(async (idea: Idea) => {
    if (idea.plan.length > 500) {
      setSelectedProject(idea);
      return;
    }

    setSelectedProject(idea);
    setIsBlueprintLoading(true);
    
    try {
      const advancedIdea = await buildIdea(idea.idea, idea.originalPrompt, idea.userInputtedName);
      if (advancedIdea) {
        const merged = { ...idea, ...advancedIdea };
        setSelectedProject(merged);
        setIdeas(prev => prev.map(i => i.idea === idea.idea ? merged : i));
        
        if (user) {
          saveProject(merged, user.uid).then(success => {
            if (success) {
              setIdeas(prev => prev.map(i => i.idea === idea.idea ? { ...merged, isSaved: true } : i));
              setSelectedProject(curr => curr?.idea === idea.idea ? { ...merged, isSaved: true } : curr);
            }
          });
        }
      }
    } catch (error: unknown) {
      console.error("Blueprint generation failed:", error);
      toast.error("Failed to generate project blueprint.");
    } finally {
      setIsBlueprintLoading(false);
    }
  }, [user]);

  const handleForge = useCallback(async (prompt: string, isDirect: boolean = false, customTitle?: string) => {
    setIsLoading(true);
    try {
      if (isDirect) {
        const directIdea: Idea = {
          idea: customTitle || prompt,
          title: customTitle || prompt,
          description: `Direct neural synthesis of: ${customTitle || prompt}`,
          field: "Experimental",
          difficulty: "Hard",
          estimatedCost: "...",
          plan: "",
          code: "",
          components: [],
          originalPrompt: prompt,
          userInputtedName: customTitle || prompt
        };
        setIdeas([directIdea]);
        handleSelectProject(directIdea);
      } else {
        const generatedIdeas = await generateIdeas(prompt);
        setIdeas(generatedIdeas);
      }
    } catch (error: unknown) {
      console.error("Forging failed:", error);
      toast.error("Failed to synthesize ideas.");
    } finally {
      setIsLoading(false);
    }
  }, [handleSelectProject]);

  const handleDeleteIdea = useCallback(async (idx: number) => {
    const ideaToDelete = ideas[idx];
    if (ideaToDelete.isSaved) {
      const success = await deleteProject(ideaToDelete.idea);
      if (!success) {
        toast.error("Failed to purge from cloud.");
        return;
      }
    }
    setIdeas(prev => prev.filter((_, i) => i !== idx));
    if (selectedProject?.idea === ideaToDelete.idea) setSelectedProject(null);
  }, [selectedProject, ideas]);

  const handleSaveIdea = useCallback(async (idea: Idea) => {
    if (!user) {
      toast.info("Authentication Required");
      return;
    }
    setSavingIdeas(prev => ({ ...prev, [idea.idea]: true }));
    const success = await saveProject(idea, user.uid);
    if (success) {
      handleUpdateIdea({ ...idea, isSaved: true });
      toast.success("Synthesis Synced");
    }
    setSavingIdeas(prev => ({ ...prev, [idea.idea]: false }));
  }, [user, handleUpdateIdea]);

  const loadingLogs = [
    "Establishing_Secure_Connection...",
    "Calibrating_Aether_Core...",
    "Scanning_Dimensional_Blueprints...",
    "Synthesizing_Parametric_Models...",
    "Finalizing_Reality_Anchor...",
    "Synthesis_Complete"
  ];

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-accent selection:text-black overflow-x-hidden font-sans relative">
      {/* Immersive Atmosphere & Schematic Layers */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute inset-0 atmosphere opacity-30" />
        <div className="absolute inset-0 tech-grid opacity-20" />
        
        {/* Animated Scanning Line */}
        <motion.div 
          animate={{ top: ["0%", "100%"] }}
          transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
          className="absolute left-0 right-0 h-[2px] bg-primary/5 z-10"
        />

        {/* Global Blueprint Markers */}
        <div className="absolute top-[20%] left-8 vertical-rl text-[7px] font-mono text-white/5 tracking-[2em] uppercase pointer-events-none">
          NEURAL_SYNTH_CORE_v4.2.0_STATION_722
        </div>
        <div className="absolute bottom-[20%] right-8 vertical-rl text-[7px] font-mono text-white/5 tracking-[2em] uppercase pointer-events-none rotate-180">
          GLOBAL_REGISTRY_LINK_ESTABLISHED
        </div>

        {/* Corner Brackets (Global) */}
        <div className="absolute top-10 left-10 w-20 h-20 border-t-2 border-l-2 border-white/5" />
        <div className="absolute top-10 right-10 w-20 h-20 border-t-2 border-r-2 border-white/5" />
        <div className="absolute bottom-10 left-10 w-20 h-20 border-b-2 border-l-2 border-white/5" />
        <div className="absolute bottom-10 right-10 w-20 h-20 border-b-2 border-r-2 border-white/5" />
      </div>

      {/* High-End Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-8 py-10 flex justify-between items-center bg-background/80 border-b-2 border-white/5 backdrop-blur-xl">
        <Logo />

        <div className="hidden lg:flex items-center gap-12 relative z-10">
          <div className="flex items-center gap-10">
            <a href="#" className="group flex flex-col">
              <span className="font-mono text-[11px] uppercase tracking-[0.4em] font-black text-white/40 group-hover:text-primary transition-all">RESEARCH_DATABASE</span>
            </a>
            <a href="#" className="group flex flex-col">
              <span className="font-mono text-[11px] uppercase tracking-[0.4em] font-black text-white/40 group-hover:text-primary transition-all">ARCHIVE_0x00</span>
            </a>
          </div>

          <div className="h-8 w-[2px] bg-primary/20" />

          <div className="flex items-center gap-4 px-6 py-3 bg-black border-2 border-primary">
            <div className="w-2 h-2 bg-primary phosphor-glow animate-pulse" />
            <span className="text-[10px] font-mono text-primary uppercase tracking-[0.5em] font-black">STRIKE_COORE_ACTIVE</span>
          </div>
        </div>

        <div className="flex items-center gap-8 relative z-10">
          <button 
            onClick={() => setIsAdvancedModalOpen(true)}
            className="hidden sm:flex items-center gap-4 px-8 py-3 bg-black border-2 border-white/5 hover:border-primary text-[10px] font-mono text-white/40 hover:text-primary transition-all uppercase tracking-widest font-black"
          >
            <Layers className="w-4 h-4" />
            <span>ADV_PROJECT</span>
          </button>
          <UserMenu />
        </div>
      </nav>

      <main className="relative z-10 pt-24">
        <HeroSection 
          onForge={handleForge} 
          onAdvancedForge={() => setIsAdvancedModalOpen(true)}
          isLoading={isLoading} 
        />

        <div className="max-w-7xl mx-auto px-8 pb-32">
          <AnimatePresence mode="wait">
            {ideas.length > 0 ? (
              <motion.div 
                key="results"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12"
              >
                {ideas.map((idea, index) => (
                  <motion.div
                    key={`project-synth-card-${idea.id || 'temp'}-${index}-${idea.idea.substring(0, 10)}`}
                    initial={{ opacity: 0, scale: 0.98 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <IdeaCard 
                      idea={idea} 
                      index={index}
                      isSelected={selectedProject?.idea === idea.idea}
                      onSelect={() => handleSelectProject(idea)}
                      onDelete={() => handleDeleteIdea(index)}
                      onSave={() => handleSaveIdea(idea)}
                      isSaving={savingIdeas[idea.idea]}
                    />
                  </motion.div>
                ))}
              </motion.div>
            ) : isLoading ? (
              <div 
                key="skeletons"
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 w-full"
              >
                {[0, 1, 2].map((i) => (
                  <div key={`skeleton-${i}`} className="bg-black border-2 border-white/5 p-12 space-y-8 relative overflow-hidden">
                    <motion.div 
                      className="absolute inset-0 bg-primary/5 -translate-x-full"
                      animate={{ translateX: ["100%", "-100%"] }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    />
                    
                    <div className="flex justify-between items-start">
                      <div className="w-16 h-16 bg-white/5" />
                      <div className="w-24 h-4 bg-white/5" />
                    </div>
                    
                    <div className="space-y-6">
                      <div className="w-3/4 h-12 bg-white/10" />
                      <div className="w-full h-4 bg-white/5" />
                    </div>

                    <div className="pt-12 grid grid-cols-2 gap-4">
                      <div className="h-14 bg-white/5" />
                      <div className="h-14 bg-white/5" />
                    </div>
                  </div>
                ))}
              </div>
            ) : !isLoading && (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-56 text-center"
              >
                <div className="relative w-32 h-32 mb-16 flex items-center justify-center">
                  <div className="absolute inset-0 border-4 border-primary/10 rotate-45" />
                  <div className="absolute inset-2 border-2 border-primary/20 rotate-12" />
                  <Cpu className="w-12 h-12 text-primary/60" />
                </div>
                <h3 className="text-4xl font-black tracking-[0.4em] text-white uppercase mb-6">STANDBY_IDLE</h3>
                <p className="text-white/20 font-mono text-[11px] uppercase tracking-[0.5em] max-w-lg leading-loose font-black">
                  WAITING_FOR_PARAMETRIC_INIT_SEQUENCE. <br/> INPUT_DATA_TO_COMMENCE.
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* Industrial Loading Screen */}
      <AnimatePresence>
        {isLoading && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center p-6 md:p-8 overflow-hidden"
          >
            {/* Background Atmosphere */}
            <div className="absolute inset-0 atmosphere opacity-60" />
            <div className="absolute inset-0 tech-grid opacity-30" />
            
            {/* Scanning Line (Loading) */}
            <motion.div 
              animate={{ left: ["0%", "100%"] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
              className="absolute top-0 bottom-0 w-[1px] bg-primary/20 z-10"
            />

            <div className="relative z-10 flex flex-col items-center max-w-2xl w-full">
              {/* Hardware Synthesis Loop */}
              <div className="relative w-48 h-48 mb-12">
                <div className="absolute inset-0 bg-primary/5 rounded-none animate-pulse" />
                
                {/* Rotating Girders */}
                <motion.div 
                  className="absolute inset-0 border-2 border-white/5"
                  animate={{ rotate: 90 }}
                  transition={{ duration: 0.5, repeat: Infinity, ease: "linear" }}
                />
                <motion.div 
                  className="absolute inset-6 border border-primary/10"
                  animate={{ rotate: -90 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                />
                
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-5 h-5 bg-primary phosphor-glow" />
                  <div className="absolute w-20 h-20 border-2 border-primary/20 animate-ping" />
                </div>
              </div>

              <div className="text-center space-y-10 w-full">
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-6">
                    <div className="h-[1px] w-8 bg-primary" />
                    <span className="font-mono text-primary text-sm font-black phosphor-glow tracking-[0.5em]">SYSTEM_BUSY</span>
                    <div className="h-[1px] w-8 bg-primary" />
                  </div>
                  <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white uppercase leading-none overflow-hidden">
                    <motion.span 
                      initial={{ y: "100%" }}
                      animate={{ y: 0 }}
                      className="block"
                    >
                      SYNTH_0x7
                    </motion.span>
                  </h1>
                </div>
                
                {/* Industrial Progress Bar */}
                <div className="space-y-4 max-w-lg mx-auto w-full">
                  <div className="flex justify-between items-end text-[10px] font-mono tracking-[0.4em] text-white/40 uppercase font-black">
                    <span className="animate-pulse">{loadingStatus.toUpperCase()}</span>
                    <span className="text-primary phosphor-glow">{Math.round(loadingProgress)}%</span>
                  </div>
                  <div className="h-1.5 w-full bg-white/5 relative">
                    <motion.div 
                      className="absolute inset-y-0 left-0 bg-primary phosphor-glow"
                      initial={{ width: 0 }}
                      animate={{ width: `${loadingProgress}%` }}
                    />
                  </div>
                </div>

                {/* Technical Sequence Logs */}
                <div className="flex flex-col gap-3 pt-10 border-t border-primary/10 opacity-30">
                  {loadingLogs.slice(-2).map((log, idx) => (
                    <div key={`log-${idx}-${log.substring(0, 10)}`} className="flex items-center justify-center gap-4 text-[9px] font-mono text-white/40 uppercase tracking-[0.3em] font-black">
                      <div className="w-1.5 h-1.5 bg-primary" />
                      <span>{log}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Terminal Static Labels */}
            <div className="absolute bottom-8 left-8 text-[8px] font-mono text-white/10 flex flex-col gap-1 leading-relaxed uppercase tracking-[0.1em] font-bold">
              <span>REF_CORE: OPTIMAL</span>
              <span>NEURAL_LOAD: STABLE</span>
              <span>LOC_SECTOR: 0x722_BF</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {selectedProject && (
          <ProjectDetail 
            key={selectedProject.id || selectedProject.idea}
            idea={selectedProject} 
            onClose={() => {
              setSelectedProject(null);
            }}
            isLoading={isBlueprintLoading}
            onUpdateIdea={handleUpdateIdea}
            onAskAether={(p) => {
              setChatPrompt(p);
              setIsChatOpen(true);
            }}
            allProjects={ideas}
            onSelectProject={(p) => handleSelectProject(p)}
          />
        )}
      </AnimatePresence>

      <AetherChat 
        open={isChatOpen}
        onOpenChange={(op) => {
          setIsChatOpen(op);
          if (!op) setChatPrompt(undefined);
        }}
        onForge={handleForge} 
        isForging={isLoading}
        initialMessage={chatPrompt}
        context={selectedProject ? { idea: selectedProject.idea, plan: selectedProject.plan, field: selectedProject.field } : undefined}
      />

      <AdvancedForgeModal 
        open={isAdvancedModalOpen}
        onOpenChange={setIsAdvancedModalOpen}
        onForge={(detailedPrompt, title) => {
          setIsAdvancedModalOpen(false);
          handleForge(detailedPrompt, true, title);
        }}
        isLoading={isLoading}
      />

      {/* Industrial Footer */}
      <footer className="relative z-10 border-t border-white/5 py-24 px-4 md:px-12 bg-[#050505]">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-16 md:gap-8">
          <div className="flex flex-col gap-4">
            <Logo />
            <p className="text-[10px] font-mono text-white/10 uppercase tracking-[0.3em] mt-8 font-bold leading-loose">
              © 2026 Aether Engineering Labs<br/>Neural_Fabrication_v4.2.0
            </p>
          </div>
          <div className="grid grid-cols-2 gap-16 md:flex md:gap-24">
            <div className="flex flex-col gap-6">
              <span className="text-[11px] font-mono text-white/80 uppercase tracking-widest font-bold">Interface</span>
              <div className="flex flex-col gap-4 text-[10px] font-mono text-white/20 uppercase tracking-[0.2em] font-medium">
                <a href="#" className="hover:text-primary transition-colors">Lab_Core</a>
                <a href="#" className="hover:text-primary transition-colors">Research_Archive</a>
                <a href="#" className="hover:text-primary transition-colors">Blueprint_Registry</a>
              </div>
            </div>
            <div className="flex flex-col gap-6">
              <span className="text-[11px] font-mono text-white/80 uppercase tracking-widest font-bold">Neural_Net</span>
              <div className="flex flex-col gap-4 text-[10px] font-mono text-white/20 uppercase tracking-[0.2em] font-medium">
                <a href="#" className="hover:text-primary transition-colors">Logic_Relay</a>
                <a href="#" className="hover:text-primary transition-colors">Satellite_Uplink</a>
                <a href="#" className="hover:text-primary transition-colors">Terminal_Auth</a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
